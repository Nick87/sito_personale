/*
 * Se annullo cancella file e non mostrare hash
 * se file inesistente non mostrare hash
 */

package cifrario;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Toolkit;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class GUI extends javax.swing.JFrame
{
    public GUI(String title)
    {
        super(title);
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException ex) {
        } catch (InstantiationException ex) {
        } catch (IllegalAccessException ex) {
        } catch (UnsupportedLookAndFeelException ex) {}
        
        UIManager.put("ProgressBar.background", Color.BLACK);//Colour of the background
        UIManager.put("ProgressBar.foreground", Color.RED);  //colour of progress bar
        UIManager.put("ProgressBar.selectionBackground",Color.BLACK);  //colour of percentage counter on black background
        UIManager.put("ProgressBar.selectionForeground",Color.BLUE);  //colour of precentage counter on red background
        initComponents();
        this.setLocationRelativeTo(null);
        this.setIconImage(new javax.swing.ImageIcon(iconPath).getImage());
        filePath = "";
        ProgressBar.setMinimum(0);
        ProgressBar.setValue(0);
        ProgressBar.setStringPainted(true);
        Task = null;
        oldCursorType = -1;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jToggleButton1 = new javax.swing.JToggleButton();
        panel = new javax.swing.JPanel();
        btnSfoglia = new javax.swing.JButton();
        ProgressBar = new javax.swing.JProgressBar();
        btnComincia = new javax.swing.JButton();
        filepath = new javax.swing.JLabel();
        lblChiave = new javax.swing.JLabel();
        Chiave = new javax.swing.JPasswordField();
        btnAnnulla = new javax.swing.JButton();

        jToggleButton1.setText("jToggleButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        btnSfoglia.setText("Sfoglia");
        btnSfoglia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSfogliaActionPerformed(evt);
            }
        });

        btnComincia.setText("Comincia");
        btnComincia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCominciaActionPerformed(evt);
            }
        });

        filepath.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N

        lblChiave.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblChiave.setText("Chiave:");

        Chiave.setColumns(15);

        btnAnnulla.setText("Annulla");
        btnAnnulla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnAnnullaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnAnnullaMouseExited(evt);
            }
        });
        btnAnnulla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnnullaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelLayout = new javax.swing.GroupLayout(panel);
        panel.setLayout(panelLayout);
        panelLayout.setHorizontalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblChiave)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Chiave, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSfoglia)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnComincia)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnAnnulla)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(ProgressBar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 492, Short.MAX_VALUE)
                        .addComponent(filepath, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 492, Short.MAX_VALUE))
                    .addContainerGap()))
        );
        panelLayout.setVerticalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblChiave)
                    .addComponent(Chiave, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnComincia)
                    .addComponent(btnSfoglia)
                    .addComponent(btnAnnulla))
                .addContainerGap(66, Short.MAX_VALUE))
            .addGroup(panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelLayout.createSequentialGroup()
                    .addContainerGap(40, Short.MAX_VALUE)
                    .addComponent(filepath, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(ProgressBar, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSfogliaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSfogliaActionPerformed
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Scegli il file da cifrare/decifrare");
        if(chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
        {
            filePath = chooser.getSelectedFile().getAbsolutePath();
            filepath.setText(filePath);
            ProgressBar.setMinimum(0);
            ProgressBar.setValue(0);
        }
    }//GEN-LAST:event_btnSfogliaActionPerformed

    private void btnCominciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCominciaActionPerformed
        boolean check = false;
        if(filePath.equals("")){
            JOptionPane.showMessageDialog(this, "Scegliere un file da cifrare/decifrare.", "Errore", JOptionPane.ERROR_MESSAGE);
            check = true;
        }
        if(Chiave.getPassword().length == 0){
            JOptionPane.showMessageDialog(this, "Inserire una chiave di cifratura/decifratura.", "Errore", JOptionPane.ERROR_MESSAGE);
            check = true;
        }
        if(check) return;
        btnSfoglia.setEnabled(false);
        btnComincia.setEnabled(false);
        Chiave.setEditable(false);
        ProgressBar.setMinimum(0);
        ProgressBar.setValue(0);
        Task = new WorkerThread(filePath, Chiave.getPassword(), this);
        this.setCursor(new Cursor(Cursor.WAIT_CURSOR));
        Task.start();
    }//GEN-LAST:event_btnCominciaActionPerformed

    private void btnAnnullaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnnullaActionPerformed
        if(Task != null) Task.Stop();
    }//GEN-LAST:event_btnAnnullaActionPerformed

    private void btnAnnullaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAnnullaMouseEntered
        oldCursorType = this.getCursor().getType();
        this.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_btnAnnullaMouseEntered

    private void btnAnnullaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAnnullaMouseExited
        this.setCursor(new Cursor(oldCursorType));
    }//GEN-LAST:event_btnAnnullaMouseExited

    public void Avanza(int step)
    {
        ProgressBar.setValue(ProgressBar.getValue()+step);
    }

    public void SetLimit(int limit)
    {
        ProgressBar.setMaximum(limit);
    }

    public void ResetProgressBar()
    {
        ProgressBar.setValue(0);
    }

    public void SetProgressBarString(String string)
    {
        ProgressBar.setString(string);
    }

    public void Fine(boolean returnState, String filename, String md5)
    {
        this.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        btnSfoglia.setEnabled(true);
        btnComincia.setEnabled(true);
        Chiave.setEditable(true);
        Toolkit.getDefaultToolkit().beep();
        if(returnState)
            JOptionPane.showMessageDialog(this, "Hash MD5 (" + filename + "): " + md5, "Info", JOptionPane.INFORMATION_MESSAGE);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPasswordField Chiave;
    private javax.swing.JProgressBar ProgressBar;
    private javax.swing.JButton btnAnnulla;
    private javax.swing.JButton btnComincia;
    private javax.swing.JButton btnSfoglia;
    private javax.swing.JLabel filepath;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JLabel lblChiave;
    private javax.swing.JPanel panel;
    // End of variables declaration//GEN-END:variables
    private final String iconPath = "lucchetto.png";
    private String filePath;
    private WorkerThread Task;
    private int oldCursorType;
}
