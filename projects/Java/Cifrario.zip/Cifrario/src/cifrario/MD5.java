package cifrario;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.MessageDigest;

public class MD5
{
    private String MD5Checksum;

    public MD5()
    {
        MD5Checksum = "";
    }

    public MD5(GUI gui, String filename)
    {
        MD5Checksum = "";
        createChecksum(gui, filename);
    }

    public String getMD5()
    {
        return MD5Checksum;
    }

    public void computeMD5(GUI gui, String filename)
    {
        MD5Checksum = "";
        createChecksum(gui, filename);
    }

    private void createChecksum(GUI gui, String filename)
    {
        InputStream fis = null;
        MessageDigest md = null;
        byte[] buffer = new byte[1024];
        int numRead;

        try
        {
            gui.ResetProgressBar();
            gui.SetLimit((int)new File(filename).length());
            fis = new FileInputStream(filename);
            md = MessageDigest.getInstance("MD5");
            do
            {
                numRead = fis.read(buffer);
                if (numRead > 0)
                    md.update(buffer, 0, numRead);
                gui.Avanza(numRead+1);
            } while (numRead != -1);
            fis.close();
        } catch (Exception ex) {}

        buffer = md.digest();
        for (int i = 0; i < buffer.length; i++)
            MD5Checksum += Integer.toString((buffer[i]&0xff) + 0x100, 16).substring(1);
    }
}
