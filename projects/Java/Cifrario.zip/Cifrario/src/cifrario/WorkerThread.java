package cifrario;

import java.io.File;
import java.io.RandomAccessFile;
import javax.swing.JOptionPane;

public class WorkerThread extends Thread
{
    private String file;
    private String tempFile;
    private char[] chiave;
    private char mask = 0;
    private GUI gui;
    private volatile boolean stop;
    private MD5 digest;
    private final int step = 100000000;

    public WorkerThread(String file, char[] chiave, GUI gui)
    {
        this.file = file;
        this.chiave = chiave;
        this.gui = gui;
        this.stop = false;
        this.mask = 0;
        for(int i = 0; i < chiave.length; i++)
            this.mask ^= chiave[i];
        this.digest = new MD5();
    }

    @Override
    public void run()
    {
        if(file.endsWith(".cifrato"))
            tempFile = file.substring(0, file.length()-8);
        else
            tempFile = file + ".cifrato";
        boolean ret = comincia();
        gui.Fine(ret, tempFile, digest.getMD5());
    }

    private boolean comincia()
    {
        RandomAccessFile rafIn = null, rafOut = null;
        byte[] buffer;

        File f1 = new File(file);

        if(!f1.exists()){
            JOptionPane.showMessageDialog(gui, file + ": file inesistente.", "Errore", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if(new File(tempFile).exists()){
            int ret = JOptionPane.showConfirmDialog(gui, tempFile + ": file esistente. Continuare?", "Conferma",
                                                    JOptionPane.YES_NO_OPTION);
            if(ret == JOptionPane.NO_OPTION) return false;
        }

        try
        {
            int count = 0;
            int dim, offset = 0, nRead, BytesLeft = (int)f1.length();
            rafIn = new RandomAccessFile(file, "r");
            rafOut = new RandomAccessFile(new File(tempFile), "rw");
            gui.SetLimit((int)f1.length());

            dim = (BytesLeft < step) ? BytesLeft : step;
            buffer = new byte[dim];

            while(BytesLeft > 0)
            {
                dim = (BytesLeft < step) ? BytesLeft : step;
                BytesLeft -= rafIn.read(buffer, 0, dim);
                for(int i = 0; i < dim; i++)
                {
                    buffer[i] ^= this.mask;
                    gui.Avanza(1);
                    count++;
                    if(stop)
                    {
                        rafIn.close();
                        rafOut.close();
                        new File(tempFile).delete();
                        return false;
                    }
                }
                rafOut.write(buffer, 0, dim);
                offset += dim;
            }
            rafIn.close();
            rafOut.close();
        } catch (Exception ex){
            JOptionPane.showMessageDialog(gui, ex.toString(), "Errore", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        digest.computeMD5(gui, tempFile);
        return true;
    }

    public void Stop()
    {
        this.stop = true;
    }
}
