package cifrario;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;

public class SHA1
{
    public String calculateSHA1(String fileName) throws NoSuchAlgorithmException,
                                                        FileNotFoundException,
                                                        IOException
    {
        MessageDigest complete = MessageDigest.getInstance("SHA1");
        FileInputStream     fis = new FileInputStream(fileName);
        BufferedInputStream bis = new BufferedInputStream(fis);
        DigestInputStream   dis = new DigestInputStream(bis, complete);

        // read the file and update the hash calculation
        while (dis.read() != -1);

        // get the hash value as byte array
        byte[] hash = complete.digest();

        return byteArray2Hex(hash);
    }

    private static String byteArray2Hex(byte[] hash)
    {
        Formatter formatter = new Formatter();
        for (byte b : hash)
            formatter.format("%02x", b);
        return formatter.toString();
    }
}