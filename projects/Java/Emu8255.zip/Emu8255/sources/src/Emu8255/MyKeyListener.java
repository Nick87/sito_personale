/* Eemu - 8255 peripheral extension for emu8086
 * Copyright (C) <2011>  <Nicola Alessandro Domingo>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package Emu8255;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * This class implements the listener for all the text fields.
 * According to the input method, a character may be rejected or not.
 * For example, if the input method is set to binary, only characters 1 and 0 are allowed.
 * Besides, when in mode 0, values are written to the corresponding ports when the input is complete
 * (i.e. 8 one/zeros when in binary mode, 1 bit for PCi,
 * 1 character when in Ascii mode, 2 hex chars when in hexadecimal mode).
 */
public class MyKeyListener implements KeyListener
{
    /**
     * Parameterized constructor.
     * @param gui A reference to the main user interface
     * @param TextField A reference to the text field this listener is associated to.
     * @param me An identifier for text field.
     */
    public MyKeyListener(Emu8255GUI gui, Emu8255 mainclass, char me)
    {
        this.gui = gui;
        this.Main = mainclass;
        Me = me;
        old_str = "";
    }

    /**
     * This method is invoked when a key has been pressed.
     * @param e The KeyEvent
     */
    public void keyPressed(KeyEvent e)
    {
        old_str = gui.GetText(Me);
        int Key = e.getKeyCode();
        if(e.isShiftDown() == true && gui.GetText(Me).length() > 0)
           return;
        if((Main.GetInputMode() == Ascii && old_str.length() == 1) ||
           (Me >= '0' && Me <= '7' && old_str.length() == 1))
        gui.SetText(Me, "");
    }

    /**
     * This method is invoked when a key has been typed.
     * @param e The KeyEvent
     */
    public void keyTyped(KeyEvent e) {}

    /**
     * This method is invoked when a key has been released.
     * @param e The KeyEvent
     */
    public void keyReleased(KeyEvent e)
    {
        int Key = e.getKeyCode();
        char KeyChar = e.getKeyChar();
        boolean check = false;

        if(Me >= '0' && Me <= '7')
        {
            if((e.isShiftDown() == true && Key == KeyEvent.VK_HOME) ||
               (e.isShiftDown() == true && Key == KeyEvent.VK_END)  || Key == KeyEvent.VK_SHIFT)
            check = true;

            //in order to allow text editing
            if(Key != KeyEvent.VK_BACK_SPACE && Key != KeyEvent.VK_DELETE &&
               Key != KeyEvent.VK_KP_LEFT && Key != KeyEvent.VK_KP_RIGHT &&
               Key != KeyEvent.VK_LEFT && Key != KeyEvent.VK_RIGHT &&
               Key != KeyEvent.VK_END && Key != KeyEvent.VK_HOME)
            {
                if(old_str.length() < 2){
                   if(Key != KeyEvent.VK_0 && Key != KeyEvent.VK_1 &&
                      Key != KeyEvent.VK_NUMPAD0 && Key != KeyEvent.VK_NUMPAD1 && !check)
                   gui.SetText(Me, old_str);
                }else{
                    if(!check)
                         gui.SetText(Me, old_str);
                }
            }
        }

        if(Main.GetInputMode() == Binary || Main.GetInputMode() == Hexadecimal)
        {
            if((e.isShiftDown() == true && Key == KeyEvent.VK_HOME) ||
              (e.isShiftDown() == true && Key == KeyEvent.VK_END) || Key == KeyEvent.VK_SHIFT)
                check = true;

            //in order to allow text editing
            if(Key != KeyEvent.VK_BACK_SPACE && Key != KeyEvent.VK_DELETE &&
               Key != KeyEvent.VK_KP_LEFT && Key != KeyEvent.VK_KP_RIGHT &&
               Key != KeyEvent.VK_LEFT && Key != KeyEvent.VK_RIGHT &&
               Key != KeyEvent.VK_END && Key != KeyEvent.VK_HOME)
            {
                if(Me == 'A' || Me == 'B')
                {
                    if(Main.GetInputMode() == Binary && old_str.length() < 8){
                        if(Key != KeyEvent.VK_0 && Key != KeyEvent.VK_1 &&
                           Key != KeyEvent.VK_NUMPAD0 && Key != KeyEvent.VK_NUMPAD1 && !check)
                         gui.SetText(Me, old_str);
                    }else if(Main.GetInputMode() == Hexadecimal && old_str.length() < 2){
                        if(!((KeyChar >= '0' && KeyChar <= '9') ||
                           (KeyChar >= 'a' && KeyChar <= 'f') ||
                           (KeyChar >= 'A' && KeyChar <= 'F')) && !check)
                         gui.SetText(Me, old_str);
                    }else{
                        if(!check)
                             gui.SetText(Me, old_str);
                    }
                }
            }
        }
        if(Main.GetInputMode() == IntegerSigned)
        {
            if((e.isShiftDown() == true && Key == KeyEvent.VK_HOME) ||
              (e.isShiftDown() == true && Key == KeyEvent.VK_END) || Key == KeyEvent.VK_SHIFT)
            check = true;
            
            if(Key != KeyEvent.VK_BACK_SPACE && Key != KeyEvent.VK_DELETE &&
               Key != KeyEvent.VK_KP_LEFT && Key != KeyEvent.VK_KP_RIGHT &&
               Key != KeyEvent.VK_LEFT && Key != KeyEvent.VK_RIGHT &&
               Key != KeyEvent.VK_END && Key != KeyEvent.VK_HOME)
            {
                if((Key == KeyEvent.VK_MINUS || Key == KeyEvent.VK_SUBTRACT) && gui.GetText(Me).length() == 1)
                    return;
                if((Key == KeyEvent.VK_PERIOD || Key == KeyEvent.VK_DECIMAL) && gui.GetText(Me).length() == 2){
                    gui.SetText(Me, old_str);
                    return;
                }

                if(!((Key >= KeyEvent.VK_0 && Key <= KeyEvent.VK_9) ||
                     (Key >= KeyEvent.VK_NUMPAD0 && Key <= KeyEvent.VK_NUMPAD9) ||
                     (Key == KeyEvent.VK_PERIOD || Key == KeyEvent.VK_DECIMAL)) && !check)
                {
                    gui.SetText(Me, old_str);
                    return;
                }

                if(Key == KeyEvent.VK_PERIOD || Key == KeyEvent.VK_DECIMAL)
                {
                    String text = gui.GetText(Me);
                    char val;
                    boolean isNegative = (text.charAt(0) == '-') ? true : false;
                    int temp, start = (isNegative) ? 1 : 0;

                    //Prendo il modulo del numero
                    if(isNegative) temp = Integer.parseInt(text.substring(1, text.length()-1));
                    else           temp = Integer.parseInt(text.substring(0, text.length()-1));

                    //e controllo che non esca fuori dal range
                    if(isNegative){
                        if(temp > 128){
                           gui.SetText(Me, old_str);
                           return;
                        }
                    }else{
                        if(temp > 127){
                           gui.SetText(Me, old_str);
                           return;
                        }
                    }

                    val = (char) ((char) temp & 0xff);

                    if(isNegative){
                        val ^= 0xff;
                        val++;
                        val &= 0xff;
                    }
                    if(Main.GetGroupAMode() == 0 && Me == 'A'){
                        IO.WriteByte(IO_FILE, BASE, val);
                        //Write IBFa, PC5
                        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x20));
                    }else if (Main.GetGroupBMode() == 0 && Me == 'B'){
                        IO.WriteByte(IO_FILE, BASE+1, val);
                        //Write IBFb, PC1
                        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x01));
                    }
                    //System.out.println("Scrivo " + val);
                    gui.SetText(Me, old_str);
                    return;
                }

                if(gui.GetText(Me).length() > 4){
                    gui.SetText(Me, old_str);
                    return;
                }
                
                //Se c'è '-' come primo carattere, non ce ne devono essere altri
                String str = gui.GetText(Me);
                boolean isNegative;

                if(str.charAt(0) == '-'){
                    if(str.length() > 1)
                    {
                        if(str.charAt(1) == '0') gui.SetText(Me, old_str); //Uno zero dopo il meno non ha senso
                        for(int i = 1; i < str.length(); i++)
                            if(str.charAt(i) < '0' || str.charAt(i) > '9')
                                gui.SetText(Me, old_str);
                        isNegative = true;
                    }
                }else{
                    if(str.charAt(0) == '0') gui.SetText(Me, old_str); //Uno zero come prima cifra non ha senso
                    //Se non c'è '-' come primo carattere, non ci deve essere nessun '-'
                    for(int i = 0; i < str.length(); i++)
                        if(str.charAt(i) < '0' || str.charAt(i) > '9')
                            gui.SetText(Me, old_str);
                    isNegative = false;
                }
            }
        }
        if(Main.GetInputMode() == IntegerUnsigned)
        {
            if((e.isShiftDown() == true && Key == KeyEvent.VK_HOME) ||
              (e.isShiftDown() == true && Key == KeyEvent.VK_END) || Key == KeyEvent.VK_SHIFT)
            check = true;

            if(Key != KeyEvent.VK_BACK_SPACE && Key != KeyEvent.VK_DELETE &&
               Key != KeyEvent.VK_KP_LEFT && Key != KeyEvent.VK_KP_RIGHT &&
               Key != KeyEvent.VK_LEFT && Key != KeyEvent.VK_RIGHT &&
               Key != KeyEvent.VK_END && Key != KeyEvent.VK_HOME)
            {
                if(Key == KeyEvent.VK_MINUS || Key == KeyEvent.VK_SUBTRACT){
                    gui.SetText(Me, old_str);
                    return;
                }
                if((Key == KeyEvent.VK_PERIOD || Key == KeyEvent.VK_DECIMAL) && gui.GetText(Me).length() == 1){
                    gui.SetText(Me, old_str);
                    return;
                }

                if(!((Key >= KeyEvent.VK_0 && Key <= KeyEvent.VK_9) ||
                     (Key >= KeyEvent.VK_NUMPAD0 && Key <= KeyEvent.VK_NUMPAD9) ||
                     (Key == KeyEvent.VK_PERIOD || Key == KeyEvent.VK_DECIMAL)) && !check)
                {
                    gui.SetText(Me, old_str);
                    return;
                }

                if(Key == KeyEvent.VK_PERIOD || Key == KeyEvent.VK_DECIMAL)
                {
                    String text = gui.GetText(Me);
                    char val;
                    int temp;
                    //Prendo il modulo del numero
                    temp = Integer.parseInt(text.substring(0, text.length()-1));

                    //e controllo che non esca fuori dal range
                    if(temp > 255){
                           gui.SetText(Me, old_str);
                           return;
                    }
                    val = (char) ((char) temp & 0xff);

                    if(Main.GetGroupAMode() == 0 && Me == 'A'){
                        IO.WriteByte(IO_FILE, BASE, val);
                        //Write IBFa, PC5
                        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x20));
                    }else if (Main.GetGroupBMode() == 0 && Me == 'B'){
                        IO.WriteByte(IO_FILE, BASE+1, val);
                        //Write IBFb, PC1
                        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x01));
                    }
                    //System.out.println("Scrivo " + val);
                    gui.SetText(Me, old_str);
                    return;
                }

                if(gui.GetText(Me).length() > 3){
                    gui.SetText(Me, old_str);
                    return;
                }
            }
        }

        if(Main.GetInputMode() == Ascii && gui.GetText(Me).length() == 1)
        {
            char val = gui.GetText(Me).charAt(0);
            if(Main.GetGroupAMode() == 0 && Me == 'A'){
                IO.WriteByte(IO_FILE, BASE, val);
                //Write IBFa, PC5
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x20));
            }else if (Main.GetGroupBMode() == 0 && Me == 'B'){
                IO.WriteByte(IO_FILE, BASE+1, val);
                //Write IBFb, PC1
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x01));
            }
        }
        else if(Main.GetInputMode() == Binary && gui.GetText(Me).length() == 8)
        {
            char val = 0;
            for(int i = 0; i < 8; i++)
                if(gui.GetText(Me).charAt(i) == '1')
                    val |= (1 << (7-i));
            if(Main.GetGroupAMode() == 0 && Me == 'A'){
                IO.WriteByte(IO_FILE, BASE, val);
                //Write IBFa, PC5
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x20));
            }else if (Main.GetGroupBMode() == 0 && Me == 'B'){
                IO.WriteByte(IO_FILE, BASE+1, val);
                //Write IBFb, PC1
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x01));
            }
        }
        else if(Main.GetInputMode() == Hexadecimal && gui.GetText(Me).length() == 2)
        {
            char val = 0;
            char msn = gui.GetText(Me).charAt(0);
            char lsn = gui.GetText(Me).charAt(1);
            if(lsn >= '0' && lsn <= '9')
                val |= lsn-'0';
            else if(lsn >= 'a' && lsn <= 'f')
                val |= lsn-87;
            else if(lsn >= 'A' && lsn <= 'F')
                val |= lsn-55;
            if(msn >= '0' && msn <= '9')
                val |= (msn-'0')<<4;
            else if(msn >= 'a' && msn <= 'f')
                val |= (msn-87)<<4;
            else if(msn >= 'A' && msn <= 'F')
                val |= (msn-55)<<4;

            if(Main.GetGroupAMode() == 0 && Me == 'A'){
                IO.WriteByte(IO_FILE, BASE, val);
                //Write IBFa, PC5
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x20));
            }else if (Main.GetGroupBMode() == 0 && Me == 'B') {
                IO.WriteByte(IO_FILE, BASE+1, val);
                //Write IBFb, PC1
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x01));
            }
        }

        if(Me == '0' && gui.GetText(Me).length() > 0)
        {
            if(gui.GetText(Me).charAt(0) == '0')
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xFE));
            else
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x01));
        }
        else if(Me == '1' && gui.GetText(Me).length() > 0)
        {
            if(gui.GetText(Me).charAt(0) == '0')
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xFD));
            else
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x02));
        }
        else if(Me == '2' && gui.GetText(Me).length() > 0)
        {
            if(gui.GetText(Me).charAt(0) == '0')
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xFB));
            else
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x04));
        }
        else if(Me == '3' && gui.GetText(Me).length() > 0)
        {
            if(gui.GetText(Me).charAt(0) == '0')
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xF7));
            else
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x08));
        }
        else if(Me == '4' && gui.GetText(Me).length() > 0)
        {
            if(gui.GetText(Me).charAt(0) == '0')
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xEF));
            else
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x10));
        }
        else if(Me == '5' && gui.GetText(Me).length() > 0)
        {
            if(gui.GetText(Me).charAt(0) == '0')
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xDF));
            else
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x20));
        }
        else if(Me == '6' && gui.GetText(Me).length() > 0)
        {
            if(gui.GetText(Me).charAt(0) == '0')
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xBF));
            else
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x40));
        }
        else if(Me == '7' && gui.GetText(Me).length() > 0)
        {
            if(gui.GetText(Me).charAt(0) == '0')
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0x7F));
            else
                IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x80));
        }
    }

    private String old_str;
    private char Me;
    private Emu8255GUI gui;
    private Emu8255 Main;
    private final int Ascii = 0;
    private final int Binary = 1;
    private final int Hexadecimal = 2;
    private final int IntegerSigned = 3;
    private final int IntegerUnsigned = 4;
    private final int BASE = 128; //080h
    private final String IO_FILE = "C:\\emu8086.io";
}