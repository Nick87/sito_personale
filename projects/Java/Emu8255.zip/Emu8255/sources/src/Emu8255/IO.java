/* Eemu - 8255 peripheral extension for emu8086
 * Copyright (C) <2011>  <Nicola Alessandro Domingo>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package Emu8255;

import intr.InterruptRequest;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.RandomAccessFile;
import java.io.StringWriter;
import java.net.Socket;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

/**
 * This class provides methods for writing to and reading from file, as well as
 * sending an InterruptRequest object to the PIC8259 through a socket and retrieving and
 * setting value of XML configuration tags.
 *
 * @see InterruptRequest
 */
public class IO
{
    /**
     * Default Constructor.
     */
    public IO()
    {
        PortNo = -1;
    }

    /**
     * This method returns one byte as a char at <code>PortNo</code> position within <code>file</code>.
     * @param file File to read from.
     * @param PortNo Offset from the beginning of the file.
     * @return The character read.
     * @exception IOException
     */
    public synchronized static char ReadByte(String file, int PortNo)
    {
        File f = new File(file);
        RandomAccessFile raf = null;
        byte[] b = new byte[1];
        try {
            raf = new RandomAccessFile(f, "r");
            raf.seek(PortNo);
            raf.read(b, 0, 1);
            raf.close();
        } catch (FileNotFoundException ex) {
            String message = ex.toString() + ".\nTry to run this program as Administrator.";
            JOptionPane.showMessageDialog(null, message, "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
        return (char) b[0];
    }

     /**
     * This method writes one byte as a char at <code>PortNo</code> position within <code>file</code>.
     * @param file File to write to.
     * @param PortNo Offset from the beginning of the file.
     * @param Value Character to write.
     * @exception IOException
     */
    public synchronized static void WriteByte(String file, int PortNo, char Value)
    {
        File f = new File(file);
        RandomAccessFile raf = null;
        try {
            raf = new RandomAccessFile(f, "rw");
            raf.seek(PortNo);
            raf.writeByte(Value);
            raf.close();
        } catch (FileNotFoundException ex) {
            String message = ex.toString() + ".\nTry to run this program as Administrator.";
            JOptionPane.showMessageDialog(null, message, "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }

    /**
     * This method gets the value of the XML tag passed as argument.
     * @param tag Tag whose value we're looking for.
     * @return The value of the tag passed as argument
     * @exception ParserConfigurationException
     * @exception SAXException
     * @exception IOException
     */
    public static String GetXMLValueOf(String tag)
    {
        File file = new File(XMLFile);
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db;
        Document doc = null;
        String ret = "";
        try {
            db = dbf.newDocumentBuilder();
            doc = (Document) db.parse(file);
            ret = doc.getElementsByTagName(tag).item(0).getChildNodes().item(0).getNodeValue();
        } catch (ParserConfigurationException ex) {
            JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        } catch (SAXException ex) {
            JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        } catch (NullPointerException e) {}
        return ret;
    }

    /**
     * This method sets the value of the XML tag passed as argument.
     * @param tag Tag whose value we want to set.
     * @param value Value we want to set for the tag.
     * @exception ParserConfigurationException
     * @exception SAXException
     * @exception IOException
     * @exception TransformerConfigurationException
     */
    public static void SetXMLValueOf(String tag, String value)
    {
        File file = new File(XMLFile);
        RandomAccessFile raf = null;
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db;
        Document doc = null;
        Transformer transformer = null;
        try {
            db = dbf.newDocumentBuilder();
            doc = (Document) db.parse(file);
        } catch (ParserConfigurationException ex) {
            JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        } catch (SAXException ex) {
            JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
       }
       doc.getElementsByTagName(tag).item(0).getChildNodes().item(0).setNodeValue(value);

        try {
            transformer = TransformerFactory.newInstance().newTransformer();
        } catch (TransformerConfigurationException ex) {
            JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        StreamResult result = new StreamResult(new StringWriter());
        DOMSource source = new DOMSource(doc);
        
        try {
            transformer.transform(source, result);
            raf = new RandomAccessFile(file, "rw");
            raf.writeBytes(result.getWriter().toString());
            raf.close();
        } catch (TransformerException ex) {
            JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }

    /**
     * This method sends an object InterruptRequest to the PIC8259 through a socket.
     * @param IRQId Line of interrupt within the 8259 where the IRQ is sent.
     * @see InterruptRequest
     * @exception Exception
     */
    public static void SendInterrupt(int IRQId)
    {
        if(PortNo <= 0 || PortNo > 65535){
            JOptionPane.showMessageDialog(null, "Invalid port: " + PortNo + ".", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            Socket s = new Socket("localhost", PortNo);
            ObjectOutputStream ois = new ObjectOutputStream(s.getOutputStream());
            ois.writeObject(new InterruptRequest(IRQId, "8255"));
            ois.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,
                                          "Unable to find PIC 8259 on port " + PortNo + ". No interrupt sent.",
                                          "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    public static int GetPort() { return PortNo; }
    public static void SetPort(int port) { PortNo = port; }

    private final static String XMLFile = "configP.xml";
    private static int PortNo;
}
