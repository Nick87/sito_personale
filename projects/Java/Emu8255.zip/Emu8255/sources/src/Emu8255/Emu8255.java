/* Eemu - 8255 peripheral extension for emu8086
 * Copyright (C) <2011>  <Nicola Alessandro Domingo>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package Emu8255;

import java.awt.Cursor;
import java.awt.TrayIcon.MessageType;
import java.io.File;
import java.net.Socket;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * This is the main class of the application.
 * It creates the main frame and contains the bulk of the application logic for the Emu8255.
 * @author Nicola
 */
public class Emu8255
{
    /**
     * Default constructor.
     */
    public Emu8255()
    {
        ControlWord = 0;
        GroupAMode = -1;
        GroupBMode = -1;
        GroupAInInt = -1;
        GroupAOutInt = -1;
        GroupBInInt = -1;
        GroupBOutInt = -1;
        PortADir = -1;
        PortBDir = -1;
        PortCUpDir = -1;
        PortCLoDir = -1;
        PC45Dir = -1;
        PC67Dir = -1;
        OutputMode = Ascii;
        InputMode = Ascii;
        UseWith8259 = UseWith8259Default;
    }

     /**
     * main() method.
     *
     * Here is where the main frame is allocated, the port to use in order to
     * communicate with the Emu8259 is read from the config file, the two auxiliary
     * threads are created and started.<br>
     * One thread checks for a change in the control word, one thread checks when
     * a new value is written to a port.
     *
     * @see CheckControlWord
     * @see OutputThread
     */
    public static void main(String args[]) throws InterruptedException
    {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException ex) {
        } catch (InstantiationException ex) {
        } catch (IllegalAccessException ex) {
        } catch (UnsupportedLookAndFeelException ex) {}

        //Let's check is config file is present
        if(!new File(XMLFile).exists())
        {
            JOptionPane.showMessageDialog(GUI, "Configuration file not found (" + XMLFile + "). Program will now exit.",
                                          "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
        
        //Let's check if another instance of the application is already running
        /*File LockFile = new File(LockFilePath);
        if(!LockFile.exists())
        {
            try {
                RandomAccessFile raf = new RandomAccessFile(LockFile, "rw");
                raf.writeBytes("Delete this file just in case Emu8255 did not exit gracefully.\n");
                raf.close();
                LockFile.deleteOnExit();
            } catch (IOException ex){
                JOptionPane.showMessageDialog(GUI, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
                System.exit(1);
            }
        }else{
            String message = "Another instance of Emu8255 is already running.\n";
            message += "Program will now exit.";
            JOptionPane.showMessageDialog(GUI, message, "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }*/

        //Let's clear the content of both files at locations that due to us (emu8086.io, emu8086.hw)
        File f1 = new File(IO_FILE);
        File f2 = new File(HW_FILE);
        for(int i = 0; i < 4; i++){
            IO.WriteByte(IO_FILE, BASE+i, (char) 0);
            IO.WriteByte(HW_FILE, 36+i, (char) 0);
        }

        final Emu8255 Main = new Emu8255();

        GUI = new Emu8255GUI(Main, "Emu8255", UseWith8259Default);
        GUI.setVisible(true);

        if(UseWith8259Default){
            GUI.setCursor(new Cursor(Cursor.WAIT_CURSOR));
            Set8259RuntimePort();
            GUI.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        }

        //Let's create our threads
        CWThread = new CheckControlWord(Main, GUI, READ_FROM_FILE_INTERVAL);
        OutThread = new OutputThread(Main, GUI, READ_FROM_FILE_INTERVAL);
        //Let's start everything
        CWThread.start();
        OutThread.start();
    }

    /**
     * Set the control word and update ports status.
     * @param val Control Word to set.
     */
    public void SetControlWord(char val){
        ControlWord = val;
        UpdateControlWordAndPortStatus();
    }
    /**
     * Returns the value of the Control Word as a char.
     * @return The control word value.
     */
    public char GetControlWord() { return ControlWord; }
    /**
     * Returns the group A mode.
     * Mode 2 is not implemented here.
     * @return The group A mode (0, 1, 2).
     */
    public int GetGroupAMode() { return GroupAMode; }
    /**
     * Returns the group B mode.
     * @return The group A mode (0, 1).
     */
    public int GetGroupBMode() { return GroupBMode; }
    /**
     * Returns the value for the group A input interrupt.
     * @return Group A input interrupt (Enabled, Disabled);
     */
    public int GetGroupAInInt() { return GroupAInInt; }
    /**
     * Returns the value for the group A output interrupt.
     * @return Group A output interrupt (Enabled, Disabled);
     */
    public int GetGroupAOutInt() { return GroupAOutInt; }
    /**
     * Returns the value for the group B input interrupt.
     * @return Group B input interrupt (Enabled, Disabled);
     */
    public int GetGroupBInInt() { return GroupBInInt; }
    /**
     * Returns the value for the group B output interrupt.
     * @return Group B output interrupt (Enabled, Disabled);
     */
    public int GetGroupBOutInt() { return GroupBOutInt; }
    /**
     * Returns the value for the port A direction.
     * @return Port A direction (Input, Output);
     */
    public int GetPortADir() { return PortADir; }
    /**
     * Returns the value for the port B direction.
     * @return Port B direction (Input, Output);
     */
    public int GetPortBDir() { return PortBDir; }
    /**
     * Returns the value for the port C Upper direction.
     * @return Port C Upper direction (Input, Output);
     */
    public int GetPortCUpDir() { return PortCUpDir; }
    /**
     * Returns the value for the port C Lower direction.
     * @return Port C Lower direction (Input, Output);
     */
    public int GetPortCLoDir() { return PortCLoDir; }
    /**
     * Returns the value for PC4 and PC5 direction when group A is in mode 1.
     * @return PC4 and PC5 direction (Input, Output);
     */
    public int GetPC45Dir() { return PC45Dir; }
    /**
     * Returns the value for PC6 and PC7 direction when group A is in mode 1.
     * @return PC4 and PC5 direction (Input, Output);
     */
    public int GetPC67Dir() { return PC67Dir; }
    /**
     * Returns the value for the input mode.
     * @return Input mode (Ascii, Binary, Hexadecimal);
     */
    public int GetInputMode() { return InputMode; }
    /**
     * Returns the value for the output mode.
     * @return Output mode (Ascii, Binary, Hexadecimal);
     */
    public int GetOutputMode() { return OutputMode; }

    /**
     * Exit application with status <code>code></code>.
     * @param status Exit status.
     */
    public void Exit(int status) { System.exit(status); }

    /**
     * Handler invoked when a new selection is made in the
     * UseWith8259 submenu in menu File.
     * @param val true if we want to use the Emu8259, false otherwise.
     */
    public void UseWith8259ActionPerformedHandler(boolean val)
    {
        if(val)
        {
            if(!Set8259RuntimePort())
                return;
        }else{
            UseWith8259 = val;
            GUI.UseWith8259(val);
        }
    }

    /**
     * This method reads from the config file the port associated with the Emu8259,
     * wich is supposed to be already written by the Emu8259 itself.
     */
    public static boolean Set8259RuntimePort()
    {
        GUI.GetSystemTray().Notify("Info", "Reading configuration file...", MessageType.INFO);
        String StrPort = IO.GetXMLValueOf("porta");
        int port = Integer.parseInt(StrPort);
        if(port <= 0 || port > 65535)
        {
            String message = "Invalid port (" + port + "). Standalone mode set.\n";
            message += "Press reset or select \"File -> Use With PIC 8259 -> Yes\" from menu to check again.";
            JOptionPane.showMessageDialog(GUI, message, "Error", JOptionPane.ERROR_MESSAGE);
            IO.SetPort(-1);
            UseWith8259 = false;
            GUI.UseWith8259(false);
            GUI.UseWith8259SetText("*");
            return false;
        }
        
        try
        {
            Socket s = new Socket("localhost", port);
            IO.SetPort(port);
            UseWith8259 = true;
            GUI.UseWith8259(true);
            GUI.UseWith8259SetText(StrPort);
            return true;
        }
        catch (Exception ex)
        {
            String message = "Unable to find PIC 8259 on port " + port + ". Standalone mode set.\n";
            message += "Press reset or select \"File -> Use With PIC 8259 -> Yes\" from menu to check again.";
            JOptionPane.showMessageDialog(GUI, message, "Info", JOptionPane.INFORMATION_MESSAGE);
            IO.SetPort(-1);
            UseWith8259 = false;
            GUI.UseWith8259(false);
            GUI.UseWith8259SetText("*");
            return false;
        }
    }

    /**
     * Handler invoked when the Ascii Input Mode is chosen from the menu.
     */
    public void InputModeAsciiActionPerformedHandler()
    {
        GUI.InputModeAsciiSetSelected(true);
        GUI.InputModeBinarySetSelected(false);
        GUI.InputModeHexadecimalSetSelected(false);
        GUI.InputModeIntegerSignedSetSelected(false);
        GUI.InputModeIntegerUnsignedSetSelected(false);
        InputMode = Ascii;
        if(PortADir == Input){
            GUI.SetText('A', "");
            GUI.SetTooltipText('A', PortADir, InputMode);
        }
        if(PortBDir == Input){
            GUI.SetText('B', "");
            GUI.SetTooltipText('B', PortBDir, InputMode);
        }
    }

    /**
     * Handler invoked when the Binary Input Mode is chosen from the menu.
     */
    public void InputModeBinaryActionPerformedHandler()
    {
        GUI.InputModeAsciiSetSelected(false);
        GUI.InputModeBinarySetSelected(true);
        GUI.InputModeHexadecimalSetSelected(false);
        GUI.InputModeIntegerSignedSetSelected(false);
        GUI.InputModeIntegerUnsignedSetSelected(false);
        InputMode = Binary;
        if(PortADir == Input){
            GUI.SetText('A', "");
            GUI.SetTooltipText('A', PortADir, InputMode);
        }
        if(PortBDir == Input){
            GUI.SetText('B', "");
            GUI.SetTooltipText('B', PortBDir, InputMode);
        }
    }

    /**
     * Handler invoked when the Hexadecimal Input Mode is chosen from the menu.
     */
    public void InputModeHexadecimalActionPerformedHandler()
    {
        GUI.InputModeAsciiSetSelected(false);
        GUI.InputModeBinarySetSelected(false);
        GUI.InputModeHexadecimalSetSelected(true);
        GUI.InputModeIntegerSignedSetSelected(false);
        GUI.InputModeIntegerUnsignedSetSelected(false);
        InputMode = Hexadecimal;
        if(PortADir == Input){
            GUI.SetText('A', "");
            GUI.SetTooltipText('A', PortADir, InputMode);
        }
        if(PortBDir == Input){
            GUI.SetText('B', "");
            GUI.SetTooltipText('B', PortBDir, InputMode);
        }
    }

    /**
     * Handler invoked when the Integer Signed Input Mode is chosen from the menu.
     */
    public void InputModeIntegerSignedActionPerformedHandler()
    {
        GUI.InputModeAsciiSetSelected(false);
        GUI.InputModeBinarySetSelected(false);
        GUI.InputModeHexadecimalSetSelected(false);
        GUI.InputModeIntegerSignedSetSelected(true);
        GUI.InputModeIntegerUnsignedSetSelected(false);
        InputMode = IntegerSigned;
        if(PortADir == Input){
            GUI.SetText('A', "");
            GUI.SetTooltipText('A', PortADir, InputMode);
        }
        if(PortBDir == Input){
            GUI.SetText('B', "");
            GUI.SetTooltipText('B', PortBDir, InputMode);
        }
    }

    /**
     * Handler invoked when the Integer Unsigned Input Mode is chosen from the menu.
     */
    public void InputModeIntegerUnsignedActionPerformedHandler()
    {
        GUI.InputModeAsciiSetSelected(false);
        GUI.InputModeBinarySetSelected(false);
        GUI.InputModeHexadecimalSetSelected(false);
        GUI.InputModeIntegerSignedSetSelected(false);
        GUI.InputModeIntegerUnsignedSetSelected(true);
        InputMode = IntegerUnsigned;
        if(PortADir == Input){
            GUI.SetText('A', "");
            GUI.SetTooltipText('A', PortADir, InputMode);
        }
        if(PortBDir == Input){
            GUI.SetText('B', "");
            GUI.SetTooltipText('B', PortBDir, InputMode);
        }
    }

    /**
     * Handler invoked when the Ascii Output Mode is chosen from the menu.
     */
    public void OutputModeAsciiActionPerformedHandler()
    {
        UpdateOutputTextFields(OutputMode, Ascii);
        OutputMode = Ascii;
        GUI.OutputModeAsciiSetSelected(true);
        GUI.OutputModeBinarySetSelected(false);
        GUI.OutputModeHexadecimalSetSelected(false);
        GUI.OutputModeIntegerSignedSetSelected(false);
        GUI.OutputModeIntegerUnsignedSetSelected(false);
        if(PortADir == Output)
            GUI.SetTooltipText('A', PortADir, OutputMode);
        if(PortBDir == Output)
            GUI.SetTooltipText('B', PortBDir, OutputMode);
    }

    /**
     * Handler invoked when the Binary Output Mode is chosen from the menu.
     */
    public void OutputModeBinaryActionPerformedHandler()
    {
        UpdateOutputTextFields(OutputMode, Binary);
        OutputMode = Binary;
        GUI.OutputModeAsciiSetSelected(false);
        GUI.OutputModeHexadecimalSetSelected(false);
        GUI.OutputModeBinarySetSelected(true);
        GUI.OutputModeIntegerSignedSetSelected(false);
        GUI.OutputModeIntegerUnsignedSetSelected(false);
        if(PortADir == Output)
            GUI.SetTooltipText('A', PortADir, OutputMode);
        if(PortBDir == Output)
            GUI.SetTooltipText('B', PortBDir, OutputMode);
    }

    /**
     * Handler invoked when the Hexadecimal Output Mode is chosen from the menu.
     */
    public void OutputModeHexadecimalActionPerformedHandler()
    {
        UpdateOutputTextFields(OutputMode, Hexadecimal);
        OutputMode = Hexadecimal;
        GUI.OutputModeAsciiSetSelected(false);
        GUI.OutputModeBinarySetSelected(false);
        GUI.OutputModeHexadecimalSetSelected(true);
        GUI.OutputModeIntegerSignedSetSelected(false);
        GUI.OutputModeIntegerUnsignedSetSelected(false);
        if(PortADir == Output)
            GUI.SetTooltipText('A', PortADir, OutputMode);
        if(PortBDir == Output)
            GUI.SetTooltipText('B', PortBDir, OutputMode);
    }

    /**
     * Handler invoked when the Integer Signed Output Mode is chosen from the menu.
     */
    public void OutputModeIntegerSignedActionPerformedHandler()
    {
        UpdateOutputTextFields(OutputMode, IntegerSigned);
        OutputMode = IntegerSigned;
        GUI.OutputModeAsciiSetSelected(false);
        GUI.OutputModeBinarySetSelected(false);
        GUI.OutputModeHexadecimalSetSelected(false);
        GUI.OutputModeIntegerSignedSetSelected(true);
        GUI.OutputModeIntegerUnsignedSetSelected(false);
        if(PortADir == Output)
            GUI.SetTooltipText('A', PortADir, OutputMode);
        if(PortBDir == Output)
            GUI.SetTooltipText('B', PortBDir, OutputMode);
    }

    /**
     * Handler invoked when the Integer unsigned Output Mode is chosen from the menu.
     */
    public void OutputModeIntegerUnsignedActionPerformedHandler()
    {
        UpdateOutputTextFields(OutputMode, IntegerUnsigned);
        OutputMode = IntegerUnsigned;
        GUI.OutputModeAsciiSetSelected(false);
        GUI.OutputModeBinarySetSelected(false);
        GUI.OutputModeHexadecimalSetSelected(false);
        GUI.OutputModeIntegerSignedSetSelected(false);
        GUI.OutputModeIntegerUnsignedSetSelected(true);
        if(PortADir == Output)
            GUI.SetTooltipText('A', PortADir, OutputMode);
        if(PortBDir == Output)
            GUI.SetTooltipText('B', PortBDir, OutputMode);
    }

    /**
     * Handler invoked when the Strobe on Porta A button is pressed.
     */
    public void STBPortAButtonActionPerformedHandler()
    {
        if(PortADir != Input || GroupAMode != 1) return;

        if(((InputMode == Ascii && GUI.GetText('A').length() != 1) ||
            (InputMode == Binary && GUI.GetText('A').length() != 8) ||
            (InputMode == Hexadecimal && GUI.GetText('A').length() != 2) ||
            (InputMode == IntegerSigned && !IsADecimalValue(GUI.GetText('A'), IntegerSigned)) ||
            (InputMode == IntegerUnsigned && !IsADecimalValue(GUI.GetText('A'), IntegerUnsigned))) && PortADir == Input)
        {
            GUI.SetText('A', "");
            return;
        }

        char val = 0;

        if(InputMode == Ascii && GUI.GetText('A').length() == 1){
            val = GUI.GetText('A').charAt(0);
        }else if(InputMode == Binary && GUI.GetText('A').length() == 8){
            String str = GUI.GetText('A');
            for(int i = 0; i < 8; i++)
                if(str.charAt(i) == '1')
                    val |= (1 << (7-i));
        }else if(InputMode == Hexadecimal && GUI.GetText('A').length() == 2){
            char msn = GUI.GetText('A').charAt(0);
            char lsn = GUI.GetText('A').charAt(1);
            if(lsn >= '0' && lsn <= '9')
                val |= lsn-'0';
            else if(lsn >= 'a' && lsn <= 'f')
                val |= lsn-87;
            else if(lsn >= 'A' && lsn <= 'F')
                val |= lsn-55;
            if(msn >= '0' && msn <= '9')
                val |= (msn-'0')<<4;
            else if(msn >= 'a' && msn <= 'f')
                val |= (msn-87)<<4;
            else if(msn >= 'A' && msn <= 'F')
                val |= (msn-55)<<4;
        }else if((InputMode == IntegerSigned && IsADecimalValue(GUI.GetText('A'), IntegerSigned)) ||
                 (InputMode == IntegerUnsigned && IsADecimalValue(GUI.GetText('A'), IntegerUnsigned))){
            val = GetCharValueFromString(GUI.GetText('A'));
        }
        else return;

        //Write value to port A for application to read it
        IO.WriteByte(IO_FILE, BASE, val);

        //Clear STBa = PC4 = 0
        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xEF));
        //GUI.SetText('4', "0");

        /*try {
            Thread.sleep(100);
        } catch (InterruptedException ex) {}*/

        //Set IBFa = PC5 = 1
        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x20));
        //GUI.SetText('5', "1");
        //Set STBa = PC4 = 1
        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x10));
        //GUI.SetText('4', "1");

        /*try {
            Thread.sleep(200);
        } catch (InterruptedException ex) {}*/

        if(GroupAInInt == Enabled)
        {
            //Interrupt
            if(UseWith8259)
                IO.SendInterrupt(7);
            else
                IO.WriteByte(HW_FILE, 39, (char) 1);
            
            //GUI.SetText('3', "1");

            /*try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {}*/

            //PC3 on file cleared by emu8086
            //GUI.SetText('3', "0");
        }

        /*try {
            Thread.sleep(200);
        } catch (InterruptedException ex) {}*/

        //Clear IBFa = PC5 = 0
        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xDF));
        //GUI.SetText('5', "0");
    }

    /**
     * Handler invoked when the Strobe on Porta B button is pressed.
     */
    public void STBPortBButtonActionPerformedHandler()
    {
        if(PortBDir != Input || GroupBMode != 1) return;

        if(((InputMode == Ascii && GUI.GetText('B').length() != 1) ||
            (InputMode == Binary && GUI.GetText('B').length() != 8) ||
            (InputMode == Hexadecimal && GUI.GetText('B').length() != 2) ||
            (InputMode == IntegerSigned && !IsADecimalValue(GUI.GetText('B'), IntegerSigned)) ||
            (InputMode == IntegerUnsigned && !IsADecimalValue(GUI.GetText('B'), IntegerUnsigned))) && PortBDir == Input)
        {
            GUI.SetText('B', "");
            return;
        }
        char val = 0;

        if(InputMode == Ascii && GUI.GetText('B').length() == 1){
            val = GUI.GetText('B').charAt(0);
        }else if(InputMode == Binary && GUI.GetText('B').length() == 8){
            String str = GUI.GetText('B');
            for(int i = 0; i < 8; i++)
                if(str.charAt(i) == '1')
                    val |= (1 << (7-i));
        }else if(InputMode == Hexadecimal && GUI.GetText('B').length() == 2){
            char msn = GUI.GetText('B').charAt(0);
            char lsn = GUI.GetText('B').charAt(1);
            if(lsn >= '0' && lsn <= '9')
                val |= lsn-'0';
            else if(lsn >= 'a' && lsn <= 'f')
                val |= lsn-87;
            else if(lsn >= 'A' && lsn <= 'F')
                val |= lsn-55;
            if(msn >= '0' && msn <= '9')
                val |= (msn-'0')<<4;
            else if(msn >= 'a' && msn <= 'f')
                val |= (msn-87)<<4;
            else if(msn >= 'A' && msn <= 'F')
                val |= (msn-55)<<4;
        }else if((InputMode == IntegerSigned && IsADecimalValue(GUI.GetText('B'), IntegerSigned)) ||
                 (InputMode == IntegerUnsigned && IsADecimalValue(GUI.GetText('B'), IntegerUnsigned))){
            val = GetCharValueFromString(GUI.GetText('B'));
        }
        else return;

        //Write value to port B for application to read it
        IO.WriteByte(IO_FILE, BASE+1, val);

        //Clear STBb = PC2 = 0
        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xFB));
        //GUI.SetText('2', "0");

        /*try {
            Thread.sleep(100);
        } catch (InterruptedException ex) {}*/

        //Set IBFb = PC1 = 1
        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x02));
        //GUI.SetText('1', "1");
        //Set STBb = PC2 = 1
        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x04));
        //GUI.SetText('2', "1");

        /*try {
            Thread.sleep(200);
        } catch (InterruptedException ex) {}*/

        if(GroupBInInt == Enabled)
        {
            //Interrupt
            if(UseWith8259)
                IO.SendInterrupt(5);
            else
                IO.WriteByte(HW_FILE, 37, (char) 1);
            
            //GUI.SetText('0', "1");

            /*try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {}*/

            //PC0 on file should be cleared by emu8086
            //GUI.SetText('0', "0");
        }

        //Clear IBFa = PC1 = 0
        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xFD));
        //GUI.SetText('1', "0");
    }

    /**
     * Handler invoked when the Ack on Porta A button is pressed.
     */
    public void ACKPortAButtonActionPerformedHandler()
    {
        if(PortADir != Output || GroupAMode != 1) return;

        //A questo punto PC3 = 1, PC6 = PC7 = 0 da output thread
        //Set ACKa = PC6 = 1
        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x40));
        //GUI.SetText('6', "1");
        //Set OBFa = PC7 = 1
        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x80));
        //GUI.SetText('7', "1");

        if(GroupAOutInt == Enabled)
        {
            /*try {
                Thread.sleep(200);
            } catch (InterruptedException ex) {}*/

            //Interrupt thrown now, on the falling edge, and PC3 goes low
            if(UseWith8259)
                IO.SendInterrupt(6);
            else
                IO.WriteByte(HW_FILE, 38, (char) 1);
            
            //GUI.SetText('3', "0");
        }
        RestoreTextFieldAndButtonState();
    }

    /**
     * Handler invoked when the Ack on Porta B button is pressed.
     */
    public void ACKPortBButtonActionPerformedHandler()
    {
        if(PortBDir != Output || GroupBMode != 1) return;

        //A questo punto PC0 = 1, PC1 = PC2 = 0 da output thread
        //Set ACKb = PC2 = 1
        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x04));
        //GUI.SetText('2', "1");
        //Set OBFb = PC1 = 1
        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x02));
        //GUI.SetText('1', "1");

        if(GroupBOutInt == Enabled)
        {
            /*try {
                Thread.sleep(200);
            } catch (InterruptedException ex) {}*/

            //Interrupt thrown now, on the falling edge, and PC0 goes low
            if(UseWith8259)
                IO.SendInterrupt(4);
            else
                IO.WriteByte(HW_FILE, 36, (char) 1);
            
            //GUI.SetText('0', "0");
        }
        RestoreTextFieldAndButtonState();
    }

    /*
     * In complemento a 2, con n bit posso rappresentare
     * numeri compresi nel range: -2^(n-1) <-> 2^(n-1) -1.
     * Nel nostro caso n = 8, quindi i valori ammessi vanno
     * da -128 a 127 per i signed, da 0 a 255 per gli unsigned
     */
    private boolean IsADecimalValue(String number, int SignedUnsigned)
    {
        if(number.length() == 0)                           return false;
        if(number.charAt(0) == '-' && number.length() > 4) return false;
        if(number.charAt(0) != '-' && number.length() > 3) return false;

        boolean isNegative;
        int value;

        //Se c'è '-' come primo carattere, non ce ne devono essere altri
        if(number.charAt(0) == '-'){
            if(number.charAt(1) == '0') return false; //Uno zero dopo il meno non ha senso
            for(int i = 1; i < number.length(); i++)
                if(number.charAt(i) < '0' || number.charAt(i) > '9')
                    return false;
            isNegative = true;
        }else{
            if(number.charAt(0) == '0') return false; //Uno zero come prima cifra non ha senso
            //Se non c'è '-' come primo carattere, non ci deve essere nessun '-'
            for(int i = 0; i < number.length(); i++)
                if(number.charAt(i) < '0' || number.charAt(i) > '9')
                    return false;
            isNegative = false;
        }

        if(isNegative && SignedUnsigned == IntegerUnsigned) return false;

        //Prendo il modulo del numero
        if(isNegative) value = Integer.parseInt(number.substring(1));
        else           value = Integer.parseInt(number);
        //e controllo che non esca fuori dal range
        if(SignedUnsigned == IntegerUnsigned){
            if(value > 255) return false;
            else            return true;
        }else{
            if(isNegative){
                if(value > 128) return false;
                else            return true;
            }else{
                if(value > 127) return false;
                else            return true;
            }
        }
    }

    /**
     * This method returns the char representation of a number in the form of a string
     * @param number The string representing the value.
     * @return THe char representation.
     */
    public char GetCharValueFromString(String number)
    {
        int temp;
        char val = 0;
        boolean isNegative = (number.charAt(0) == '-') ? true : false;

        //Prendo il modulo del numero
        if(isNegative) temp = Integer.parseInt(number.substring(1));
        else           temp = Integer.parseInt(number);

        val = (char) ((char) temp & 0xff);

        if(isNegative){
            val ^= 0xff;
            val++;
            val &= 0xff;
        }
        return val;
    }

    /**
     * This method returns the signed integer representation of the char value passed as argument
     * @param signed_number The signed char to convert
     * @return The integer representation of the char.
     */
    public int GetSignedIntegerFromChar(char signed_number)
    {
        int intValue = 0;
        boolean isNegative;

        int val = signed_number&0x80; 
        if(val == 0x80)
            isNegative = true;
        else
            isNegative = false;

        if(!isNegative)
            return GetUnsignedIntegerFromChar(signed_number);
        else
        {
            char temp = (char) (signed_number^0xff);
            temp &= 0xff;
            temp++;
            return -GetUnsignedIntegerFromChar(temp);
        }
    }

    /**
     * This method returns the unsigned integer representation of the char value passed as argument
     * @param unsigned_number The unsigned char to convert
     * @return The integer representation of the char.
     */
    public int GetUnsignedIntegerFromChar(char unsigned_number)
    {
        int val = 0;
        for(int i = 0; i < 8; i++)
            if(((unsigned_number&(1 << i)) >> i) == 1)
                val += Power(2, i);
        return val;
    }

    private int Power(int base, int exp)
    {
        if(exp == 0) return 1;

        int val = base;
        while(--exp > 0)
            val *= base;
        return val;
    }

    /**
     * Handler invoked the reset button is pressed.
     */
    public void ResetButtonActionPerformedHandler()
    {                                            
        File f1 = new File(IO_FILE);
        File f2 = new File(HW_FILE);
        for(int i = 0; i < f1.length(); i++)
            IO.WriteByte(IO_FILE, i, (char) 0);
        for(int i = 0; i < f2.length(); i++)
            IO.WriteByte(HW_FILE, i, (char) 0);

        ControlWord = 0;
        GroupAMode = -1;
        GroupBMode = -1;
        GroupAInInt = -1;
        GroupAOutInt = -1;
        GroupBInInt = -1;
        GroupBOutInt = -1;
        PortADir = -1;
        PortBDir = -1;
        PortCUpDir = -1;
        PortCLoDir = -1;
        PC45Dir = -1;
        PC67Dir = -1;
        GUI.SetEditable('A', false);
        GUI.SetText('A', "");
        GUI.SetEditable('B', false);
        GUI.SetText('B', "");
        GUI.SetEditable('C', false);
        GUI.SetText('C', "");
        GUI.CUpIntSetText(" ");
        GUI.CLoIntSetText(" ");
        GUI.GroupAModeLabelSetText(" ");
        GUI.GroupBModeLabelSetText(" ");
        GUI.SetText('0', "0");
        GUI.SetText('1', "0");
        GUI.SetText('2', "0");
        GUI.SetText('3', "0");
        GUI.SetText('4', "0");
        GUI.SetText('5', "0");
        GUI.SetText('6', "0");
        GUI.SetText('7', "0");
        GUI.SetEditable('0', false);
        GUI.SetEditable('1', false);
        GUI.SetEditable('2', false);
        GUI.SetEditable('3', false);
        GUI.SetEditable('4', false);
        GUI.SetEditable('5', false);
        GUI.SetEditable('6', false);
        GUI.SetEditable('7', false);
        GUI.OutputModeAsciiSetSelected(true);
        GUI.OutputModeBinarySetSelected(false);
        GUI.OutputModeHexadecimalSetSelected(false);
        GUI.OutputModeIntegerSignedSetSelected(false);
        GUI.OutputModeIntegerUnsignedSetSelected(false);
        GUI.InputModeAsciiSetSelected(true);
        GUI.InputModeBinarySetSelected(false);
        GUI.InputModeHexadecimalSetSelected(false);
        GUI.InputModeIntegerSignedSetSelected(false);
        GUI.InputModeIntegerUnsignedSetSelected(false);
        GUI.STBPortAButtonSetEnabled(false);
        GUI.STBPortBButtonSetEnabled(false);
        GUI.ACKPortAButtonSetEnabled(false);
        GUI.ACKPortBButtonSetEnabled(false);
        OutputMode = Ascii;
        InputMode = Ascii;
        GUI.SetTooltipText('A', -1, -1);
        GUI.SetTooltipText('B', -1, -1);
        GUI.SetTooltipText('0', "PC0");
        GUI.SetTooltipText('1', "PC1");
        GUI.SetTooltipText('2', "PC2");
        GUI.SetTooltipText('3', "PC3");
        GUI.SetTooltipText('4', "PC4");
        GUI.SetTooltipText('5', "PC5");
        GUI.SetTooltipText('6', "PC6");
        GUI.SetTooltipText('7', "PC7");
        UseWith8259 = UseWith8259Default;
        GUI.UseWith8259(UseWith8259Default);
        if(UseWith8259Default) Set8259RuntimePort();
    }

    /**
     * Handler invoked when a mode 2 is detected by the application.
     */
    private void ResetAfterMode2Detection()
    {
        File f1 = new File(IO_FILE);
        File f2 = new File(HW_FILE);
        for(int i = 0; i < f1.length(); i++)
            IO.WriteByte(IO_FILE, i, (char) 0);
        for(int i = 0; i < f2.length(); i++)
            IO.WriteByte(HW_FILE, i, (char) 0);

        ControlWord = 0;
        GroupAMode = -1;
        GroupBMode = -1;
        GroupAInInt = -1;
        GroupAOutInt = -1;
        GroupBInInt = -1;
        GroupBOutInt = -1;
        PortADir = -1;
        PortBDir = -1;
        PortCUpDir = -1;
        PortCLoDir = -1;
        PC45Dir = -1;
        PC67Dir = -1;
        GUI.SetEditable('A', false);
        GUI.SetText('A', "");
        GUI.SetEditable('B', false);
        GUI.SetText('B', "");
        GUI.CUpIntSetText(" ");
        GUI.CLoIntSetText(" ");
        GUI.SetText('0', "0");
        GUI.SetText('1', "0");
        GUI.SetText('2', "0");
        GUI.SetText('3', "0");
        GUI.SetText('4', "0");
        GUI.SetText('5', "0");
        GUI.SetText('6', "0");
        GUI.SetText('7', "0");
        GUI.SetEditable('0', false);
        GUI.SetEditable('1', false);
        GUI.SetEditable('2', false);
        GUI.SetEditable('3', false);
        GUI.SetEditable('4', false);
        GUI.SetEditable('5', false);
        GUI.SetEditable('6', false);
        GUI.SetEditable('7', false);
        GUI.OutputModeAsciiSetSelected(true);
        GUI.OutputModeBinarySetSelected(false);
        GUI.OutputModeHexadecimalSetSelected(false);
        GUI.OutputModeIntegerSignedSetSelected(false);
        GUI.OutputModeIntegerUnsignedSetSelected(false);
        GUI.InputModeAsciiSetSelected(true);
        GUI.InputModeBinarySetSelected(false);
        GUI.InputModeHexadecimalSetSelected(false);
        GUI.InputModeIntegerSignedSetSelected(false);
        GUI.InputModeIntegerUnsignedSetSelected(false);
        GUI.STBPortAButtonSetEnabled(false);
        GUI.STBPortBButtonSetEnabled(false);
        GUI.ACKPortAButtonSetEnabled(false);
        GUI.ACKPortBButtonSetEnabled(false);
        OutputMode = Ascii;
        InputMode = Ascii;
        GUI.SetTooltipText('A', -1, -1);
        GUI.SetTooltipText('B', -1, -1);
        GUI.SetTooltipText('0', "PC0");
        GUI.SetTooltipText('1', "PC1");
        GUI.SetTooltipText('2', "PC2");
        GUI.SetTooltipText('3', "PC3");
        GUI.SetTooltipText('4', "PC4");
        GUI.SetTooltipText('5', "PC5");
        GUI.SetTooltipText('6', "PC6");
        GUI.SetTooltipText('7', "PC7");
        UseWith8259 = UseWith8259Default;
        GUI.UseWith8259(UseWith8259Default);
        if(UseWith8259Default) Set8259RuntimePort();
    }

    /**
     * This method makes the UI wait for an user input.<br>
     * All text fields are non editable, all buttons are disabled
     * except the button Ack corresponding to the port <code>port</code>.
     * @param port Port whose Ack button is the only one enabled.
     */
    public void WaitForAckFromUser(char port)
    {
        GUI.SetEditable('A', false);
        GUI.STBPortAButtonSetEnabled(false);
        if(port == 'A')
            GUI.ACKPortAButtonSetEnabled(true);
        GUI.SetEditable('B', false);
        GUI.STBPortBButtonSetEnabled(false);
        if(port == 'B')
            GUI.ACKPortBButtonSetEnabled(true);
    }

    /**
     * This method restore the state of all Text Fields and buttons
     * after they have been disabled or made non editable waiting for
     * the user to press an Ack button.
     */
    private void RestoreTextFieldAndButtonState()
    {
        if(PortADir == Input)
            GUI.SetEditable('A', true);
        if(GroupAMode == 1 && PortADir == Input)
            GUI.STBPortAButtonSetEnabled(true);
        GUI.ACKPortAButtonSetEnabled(false);
        if(PortBDir == Input)
            GUI.SetEditable('B', true);
        if(GroupBMode == 1 && PortBDir == Input)
            GUI.STBPortBButtonSetEnabled(true);
        GUI.ACKPortBButtonSetEnabled(false);
    }

    /**
     * This method update the text in Text Fields when the Output Mode
     * changes.
     */
    private void UpdateOutputTextFields(int old_mode, int new_mode)
    {
        String str = null;
        for(char TextField = 'A'; TextField <= 'B'; TextField++)
        {
            if((TextField == 'A' && PortADir == Output && GUI.GetText(TextField).length() > 0) ||
               (TextField == 'B' && PortBDir == Output && GUI.GetText(TextField).length() > 0))
            {
                str = GUI.GetText(TextField);
                if(new_mode == Ascii)
                {
                    if(old_mode == Binary){
                        char val = 0;
                        for(int i = 0; i < 8; i++)
                            if(str.charAt(i) == '1')
                                val |= (1 << (7-i));
                        GUI.SetText(TextField, String.valueOf(val));
                    }else if(old_mode == Hexadecimal){
                        GUI.SetText(TextField, String.valueOf((char)Integer.parseInt(str, 16)));
                    }else if(old_mode == IntegerSigned || old_mode == IntegerUnsigned){
                        char val = GetCharValueFromString(str);
                        GUI.SetText(TextField, String.valueOf(val));
                    }
                }
                else if(new_mode == Binary)
                {
                    if(old_mode == Ascii){
                        GUI.SetText(TextField, ToBinaryString(str.charAt(0), 8));
                    }else if(old_mode == Hexadecimal){
                        GUI.SetText(TextField, ToBinaryString((char) Integer.parseInt(str, 16), 8));
                    }else if(old_mode == IntegerSigned || old_mode == IntegerUnsigned){
                        char val = GetCharValueFromString(str);
                        GUI.SetText(TextField, ToBinaryString(val, 8));
                    }
                }
                else if(new_mode == Hexadecimal)
                {
                    if(old_mode == Ascii){
                        GUI.SetText(TextField, Integer.toHexString((int) str.charAt(0)));
                    }else if(old_mode == Binary){
                        char val = 0;
                        for(int i = 0; i < 8; i++)
                            if(str.charAt(i) == '1')
                                val |= (1 << (7-i));
                        GUI.SetText(TextField, Integer.toHexString((int) val));
                    }else if(old_mode == IntegerSigned || old_mode == IntegerUnsigned){
                        char val = GetCharValueFromString(str);
                        GUI.SetText(TextField, Integer.toHexString((int) val));
                    }
                }
                else if(new_mode == IntegerSigned)
                {
                    if(old_mode == Ascii){
                        int val = GetSignedIntegerFromChar(str.charAt(0));
                        GUI.SetText(TextField, String.valueOf(val));
                    }else if(old_mode == Binary){
                        char val = 0;
                        for(int i = 0; i < 8; i++)
                            if(str.charAt(i) == '1')
                                val |= (1 << (7-i));
                        int val2 = GetSignedIntegerFromChar(val);
                        GUI.SetText(TextField, String.valueOf(val2));
                    }else if(old_mode == Hexadecimal){
                        String val = ToBinaryString((char) Integer.parseInt(str, 16), 8);
                        char val2 = 0;
                        for(int i = 0; i < 8; i++)
                            if(val.charAt(i) == '1')
                                val2 |= (1 << (7-i));
                        int val3 = GetSignedIntegerFromChar(val2);
                        GUI.SetText(TextField, String.valueOf(val3));
                    }else if(old_mode == IntegerUnsigned){
                        char val = GetCharValueFromString(str);
                        int val2 = GetSignedIntegerFromChar(val);
                        GUI.SetText(TextField, String.valueOf(val2));
                    }
                }
                else if(new_mode == IntegerUnsigned)
                {
                    if(old_mode == Ascii){
                        int val = GetUnsignedIntegerFromChar(str.charAt(0));
                        GUI.SetText(TextField, String.valueOf(val));
                    }else if(old_mode == Binary){
                        char val = 0;
                        for(int i = 0; i < 8; i++)
                            if(str.charAt(i) == '1')
                                val |= (1 << (7-i));
                        int val2 = GetUnsignedIntegerFromChar(val);
                        GUI.SetText(TextField, String.valueOf(val2));
                    }else if(old_mode == Hexadecimal){
                        String val = ToBinaryString((char) Integer.parseInt(str, 16), 8);
                        char val2 = 0;
                        for(int i = 0; i < 8; i++)
                            if(val.charAt(i) == '1')
                                val2 |= (1 << (7-i));
                        int val3 = GetUnsignedIntegerFromChar(val2);
                        GUI.SetText(TextField, String.valueOf(val3));
                    }else if(old_mode == IntegerSigned){
                        char val = GetCharValueFromString(str);
                        int val2 = GetUnsignedIntegerFromChar(val);
                        GUI.SetText(TextField, String.valueOf(val2));
                    }
                }
            }
        }
    }

    /**
     * This method returns the binary representation of the character <code>value</code>
     * according to the value of <code>padding</code>.
     * @param value Character whose binary representation is returned.
     * @param padding Padding to be applied.
     * @return The binary representation of <code>value</code>.
     */
    public String ToBinaryString(char value, int padding)
    {
        int val = Integer.valueOf(value);
        String str = Integer.toBinaryString(val);
        int len = str.length();
        for(int i = 0; i < padding-len; i++)
            str = "0" + str;
        str = (len > padding) ? str.substring(padding) : str;
        return str;
    }

    private void UpdateControlWordAndPortStatus()
    {
        if(GroupAMode == 2) return;

        int set, CW = Integer.valueOf(ControlWord);
        String str = Integer.toBinaryString(CW);
        int len = str.length();
        if(str.length() > 8)
            str = str.substring(8);
        for(int i = 0; i < 8-len; i++)
            str = "0" + str;
        GUI.SetText('C', str);

        str = "";
        int res = (CW&0x80);
        if(res != 0) //Program Control Word
        {
            // Group A Mode
            str = "Group A Mode ";
            res = (CW&0x60) >> 5;
            if(res == 0){
                str += "0";
                GroupAMode = 0;
            }else if(res == 1){
                str += "1";
                GroupAMode = 1;
            }else{
                str += "2 (Unavailable)";
                GroupAMode = 2;
                GUI.GroupAModeLabelSetText(str);
                GUI.GroupBModeLabelSetText("Reset to continue");
                ResetAfterMode2Detection();
                return;
             }
             GUI.GroupAModeLabelSetText(str);
             str = "";

             //Group B Mode
             str += "Group B Mode ";
             res = (CW&0x04) >> 2;
             if(res == 0){
                 str += "0";
                 GroupBMode = 0;
             }else{
                 str += "1";
                 GroupBMode = 1;
             }
             GUI.GroupBModeLabelSetText(str);
             str = "";

             //Port A Direction
             res = (CW&0x10) >> 4;
             if(res == Input && GroupAMode != 2){
                 GUI.SetEditable('A', true);
                 PortADir = Input;
             }else{
                 GUI.SetEditable('A', false);
                 PortADir = Output;
             }

             //Port B Direction
             res = (CW&0x02) >> 1;
             if(res == Input && GroupAMode != 2){
                 GUI.SetEditable('B', true);
                 PortBDir = Input;
             }else{
                 GUI.SetEditable('B', false);
                 PortBDir = Output;
             }

             //Port C Upper and PC3
            if (GroupAMode == 0) {
                GUI.CUpIntSetText("");
                res = (CW&0x08) >> 3;
                if (res == Output) {
                    PortCUpDir = Output;
                    GUI.SetEditable('4', false);
                    GUI.SetEditable('5', false);
                    GUI.SetEditable('6', false);
                    GUI.SetEditable('7', false);
                } else {
                    PortCUpDir = Input;
                    GUI.SetEditable('4', true);
                    GUI.SetEditable('5', true);
                    GUI.SetEditable('6', true);
                    GUI.SetEditable('7', true);
                }
            }
             else if(GroupAMode == 1)
             {
                 if(PortADir == Input)
                 {
                     GUI.SetEditable('3', false);
                     //GUI.SetText('3', "0"); //INTRa is active high
                     GUI.SetText('3', "I");
                     GUI.SetTooltipText('3', "INTRa");

                     GUI.SetEditable('4', false);
                     //GUI.SetText('4', "1"); //STB is active low
                     GUI.SetText('4', "S");
                     GUI.SetTooltipText('4', "STBa");

                     GUI.SetEditable('5', false);
                     //GUI.SetText('5', "0"); //IBFa is active high
                     GUI.SetText('5', "F");
                     GUI.SetTooltipText('5', "IBFa");
                     
                     res = (CW&0x08) >> 3;
                     if(res == Output){
                         PC67Dir = Output;
                         GUI.SetEditable('6', false);
                         GUI.SetEditable('7', false);
                     }else{
                         PC67Dir = Input;
                         GUI.SetEditable('6', true);
                         GUI.SetEditable('7', true);
                     }
                 }
                 else if(PortADir == Output)
                 {
                     GUI.SetEditable('3', false);
                     //GUI.SetText('3', "0"); //INTRa is active high
                     GUI.SetText('3', "I");
                     GUI.SetTooltipText('3', "INTRa");

                     GUI.SetEditable('6', false);
                     //GUI.SetText('6', "1"); //ACKa is active low
                     GUI.SetText('6', "A");
                     GUI.SetTooltipText('6', "ACKa");

                     GUI.SetEditable('7', false);
                     //GUI.SetText('7', "1"); //OBFa is active low
                     GUI.SetText('7', "O");
                     GUI.SetTooltipText('7', "OBFa");

                     res = (CW&0x08) >> 3;
                     if(res == Output){
                         PC45Dir = Output;
                         GUI.SetEditable('4', false);
                         GUI.SetEditable('5', false);
                     }else{
                         PC45Dir = Input;
                         GUI.SetEditable('4', true);
                         GUI.SetEditable('5', true);
                     }
                 }
             }
             else
             {
                 PortCUpDir = PC67Dir = PC45Dir = -1;
                 GUI.CUpIntSetText("");
             }

             //Port C Lower
            if(GroupBMode == 0)
            {
                 GUI.CUpIntSetText("");
                 res = (CW&0x01);
                 if(res == Output){
                     PortCLoDir = Output;
                     GUI.SetEditable('0', false);
                     GUI.SetEditable('1', false);
                     GUI.SetEditable('2', false);
                     if(GroupAMode != 1)
                         GUI.SetEditable('3', false);
                 }else{
                     PortCLoDir = Input;
                     GUI.SetEditable('0', true);
                     GUI.SetEditable('1', true);
                     GUI.SetEditable('2', true);
                     if(GroupAMode != 1)
                         GUI.SetEditable('3', true);
                 }
            }
            else
            {
                GUI.SetEditable('0', false);
                GUI.SetEditable('1', false);
                GUI.SetEditable('2', false);
                if(PortBDir == Input){
                    //GUI.SetText('0', "0"); //INTRb is active high
                    GUI.SetText('0', "I");
                    GUI.SetTooltipText('0', "INTRb");

                    //GUI.SetText('1', "0"); //IBFb is active high
                    GUI.SetText('1', "F");
                    GUI.SetTooltipText('1', "IBFb");

                    //GUI.SetText('2', "1"); //STBb is active low
                    GUI.SetText('2', "S");
                    GUI.SetTooltipText('3', "STBb");
                }else if(PortBDir == Output){
                    //GUI.SetText('0', "0"); //INTRb is active high
                    GUI.SetText('0', "I");
                    GUI.SetTooltipText('0', "INTRb");

                    //GUI.SetText('1', "1"); //OBFb is active low
                    GUI.SetText('1', "O");
                    GUI.SetTooltipText('1', "OBFb");

                    //GUI.SetText('2', "1"); //ACKb is active low
                    GUI.SetText('2', "A");
                    GUI.SetTooltipText('2', "ACKb");
                }
            }
            if(GroupAMode == 1){
                if(PortADir == Input){
                    GUI.STBPortAButtonSetEnabled(true);
                    GUI.ACKPortAButtonSetEnabled(false);
                }else if (PortADir == Output) {
                    GUI.STBPortAButtonSetEnabled(false);
                    //ACK attivato solo quando viene effettivamente stampato un valore sulla porta
                    //ACKPortAButton.setEnabled(true);
                }
            }else{
                GUI.STBPortAButtonSetEnabled(false);
                GUI.ACKPortAButtonSetEnabled(false);
            }
            if(GroupBMode == 1){
                if(PortBDir == Input){
                    GUI.STBPortBButtonSetEnabled(true);
                    GUI.ACKPortBButtonSetEnabled(false);
                }else if (PortBDir == Output){
                    GUI.STBPortBButtonSetEnabled(false);
                    //ACK attivato solo quando viene effettivamente stampato un valore sulla porta
                    //ACKPortBButton.setEnabled(true);
                }
            }else{
                GUI.STBPortBButtonSetEnabled(false);
                GUI.ACKPortBButtonSetEnabled(false);
            }
            GUI.SetTooltipText('A', PortADir, Ascii);
            GUI.SetTooltipText('B', PortBDir, Ascii);
        }
        else//Single Bit Set/Reset
        {
            res = (CW&0x0E) >> 1;
            set = (CW&0x01);

            if(res == 0 && GroupBMode == 0)
            {
                if(set == 0){
                    GUI.SetText('0', "0");
                    IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xFE));
                }else{
                    GUI.SetText('0', "1");
                    IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x01));
                }
            }
            else if(res == 1 && GroupBMode == 0)
            {
                if(set == 0){
                    GUI.SetText('1', "0");
                    IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xFD));
                }else{
                    GUI.SetText('1', "1");
                    IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x02));
                }
            }
            else if(res == 2)
            {
                if(GroupBMode == 0)
                {
                    if(set == 0){
                        GUI.SetText('2',"0");
                        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xFB));
                    }else{
                        GUI.SetText('2', "1");
                        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x04));
                    }
                }
                else
                {
                    if(PortBDir == Output)
                    {
                        if(set == 1)
                        {
                            GroupBOutInt = Enabled;
                            GUI.CLoIntSetText("INTRb Enabled");
                            PortCLoDir = UsedForInterrupt;
                            //PC2.setText("1");
                            //IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x04));
                        }
                        else
                        {
                            GroupBOutInt = Disabled;
                            GUI.CLoIntSetText("");
                            PortCLoDir = -1;
                            //PC2.setText("0");
                            //IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xFB));
                        }
                    }
                    else if(PortBDir == Input)
                    {
                        if(set == 1)
                        {
                            GroupBInInt = Enabled;
                            GUI.CLoIntSetText("INTRb Enabled");
                            PortCLoDir = UsedForInterrupt;
                            //PC2.setText("1");
                            //IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x04));
                        }
                        else
                        {
                            GroupBInInt = Disabled;
                            GUI.CLoIntSetText("");
                            PortCLoDir = -1;
                            //PC2.setText("0");
                            //IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xFB));
                        }
                    }
                }
            }
            else if(res == 3 && GroupAMode == 0)
            {
                if(set == 0){
                    GUI.SetText('3', "0");
                    IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xF7));
                }else{
                    GUI.SetText('3', "1");
                    IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x08));
                }
            }
            else if(res == 4)
            {
                if(GroupAMode == 0 || (GroupAMode == 1 && PortADir == Output))
                {
                    if(set == 0){
                        GUI.SetText('4', "0");
                        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xEF));
                    }else{
                        GUI.SetText('4', "1");
                        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x10));
                    }
                }
                else if(GroupAMode == 1 && PortADir == Input)
                {
                    if(set == 0)
                    {
                        GroupAInInt = Disabled;
                        GUI.CUpIntSetText("");
                        PortCUpDir = -1;
                        //PC4.setText("0");
                        //IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xEF));
                    }
                    else
                    {
                        GroupAInInt = Enabled;
                        GUI.CUpIntSetText("INTRa Enabled");
                        PortCUpDir = -1;
                        //PC4.setText("1");
                        //IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x10));
                    }
                }
            }
            else if(res == 5 && (GroupAMode == 0 || (GroupAMode == 1 && PortADir == Output)))
            {
                if(set == 0){
                    GUI.SetText('5', "0");
                    IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xDF));
                }else{
                    GUI.SetText('5', "1");
                    IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x20));
                }
            }
            else if(res  == 6)
            {
                if(GroupAMode == 0 || (GroupAMode == 1 && PortADir == Input))
                {
                    if(set == 0){
                        GUI.SetText('6', "0");
                        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xBF));
                    }else{
                        GUI.SetText('6', "1");
                        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x40));
                    }
                }
                else if(GroupAMode == 1 && PortADir == Output)
                {
                    if(PortADir == Output)
                    {
                        if(set == 0)
                        {
                            GroupAOutInt = Disabled;
                            GUI.CUpIntSetText("");
                            PortCUpDir = -1;
                            //PC6.setText("0");
                            //IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xBF));
                        }
                        else
                        {
                            GroupAOutInt = Enabled;
                            GUI.CUpIntSetText("INTRa Enabled");
                            PortCUpDir = -1;
                            //PC6.setText("1");
                            //IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x40));
                        }
                    }
                }
            }
            else if(res == 7 && (GroupAMode == 0 || (GroupAMode == 1 && PortADir == Input)))
            {
                if(set == 0){
                    GUI.SetText('7', "0");
                    IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0x7F));
                }else{
                    GUI.SetText('7', "1");
                    IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)|0x80));
                }
            }
        }
    }
    
    private static Emu8255GUI GUI;
    private char ControlWord;
    private int GroupAMode;
    private int GroupBMode;
    private int GroupAInInt;
    private int GroupAOutInt;
    private int GroupBInInt;
    private int GroupBOutInt;
    private int PortADir;
    private int PortBDir;
    private int PortCUpDir;
    private int PortCLoDir;
    private int OutputMode;
    private int InputMode;
    private int PC67Dir;
    private int PC45Dir;
    private static boolean UseWith8259;

    private final int Input = 1;
    private final int Output = 0;
    private final int Enabled = 1;
    private final int Disabled = 0;
    private final int Ascii = 0;
    private final int Binary = 1;
    private final int Hexadecimal = 2;
    private final int IntegerSigned = 3;
    private final int IntegerUnsigned = 4;
    private final int UsedForInterrupt = 2;
    private final static boolean UseWith8259Default = true;
    
    private final static String IO_FILE = "C:\\emu8086.io";
    private final static String HW_FILE = "C:\\emu8086.hw";
    private final static String XMLFile = "configP.xml";
    private final static int READ_FROM_FILE_INTERVAL = 50;
    private final static int BASE = 128;

    private static CheckControlWord CWThread;
    private static OutputThread OutThread;
}
