/* Eemu - 8255 peripheral extension for emu8086
 * Copyright (C) <2011>  <Nicola Alessandro Domingo>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package Emu8255;

import javax.swing.JOptionPane;

/**
 * This class repeatedly reads from <code>IO_FILE (C:\emu8086.io)</code> every msec milliseconds
 * checking whether or not a new value has been written to a port.
 */
public class OutputThread extends Thread
{
    /**
     * Parameterized Constructor.
     * @param gui A reference to the Emu8255 user interface.
     * @param msec Time delay between each reading from file.
     */
    public OutputThread(Emu8255 mainclass, Emu8255GUI gui, int msec)
    {
        msecSleepTime = msec;
        PortA = PortB = PortC = 0;
        this.Main = mainclass;
        this.gui = gui;
    }

    /**
     * This method actually reads from file.
     * Because of underlying limitations, the application is aware of a new value been written to a port,<br>
     * when it's different from the previous one. This may obviously lead to an unexpected and undesired behaviour.
     * @see IO
     * @exception InterruptedException
     */
    @Override
    public void run()
    {
        char val = 0;
        while(true)
        {
            if(Main.GetPortADir() == Output)
            {
                //Read from port A
                val = IO.ReadByte(IO_FILE, BASE);

                if(val != PortA)
                {
                    PortA = val;
                    //Print to port A
                    if(Main.GetOutputMode() == Ascii)
                        gui.SetText('A', String.valueOf(PortA));
                    else if(Main.GetOutputMode() == Binary)
                        gui.SetText('A', Main.ToBinaryString(PortA, 8));
                    else if(Main.GetOutputMode() == Hexadecimal){
                        String text = Integer.toHexString((int) PortA);
                        if(text.length() > 2)
                            text = text.substring(2);
                        gui.SetText('A', text);
                    }else if(Main.GetOutputMode() == IntegerSigned){
                        int value = Main.GetSignedIntegerFromChar(PortA);
                        gui.SetText('A', String.valueOf(value));
                    }else if(Main.GetOutputMode() == IntegerUnsigned){
                        int value = Main.GetUnsignedIntegerFromChar(PortA);
                        gui.SetText('A', String.valueOf(value));
                    }

                    if(Main.GetGroupAMode() == 1)
                    {
                        //Clear OBFa = PC7 = 0
                        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0x7F));
                        //gui.SetText('7', "0");
                    }
                    
                    /*if(Main.GetGroupAOutInt() == Enabled)
                        gui.SetText('3', "1");*/

                    if(Main.GetGroupAMode() == 1)
                    {
                        //Falling edge of ACK: PC6 = 0
                        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xBF));
                        //gui.SetText('6', "0");
                        //PC3 cleared by emu8086, PC7 and PC6 set by ACK from user GUI
                        Main.WaitForAckFromUser('A');
                    }
                }
            }

            if(Main.GetPortBDir() == Output)
            {
                //Read from port B
                val = IO.ReadByte(IO_FILE, BASE+1);

                if(val != PortB)
                {
                    PortB = val;
                    //Print to port B
                    if(Main.GetOutputMode() == Ascii)
                        gui.SetText('B', String.valueOf(PortB));
                    else if(Main.GetOutputMode() == Binary)
                        gui.SetText('B', Main.ToBinaryString(PortB, 8));
                    else if(Main.GetOutputMode() == Hexadecimal){
                        String text = Integer.toHexString((int) PortB);
                        if(text.length() > 2)
                            text = text.substring(2);
                        gui.SetText('B', text);
                    }else if(Main.GetOutputMode() == IntegerSigned){
                        int value = Main.GetSignedIntegerFromChar(PortA);
                        gui.SetText('B', String.valueOf(value));
                    }else if(Main.GetOutputMode() == IntegerUnsigned){
                        int value = Main.GetUnsignedIntegerFromChar(PortA);
                        gui.SetText('B', String.valueOf(value));
                    }

                    if(Main.GetGroupBMode() == 1)
                    {
                        //Clear OBFb = PC1 = 0
                        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xFD));
                        //gui.SetText('1', "0");
                    }
                    
                    /*if(Main.GetGroupBOutInt() == Enabled)
                        gui.SetText('0', "1");*/

                    if(Main.GetGroupBMode() == 1)
                    {
                        //Falling edge of ACK: PC2 = 0
                        IO.WriteByte(IO_FILE, BASE+2, (char) (IO.ReadByte(IO_FILE, BASE+2)&0xFB));
                        //gui.SetText('2', "0");
                        //PC0 cleared by emu8086, PC1 and PC2 set by ACK from user GUI
                        Main.WaitForAckFromUser('B');
                    }   
                }
            }

            if(Main.GetGroupAMode() == 0 && Main.GetPortCUpDir() == Output)
            {
                val = (char) (IO.ReadByte(IO_FILE, BASE+2)&0xF0);

                if(val != (PortC&0xF0))
                {
                    char value;
                    PortC &= 0x0F;
                    PortC |= val;

                    value = (char) ((PortC&0x80) >> 7);
                    if(value == 1) gui.SetText('7', "1");
                    else           gui.SetText('7', "0");

                    value = (char) ((PortC&0x40) >> 6);
                    if(value == 1) gui.SetText('6', "1");
                    else           gui.SetText('6', "0");

                    value = (char) ((PortC&0x20) >> 5);
                    if(value == 1) gui.SetText('5', "1");
                    else           gui.SetText('5', "0");

                    value = (char) ((PortC&0x10) >> 4);
                    if(value == 1) gui.SetText('4', "1");
                    else           gui.SetText('4', "0");
                }
            }
            if(Main.GetGroupBMode() == 0 && Main.GetPortCLoDir() == Output)
            {
                val = (char) (IO.ReadByte(IO_FILE, BASE+2)&0x0F);
                if(val != (PortC&0x0F))
                {
                    char value;
                    PortC &= 0xF0;
                    PortC |= val;

                    if(Main.GetGroupAMode() != 1){
                        value = (char) ((PortC&0x08) >> 3);
                        if(value == 1) gui.SetText('3', "1");
                        else           gui.SetText('3', "0");
                    }
                    
                    value = (char) ((PortC&0x04) >> 2);
                    if(value == 1) gui.SetText('2', "1");
                    else           gui.SetText('2', "0");

                    value = (char) ((PortC&0x02) >> 1);
                    if(value == 1) gui.SetText('1', "1");
                    else           gui.SetText('1', "0");

                    value = (char) (PortC&0x01);
                    if(value == 1) gui.SetText('0', "1");
                    else           gui.SetText('0', "0");
                }
            }
            if(Main.GetGroupAMode() == 1 && Main.GetPC67Dir() == Output)
            {
                val = (char) (IO.ReadByte(IO_FILE, BASE+2)&0xC0);

                if(val != (PortC&0xC0))
                {
                    char value;
                    PortC &= 0x3F;
                    PortC |= val;

                    value = (char) ((PortC&0x80) >> 7);
                    if(value == 1) gui.SetText('7', "1");
                    else           gui.SetText('7', "0");

                    value = (char) ((PortC&0x40) >> 6);
                    if(value == 1) gui.SetText('6', "1");
                    else           gui.SetText('6', "0");
                }
            }
            if(Main.GetGroupBMode() == 1 && Main.GetPC45Dir() == Output)
            {
                val = (char) (IO.ReadByte(IO_FILE, BASE+2)&0x30);

                if(val != (PortC&0x30))
                {
                    char value;
                    PortC &= 0xCF;
                    PortC |= val;

                    value = (char) ((PortC&0x20) >> 5);
                    if(value == 1) gui.SetText('5', "1");
                    else           gui.SetText('5', "0");

                    value = (char) ((PortC&0x10) >> 4);
                    if(value == 1) gui.SetText('4', "1");
                    else           gui.SetText('4', "0");
                }
            }

            try {
                Thread.sleep(msecSleepTime);
            } catch (InterruptedException ex) {
                JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private final int Input = 1;
    private final int Output = 0;
    private final int Enabled = 1;
    private final int Disabled = 0;
    private final int UsedForInterrupt = 2;
    private final int BASE = 128; //080h
    private final int Ascii = 0;
    private final int Binary = 1;
    private final int Hexadecimal = 2;
    private final int IntegerSigned = 3;
    private final int IntegerUnsigned = 4;
    private char PortA;
    private char PortB;
    private char PortC;
    private int msecSleepTime;
    private final String IO_FILE = "C:\\emu8086.io";
    private final String HW_FILE = "C:\\emu8086.hw";
    private Emu8255 Main;
    private Emu8255GUI gui;
}
