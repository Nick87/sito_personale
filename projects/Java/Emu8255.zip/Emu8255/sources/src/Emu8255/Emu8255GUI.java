/* Eemu - 8255 peripheral extension for emu8086
 * Copyright (C) <2011>  <Nicola Alessandro Domingo>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package Emu8255;

import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.JComponent;
import javax.swing.JRootPane;
import javax.swing.KeyStroke;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * This class implements the User Interface and provides public methods to modify it.
 */
public class Emu8255GUI extends javax.swing.JFrame
{
    /**
     * Parameterized Constructor.
     * @param title The caption of the main frame.
     */
    public Emu8255GUI(Emu8255 MainClass, String title, boolean UseWith8259Default)
    {
        super(title);
        Main = MainClass;
        Init(UseWith8259Default);
        //center on screen
        this.setLocationRelativeTo(null);
    }

    @Override
    protected JRootPane createRootPane()
    {
        ActionListener actionListener = new ActionListener() {
            public void actionPerformed(ActionEvent actionEvent) {
                if(IO.GetXMLValueOf("AskExitConfirmation").equals("0") || IO.GetXMLValueOf("AskExitConfirmation").equals(""))
                    Main.Exit(0);
                else
                    AskExitConfirmation();
            }
        };
        JRootPane RootPane = new JRootPane();
        KeyStroke stroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0);
        RootPane.registerKeyboardAction(actionListener, stroke, JComponent.WHEN_IN_FOCUSED_WINDOW);
        return RootPane;
    }

    private void Init(boolean UseWith8259Default)
    {
        initComponents();
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException ex) {
        } catch (InstantiationException ex) {
        } catch (IllegalAccessException ex) {
        } catch (UnsupportedLookAndFeelException ex) {}
        this.setDefaultCloseOperation(javax.swing.JFrame.DO_NOTHING_ON_CLOSE);
        this.setIconImage(new javax.swing.ImageIcon(iconPath).getImage());

        CWTextField.setEditable(false);
        CWTextField.setText("");
        PATextField.setEditable(false);
        PATextField.setText("");
        PBTextField.setEditable(false);
        PBTextField.setText("");
        CUpInt.setText(" ");
        CLoInt.setText(" ");
        OutputModeAscii.setSelected(true);
        OutputModeBinary.setSelected(false);
        OutputModeHexadecimal.setSelected(false);
        OutputModeIntegerSigned.setSelected(false);
        OutputModeIntegerUnsigned.setSelected(false);
        STBPortAButton.setEnabled(false);
        STBPortBButton.setEnabled(false);
        ACKPortAButton.setEnabled(false);
        ACKPortBButton.setEnabled(false);
        InputModeAscii.setSelected(true);
        InputModeBinary.setSelected(false);
        InputModeHexadecimal.setSelected(false);
        InputModeIntegerSigned.setSelected(false);
        InputModeIntegerUnsigned.setSelected(false);
        PATextField.addKeyListener(new MyKeyListener(this, Main, 'A'));
        PBTextField.addKeyListener(new MyKeyListener(this, Main, 'B'));
        PC0.addKeyListener(new MyKeyListener(this, Main, '0'));
        PC1.addKeyListener(new MyKeyListener(this, Main, '1'));
        PC2.addKeyListener(new MyKeyListener(this, Main, '2'));
        PC3.addKeyListener(new MyKeyListener(this, Main, '3'));
        PC4.addKeyListener(new MyKeyListener(this, Main, '4'));
        PC5.addKeyListener(new MyKeyListener(this, Main, '5'));
        PC6.addKeyListener(new MyKeyListener(this, Main, '6'));
        PC7.addKeyListener(new MyKeyListener(this, Main, '7'));
        PC0.setText("0");
        PC1.setText("0");
        PC2.setText("0");
        PC3.setText("0");
        PC4.setText("0");
        PC5.setText("0");
        PC6.setText("0");
        PC7.setText("0");
        PC0.setEditable(false);
        PC1.setEditable(false);
        PC2.setEditable(false);
        PC3.setEditable(false);
        PC4.setEditable(false);
        PC5.setEditable(false);
        PC6.setEditable(false);
        PC7.setEditable(false);
        UseWith8259(UseWith8259Default);
        sTray = new MySystemTray(this);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        TopPanel = new javax.swing.JPanel();
        CWLabel = new javax.swing.JLabel();
        CWTextField = new javax.swing.JTextField();
        GroupAModeLabel = new javax.swing.JLabel();
        GroupBModeLabel = new javax.swing.JLabel();
        PALabel = new javax.swing.JLabel();
        PCUpperLabel = new javax.swing.JLabel();
        PCLowerLabel = new javax.swing.JLabel();
        PBLabel = new javax.swing.JLabel();
        PBTextField = new javax.swing.JTextField();
        PATextField = new javax.swing.JTextField();
        CUpInt = new javax.swing.JLabel();
        CLoInt = new javax.swing.JLabel();
        STBPortAButton = new javax.swing.JButton();
        ACKPortAButton = new javax.swing.JButton();
        STBPortBButton = new javax.swing.JButton();
        ACKPortBButton = new javax.swing.JButton();
        ResetButton = new javax.swing.JButton();
        PC7 = new javax.swing.JTextField();
        PC6 = new javax.swing.JTextField();
        PC5 = new javax.swing.JTextField();
        PC4 = new javax.swing.JTextField();
        PC3 = new javax.swing.JTextField();
        PC2 = new javax.swing.JTextField();
        PC1 = new javax.swing.JTextField();
        PC0 = new javax.swing.JTextField();
        MenuBar = new javax.swing.JMenuBar();
        FileMenu = new javax.swing.JMenu();
        InputModeMenu = new javax.swing.JMenu();
        InputModeAscii = new javax.swing.JRadioButtonMenuItem();
        InputModeBinary = new javax.swing.JRadioButtonMenuItem();
        InputModeHexadecimal = new javax.swing.JRadioButtonMenuItem();
        InputModeInteger = new javax.swing.JMenu();
        InputModeIntegerSigned = new javax.swing.JRadioButtonMenuItem();
        InputModeIntegerUnsigned = new javax.swing.JRadioButtonMenuItem();
        OutputModeMenu = new javax.swing.JMenu();
        OutputModeAscii = new javax.swing.JRadioButtonMenuItem();
        OutputModeBinary = new javax.swing.JRadioButtonMenuItem();
        OutputModeHexadecimal = new javax.swing.JRadioButtonMenuItem();
        OutputModeInteger = new javax.swing.JMenu();
        OutputModeIntegerSigned = new javax.swing.JRadioButtonMenuItem();
        OutputModeIntegerUnsigned = new javax.swing.JRadioButtonMenuItem();
        UseWith8259Menu = new javax.swing.JMenu();
        UseWith8259Yes = new javax.swing.JRadioButtonMenuItem();
        UseWith8259No = new javax.swing.JRadioButtonMenuItem();
        Separator = new javax.swing.JPopupMenu.Separator();
        ExitMenuItem = new javax.swing.JMenuItem();
        HelpMenu = new javax.swing.JMenu();
        HelpMenuItem = new javax.swing.JMenuItem();
        CreditsMenuItem = new javax.swing.JMenuItem();
        SchematicsMenuItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setBounds(new java.awt.Rectangle(10, 10, 0, 0));
        setMinimumSize(new java.awt.Dimension(300, 200));
        setResizable(false);
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                formMouseClicked(evt);
            }
        });
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        CWLabel.setFont(new java.awt.Font("Tahoma", 1, 11));
        CWLabel.setText("Control Word:");

        CWTextField.setToolTipText("Control Word");
        CWTextField.setBorder(null);

        GroupAModeLabel.setFont(new java.awt.Font("Tahoma", 2, 11));
        GroupAModeLabel.setText("   ");
        GroupAModeLabel.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);

        GroupBModeLabel.setFont(new java.awt.Font("Tahoma", 2, 11));
        GroupBModeLabel.setText(" ");
        GroupBModeLabel.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);

        PALabel.setFont(new java.awt.Font("Tahoma", 1, 11));
        PALabel.setText("Port A:");

        PCUpperLabel.setFont(new java.awt.Font("Tahoma", 1, 11));
        PCUpperLabel.setText("Port C (upper):");

        PCLowerLabel.setFont(new java.awt.Font("Tahoma", 1, 11));
        PCLowerLabel.setText("Port C (lower):");

        PBLabel.setFont(new java.awt.Font("Tahoma", 1, 11));
        PBLabel.setText("Port B:");

        PBTextField.setToolTipText("Port B");

        PATextField.setToolTipText("Port A");

        CUpInt.setFont(new java.awt.Font("Tahoma", 2, 11));
        CUpInt.setText("    ");

        CLoInt.setFont(new java.awt.Font("Tahoma", 2, 11));
        CLoInt.setText("     ");

        STBPortAButton.setText("STB");
        STBPortAButton.setToolTipText("Trigger Strobe on Port A");
        STBPortAButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                STBPortAButtonActionPerformed(evt);
            }
        });

        ACKPortAButton.setText("ACK");
        ACKPortAButton.setToolTipText("Trigger ACK from device on Port A");
        ACKPortAButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ACKPortAButtonActionPerformed(evt);
            }
        });

        STBPortBButton.setText("STB");
        STBPortBButton.setToolTipText("Trigger Strobe on Port B");
        STBPortBButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                STBPortBButtonActionPerformed(evt);
            }
        });

        ACKPortBButton.setText("ACK");
        ACKPortBButton.setToolTipText("Trigger ACK from device on Port B");
        ACKPortBButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ACKPortBButtonActionPerformed(evt);
            }
        });

        ResetButton.setText("Reset");
        ResetButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResetButtonActionPerformed(evt);
            }
        });

        PC7.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        PC7.setToolTipText("PC7");
        PC7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        PC6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        PC6.setToolTipText("PC6");
        PC6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        PC5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        PC5.setToolTipText("PC5");
        PC5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        PC4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        PC4.setToolTipText("PC4");
        PC4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        PC3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        PC3.setToolTipText("PC3");
        PC3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        PC2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        PC2.setToolTipText("PC2");
        PC2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        PC1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        PC1.setToolTipText("PC1");
        PC1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        PC0.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        PC0.setToolTipText("PC0");
        PC0.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout TopPanelLayout = new javax.swing.GroupLayout(TopPanel);
        TopPanel.setLayout(TopPanelLayout);
        TopPanelLayout.setHorizontalGroup(
            TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(TopPanelLayout.createSequentialGroup()
                        .addComponent(CWLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(CWTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TopPanelLayout.createSequentialGroup()
                        .addComponent(GroupAModeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 162, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(GroupBModeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(TopPanelLayout.createSequentialGroup()
                        .addGroup(TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(PALabel)
                            .addComponent(PCLowerLabel)
                            .addComponent(PCUpperLabel)
                            .addComponent(PBLabel))
                        .addGap(7, 7, 7)
                        .addGroup(TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(TopPanelLayout.createSequentialGroup()
                                .addComponent(PATextField, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(STBPortAButton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(ACKPortAButton))
                            .addGroup(TopPanelLayout.createSequentialGroup()
                                .addComponent(PBTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(STBPortBButton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(ACKPortBButton))
                            .addGroup(TopPanelLayout.createSequentialGroup()
                                .addGroup(TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(TopPanelLayout.createSequentialGroup()
                                        .addComponent(PC3, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(PC2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(PC1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(PC0, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(TopPanelLayout.createSequentialGroup()
                                        .addComponent(PC7, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(PC6, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(PC5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(PC4, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(14, 14, 14)
                                .addGroup(TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(CUpInt, javax.swing.GroupLayout.DEFAULT_SIZE, 75, Short.MAX_VALUE)
                                    .addComponent(CLoInt, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 75, Short.MAX_VALUE)))))
                    .addComponent(ResetButton, javax.swing.GroupLayout.DEFAULT_SIZE, 277, Short.MAX_VALUE))
                .addContainerGap())
        );

        TopPanelLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {PC0, PC4});

        TopPanelLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {PC3, PC7});

        TopPanelLayout.setVerticalGroup(
            TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanelLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CWLabel)
                    .addComponent(CWTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(GroupAModeLabel)
                    .addComponent(GroupBModeLabel))
                .addGap(18, 18, 18)
                .addGroup(TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(PALabel)
                    .addGroup(TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(PATextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(STBPortAButton)
                        .addComponent(ACKPortAButton)))
                .addGap(7, 7, 7)
                .addGroup(TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(PC6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PC5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PCUpperLabel)
                    .addComponent(PC7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PC4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CUpInt, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(PCLowerLabel)
                        .addComponent(PC1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(PC2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(PC3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(PC0, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(CLoInt, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(PBLabel)
                    .addGroup(TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(PBTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(STBPortBButton)
                        .addComponent(ACKPortBButton)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ResetButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        TopPanelLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {PC3, PC7});

        TopPanelLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {PC2, PC6});

        TopPanelLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {PC1, PC5});

        TopPanelLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {PC0, PC4});

        FileMenu.setMnemonic('F');
        FileMenu.setText("File");

        InputModeMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Emu8255/Resources/input.gif"))); // NOI18N
        InputModeMenu.setMnemonic('I');
        InputModeMenu.setText("Input Mode");

        InputModeAscii.setText("Ascii");
        InputModeAscii.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InputModeAsciiActionPerformed(evt);
            }
        });
        InputModeMenu.add(InputModeAscii);

        InputModeBinary.setMnemonic('B');
        InputModeBinary.setText("Binary");
        InputModeBinary.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InputModeBinaryActionPerformed(evt);
            }
        });
        InputModeMenu.add(InputModeBinary);

        InputModeHexadecimal.setText("Hexadecimal");
        InputModeHexadecimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InputModeHexadecimalActionPerformed(evt);
            }
        });
        InputModeMenu.add(InputModeHexadecimal);

        InputModeInteger.setText("Integer");

        InputModeIntegerSigned.setSelected(true);
        InputModeIntegerSigned.setText("Signed");
        InputModeIntegerSigned.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InputModeIntegerSignedActionPerformed(evt);
            }
        });
        InputModeInteger.add(InputModeIntegerSigned);

        InputModeIntegerUnsigned.setText("Unsigned");
        InputModeIntegerUnsigned.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InputModeIntegerUnsignedActionPerformed(evt);
            }
        });
        InputModeInteger.add(InputModeIntegerUnsigned);

        InputModeMenu.add(InputModeInteger);

        FileMenu.add(InputModeMenu);

        OutputModeMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Emu8255/Resources/output.png"))); // NOI18N
        OutputModeMenu.setMnemonic('O');
        OutputModeMenu.setText("Output Mode");

        OutputModeAscii.setText("Ascii");
        OutputModeAscii.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OutputModeAsciiActionPerformed(evt);
            }
        });
        OutputModeMenu.add(OutputModeAscii);

        OutputModeBinary.setText("Binary");
        OutputModeBinary.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OutputModeBinaryActionPerformed(evt);
            }
        });
        OutputModeMenu.add(OutputModeBinary);

        OutputModeHexadecimal.setText("Hexadecimal");
        OutputModeHexadecimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OutputModeHexadecimalActionPerformed(evt);
            }
        });
        OutputModeMenu.add(OutputModeHexadecimal);

        OutputModeInteger.setText("Integer");

        OutputModeIntegerSigned.setSelected(true);
        OutputModeIntegerSigned.setText("Signed");
        OutputModeIntegerSigned.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OutputModeIntegerSignedActionPerformed(evt);
            }
        });
        OutputModeInteger.add(OutputModeIntegerSigned);

        OutputModeIntegerUnsigned.setText("Unsigned");
        OutputModeIntegerUnsigned.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OutputModeIntegerUnsignedActionPerformed(evt);
            }
        });
        OutputModeInteger.add(OutputModeIntegerUnsigned);

        OutputModeMenu.add(OutputModeInteger);

        FileMenu.add(OutputModeMenu);

        UseWith8259Menu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Emu8255/Resources/pic.png"))); // NOI18N
        UseWith8259Menu.setMnemonic('U');
        UseWith8259Menu.setText("Use with PIC 8259");

        UseWith8259Yes.setText("Yes");
        UseWith8259Yes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UseWith8259YesActionPerformed(evt);
            }
        });
        UseWith8259Menu.add(UseWith8259Yes);

        UseWith8259No.setMnemonic('N');
        UseWith8259No.setText("No");
        UseWith8259No.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UseWith8259NoActionPerformed(evt);
            }
        });
        UseWith8259Menu.add(UseWith8259No);

        FileMenu.add(UseWith8259Menu);
        FileMenu.add(Separator);

        ExitMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, java.awt.event.InputEvent.ALT_MASK));
        ExitMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Emu8255/Resources/exit.png"))); // NOI18N
        ExitMenuItem.setText("Exit");
        ExitMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitMenuItemActionPerformed(evt);
            }
        });
        FileMenu.add(ExitMenuItem);

        MenuBar.add(FileMenu);

        HelpMenu.setMnemonic('A');
        HelpMenu.setText("About");

        HelpMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F1, 0));
        HelpMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Emu8255/Resources/help.png"))); // NOI18N
        HelpMenuItem.setMnemonic('H');
        HelpMenuItem.setText("Help");
        HelpMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HelpMenuItemActionPerformed(evt);
            }
        });
        HelpMenu.add(HelpMenuItem);

        CreditsMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F2, 0));
        CreditsMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Emu8255/Resources/info.png"))); // NOI18N
        CreditsMenuItem.setMnemonic('C');
        CreditsMenuItem.setText("Credits");
        CreditsMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CreditsMenuItemActionPerformed(evt);
            }
        });
        HelpMenu.add(CreditsMenuItem);

        SchematicsMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F3, 0));
        SchematicsMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Emu8255/Resources/schematics.png"))); // NOI18N
        SchematicsMenuItem.setMnemonic('S');
        SchematicsMenuItem.setText("Schematics");
        SchematicsMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SchematicsMenuItemActionPerformed(evt);
            }
        });
        HelpMenu.add(SchematicsMenuItem);

        MenuBar.add(HelpMenu);

        setJMenuBar(MenuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * This method set the text to the Port C Upper Interrupt Label
     * @param text Text to set.
     */
    public void CUpIntSetText(String text) { CUpInt.setText(text); }
    /**
     * This method set the text to the Port C Lower Interrupt Label
     * @param text Text to set.
     */
    public void CLoIntSetText(String text) { CLoInt.setText(text); }
    /**
     * This method set the text to the Group A Mode Label
     * @param text Text to set.
     */
    public void GroupAModeLabelSetText(String text) { GroupAModeLabel.setText(text); }
    /**
     * This method set the text to the Group B Mode Label
     * @param text Text to set.
     */
    public void GroupBModeLabelSetText(String text) { GroupBModeLabel.setText(text); }
    /**
     * This method enables/disables the Strobe on Port A Button.
     * @param val true tu enable, false to disable.
     */
    public void STBPortAButtonSetEnabled(boolean val) { STBPortAButton.setEnabled(val); }
    /**
     * This method enables/disables the Strobe on Port B Button.
     * @param val true tu enable, false to disable.
     */
    public void STBPortBButtonSetEnabled(boolean val) { STBPortBButton.setEnabled(val); }
    /**
     * This method enables/disables the Ack on Port A Button.
     * @param val true tu enable, false to disable.
     */
    public void ACKPortAButtonSetEnabled(boolean val) { ACKPortAButton.setEnabled(val); }
    /**
     * This method enables/disables the Ack on Port B Button.
     * @param val true tu enable, false to disable.
     */
    public void ACKPortBButtonSetEnabled(boolean val) { ACKPortBButton.setEnabled(val); }
    /**
     * This method sets the text to UseWith8259 menu item yes label.
     * @param text Text to set.
     */
    public void UseWith8259SetText(String text) { UseWith8259Yes.setText("Yes (" + text+ ")"); }
    /**
     * This method makes Ascii Insertion Mode menu selected or not.
     * @param val true means selected, false means non selected.
     */
    public void InputModeAsciiSetSelected(boolean val) { InputModeAscii.setSelected(val); }
     /**
     * This method makes Binary Insertion Mode menu selected or not.
     * @param val true means selected, false means non selected.
     */
    public void InputModeBinarySetSelected(boolean val){ InputModeBinary.setSelected(val); }
     /**
     * This method makes Hexadecimal Insertion Mode menu selected or not.
     * @param val true means selected, false means non selected.
     */
    public void InputModeHexadecimalSetSelected(boolean val) { InputModeHexadecimal.setSelected(val); }
    /**
     * This method makes Integer Signed Insertion Mode menu selected or not.
     * @param val true means selected, false means non selected.
     */
    public void InputModeIntegerSignedSetSelected(boolean val) { InputModeIntegerSigned.setSelected(val); }
    /**
     * This method makes Integer Unsigned Insertion Mode menu selected or not.
     * @param val true means selected, false means non selected.
     */
    public void InputModeIntegerUnsignedSetSelected(boolean val) { InputModeIntegerUnsigned.setSelected(val); }
     /**
     * This method makes Ascii Output Mode menu selected or not.
     * @param val true means selected, false means non selected.
     */
    public void OutputModeAsciiSetSelected(boolean val) { OutputModeAscii.setSelected(val); }
     /**
     * This method makes Binary Output Mode menu selected or not.
     * @param val true means selected, false means non selected.
     */
    public void OutputModeBinarySetSelected(boolean val){ OutputModeBinary.setSelected(val); }
     /**
     * This method makes Hexadecimal Output Mode menu selected or not.
     * @param val true means selected, false means non selected.
     */
    public void OutputModeHexadecimalSetSelected(boolean val) { OutputModeHexadecimal.setSelected(val); }
    /**
     * This method makes Integer Signed Output Mode menu selected or not.
     * @param val true means selected, false means non selected.
     */
    public void OutputModeIntegerSignedSetSelected(boolean val) { OutputModeIntegerSigned.setSelected(val); }
    /**
     * This method makes Integer Unsigned Output Mode menu selected or not.
     * @param val true means selected, false means non selected.
     */
    public void OutputModeIntegerUnsignedSetSelected(boolean val) { OutputModeIntegerUnsigned.setSelected(val); }

     /**
     * This method changes the selection in UseWith8259 menu.
     * @param val true means UseWith8259Yes selected and UseWith8259No non selected, false means the other way around.
     */
    public void UseWith8259(boolean val)
    {
        if(val){
            UseWith8259Yes.setSelected(true);
            UseWith8259No.setSelected(false);
        }else{
            UseWith8259Yes.setSelected(false);
            UseWith8259No.setSelected(true);
        }
    }

    /**
     * This method sets the tooltip text for all the text fields.
     * @param port Port, that is text field, we want to set
     * @param dir Direction, Input or Output
     * @param io_mode Input/Output Mode, Ascii, Binary, Hexadecimal
     */
    public void SetTooltipText(char port, int dir, int io_mode)
    {
        String text = "Port " + String.valueOf(port).toUpperCase();
        
        if(dir == Input)
            text += ": Input";
        else if(dir == Output)
            text += ": Output";
        if(io_mode == Ascii)
            text += ", Ascii";
        else if(io_mode == Binary)
            text += ", Binary";
        else if(io_mode == Hexadecimal)
            text += ", Hexadecimal";
        else if(io_mode == IntegerSigned)
            text += ", Signed Integer";
        else if(io_mode == IntegerUnsigned)
            text += ", Unsigned Integer";

        if(port == 'a' || port == 'A')
            PATextField.setToolTipText(text);
        else if(port == 'b' || port == 'B')
            PBTextField.setToolTipText(text);
    }

    /**
     * This method is a more generical way to set a tooltip text.
     * @param who Port, that is text field, to set
     * @param text Tooltip text to set.
     */
    public void SetTooltipText(char who, String text)
    {
        if(who == 'a' || who == 'A')
            PATextField.setToolTipText(text);
        else if(who == 'b' || who == 'B')
            PBTextField.setToolTipText(text);
        else if(who == '0')
            PC0.setToolTipText(text);
        else if(who == '1')
            PC1.setToolTipText(text);
        else if(who == '2')
            PC2.setToolTipText(text);
        else if(who == '3')
            PC3.setToolTipText(text);
        else if(who == '4')
            PC4.setToolTipText(text);
        else if(who == '5')
            PC5.setToolTipText(text);
        else if(who == '6')
            PC6.setToolTipText(text);
        else if(who == '7')
            PC7.setToolTipText(text);
    }

    /**
     * This method sets the text for a text field.
     * @param tf Textfield to set.
     * @param text Text to set.
     */
    public void SetText(char tf, String text)
    {
        if(tf == 'A' || tf == 'a')
            PATextField.setText(text);
        else if(tf == 'B' || tf == 'b')
            PBTextField.setText(text);
        else if(tf == 'C' || tf == 'c')
            CWTextField.setText(text);
        else if(tf == '0')
            PC0.setText(text);
        else if(tf == '1')
            PC1.setText(text);
        else if(tf == '2')
            PC2.setText(text);
        else if(tf == '3')
            PC3.setText(text);
        else if(tf == '4')
            PC4.setText(text);
        else if(tf == '5')
            PC5.setText(text);
        else if(tf == '6')
            PC6.setText(text);
        else if(tf == '7')
            PC7.setText(text);
    }

    /**
     * This method return the text of a text field.
     * @param tf Text field in question.
     * @return A String containing the text of the text field.
     */
    public String GetText(char tf)
    {
        if(tf == 'A' || tf == 'a')
            return PATextField.getText();
        else if(tf == 'B' || tf == 'b')
            return PBTextField.getText();
        else if(tf == 'C' || tf == 'c')
            return CWTextField.getText();
        else if(tf == '0')
            return PC0.getText();
        else if(tf == '1')
            return PC1.getText();
        else if(tf == '2')
            return PC2.getText();
        else if(tf == '3')
            return PC3.getText();
        else if(tf == '4')
            return PC4.getText();
        else if(tf == '5')
            return PC5.getText();
        else if(tf == '6')
            return PC6.getText();
        else if(tf == '7')
            return PC7.getText();
        else
            return "";
    }

    /**
     * This method makes a text field editable or not
     * @param tf TextField in question.
     * @param val true to make editable, false otherwise.
     */
    public void SetEditable(char tf, boolean val)
    {
        if(tf == 'A' || tf == 'a')
            PATextField.setEditable(val);
        else if(tf == 'B' || tf == 'b')
            PBTextField.setEditable(val);
        else if(tf == 'C' || tf == 'c')
            CWTextField.setEditable(val);
        else if(tf == '0')
            PC0.setEditable(val);
        else if(tf == '1')
            PC1.setEditable(val);
        else if(tf == '2')
            PC2.setEditable(val);
        else if(tf == '3')
            PC3.setEditable(val);
        else if(tf == '4')
            PC4.setEditable(val);
        else if(tf == '5')
            PC5.setEditable(val);
        else if(tf == '6')
            PC6.setEditable(val);
        else if(tf == '7')
            PC7.setEditable(val);
    }

    /**
     * This method changes the color of a text field background.
     * @param tf TextField in question.
     * @param color The coloro to set.
     */
    public void SetBackground(char tf, java.awt.Color color)
    {
        if(tf == 'A' || tf == 'a')
            PATextField.setBackground(color);
        else if(tf == 'B' || tf == 'b')
            PBTextField.setBackground(color);
        else if(tf == 'C' || tf == 'c')
            CWTextField.setBackground(color);
        else if(tf == '0')
            PC0.setBackground(color);
        else if(tf == '1')
            PC1.setBackground(color);
        else if(tf == '2')
            PC2.setBackground(color);
        else if(tf == '3')
            PC3.setBackground(color);
        else if(tf == '4')
            PC4.setBackground(color);
        else if(tf == '5')
            PC5.setBackground(color);
        else if(tf == '6')
            PC6.setBackground(color);
        else if(tf == '7')
            PC7.setBackground(color);
    }

    /**
     * This method returns the System Tray.
     */
    public MySystemTray GetSystemTray()
    {
        return sTray;
    }
    
    private void InputModeBinaryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InputModeBinaryActionPerformed
        Main.InputModeBinaryActionPerformedHandler();
    }//GEN-LAST:event_InputModeBinaryActionPerformed

    private void InputModeAsciiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InputModeAsciiActionPerformed
        Main.InputModeAsciiActionPerformedHandler();
    }//GEN-LAST:event_InputModeAsciiActionPerformed
	
	private void InputModeHexadecimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InputModeHexadecimalActionPerformed
        Main.InputModeHexadecimalActionPerformedHandler();
    }//GEN-LAST:event_InputModeHexadecimalActionPerformed
	
	private void OutputModeAsciiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OutputModeAsciiActionPerformed
        Main.OutputModeAsciiActionPerformedHandler();
    }//GEN-LAST:event_OutputModeAsciiActionPerformed

    private void OutputModeBinaryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OutputModeBinaryActionPerformed
        Main.OutputModeBinaryActionPerformedHandler();
    }//GEN-LAST:event_OutputModeBinaryActionPerformed

    private void OutputModeHexadecimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OutputModeHexadecimalActionPerformed
        Main.OutputModeHexadecimalActionPerformedHandler();
    }//GEN-LAST:event_OutputModeHexadecimalActionPerformed

    private void HelpMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HelpMenuItemActionPerformed
        new HelpDialog(this, false).setVisible(true);
    }//GEN-LAST:event_HelpMenuItemActionPerformed

    private void CreditsMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CreditsMenuItemActionPerformed
        new CreditsDialog(this, false).setVisible(true);
    }//GEN-LAST:event_CreditsMenuItemActionPerformed

	private void ExitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitMenuItemActionPerformed
        if(IO.GetXMLValueOf("AskExitConfirmation").equals("0") || IO.GetXMLValueOf("AskExitConfirmation").equals(""))
            Main.Exit(0);
        else
            AskExitConfirmation();
    }//GEN-LAST:event_ExitMenuItemActionPerformed
	
	private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        HideMenus();
        if(IO.GetXMLValueOf("AskExitConfirmation").equals("0") || IO.GetXMLValueOf("AskExitConfirmation").equals(""))
            Main.Exit(0);
        else
            AskExitConfirmation();
    }//GEN-LAST:event_formWindowClosing

    /**
     * This method prompts the user to confirm he wants to exit
     */
    public void AskExitConfirmation()
    {
        new ExitConfirmationDialog(this, Main, false).setVisible(true);
    }

    private void STBPortAButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_STBPortAButtonActionPerformed
        Main.STBPortAButtonActionPerformedHandler();
    }//GEN-LAST:event_STBPortAButtonActionPerformed
 
    private void STBPortBButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_STBPortBButtonActionPerformed
        Main.STBPortBButtonActionPerformedHandler();
    }//GEN-LAST:event_STBPortBButtonActionPerformed

    private void ACKPortAButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ACKPortAButtonActionPerformed
        Main.ACKPortAButtonActionPerformedHandler();
    }//GEN-LAST:event_ACKPortAButtonActionPerformed

    private void ACKPortBButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ACKPortBButtonActionPerformed
        Main.ACKPortBButtonActionPerformedHandler();
    }//GEN-LAST:event_ACKPortBButtonActionPerformed

    private void ResetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResetButtonActionPerformed
        HideMenus();
        this.setCursor(new Cursor(Cursor.WAIT_CURSOR));
        Main.ResetButtonActionPerformedHandler();
        this.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_ResetButtonActionPerformed

    private void UseWith8259YesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UseWith8259YesActionPerformed
        this.setCursor(new Cursor(Cursor.WAIT_CURSOR));
        Main.UseWith8259ActionPerformedHandler(true);
        this.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_UseWith8259YesActionPerformed

    private void UseWith8259NoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UseWith8259NoActionPerformed
        Main.UseWith8259ActionPerformedHandler(false);
    }//GEN-LAST:event_UseWith8259NoActionPerformed

    private void SchematicsMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SchematicsMenuItemActionPerformed
        new SchematicsFrame(this).setVisible(true);
    }//GEN-LAST:event_SchematicsMenuItemActionPerformed

    private void formMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseClicked
        HideMenus();
    }//GEN-LAST:event_formMouseClicked

    private void InputModeIntegerSignedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InputModeIntegerSignedActionPerformed
        Main.InputModeIntegerSignedActionPerformedHandler();
    }//GEN-LAST:event_InputModeIntegerSignedActionPerformed

    private void OutputModeIntegerSignedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OutputModeIntegerSignedActionPerformed
        Main.OutputModeIntegerSignedActionPerformedHandler();
    }//GEN-LAST:event_OutputModeIntegerSignedActionPerformed

    private void InputModeIntegerUnsignedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InputModeIntegerUnsignedActionPerformed
        Main.InputModeIntegerUnsignedActionPerformedHandler();
    }//GEN-LAST:event_InputModeIntegerUnsignedActionPerformed

    private void OutputModeIntegerUnsignedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OutputModeIntegerUnsignedActionPerformed
        Main.OutputModeIntegerUnsignedActionPerformedHandler();
    }//GEN-LAST:event_OutputModeIntegerUnsignedActionPerformed

    private void HideMenus()
    {
        FileMenu.setPopupMenuVisible(false);
        FileMenu.setSelected(false);
        InputModeMenu.setPopupMenuVisible(false);
        OutputModeMenu.setPopupMenuVisible(false);
        UseWith8259Menu.setPopupMenuVisible(false);
        HelpMenu.setPopupMenuVisible(false);
        HelpMenu.setSelected(false);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ACKPortAButton;
    private javax.swing.JButton ACKPortBButton;
    private javax.swing.JLabel CLoInt;
    private javax.swing.JLabel CUpInt;
    private javax.swing.JLabel CWLabel;
    private javax.swing.JTextField CWTextField;
    private javax.swing.JMenuItem CreditsMenuItem;
    private javax.swing.JMenuItem ExitMenuItem;
    private javax.swing.JMenu FileMenu;
    private javax.swing.JLabel GroupAModeLabel;
    private javax.swing.JLabel GroupBModeLabel;
    private javax.swing.JMenu HelpMenu;
    private javax.swing.JMenuItem HelpMenuItem;
    private javax.swing.JRadioButtonMenuItem InputModeAscii;
    private javax.swing.JRadioButtonMenuItem InputModeBinary;
    private javax.swing.JRadioButtonMenuItem InputModeHexadecimal;
    private javax.swing.JMenu InputModeInteger;
    private javax.swing.JRadioButtonMenuItem InputModeIntegerSigned;
    private javax.swing.JRadioButtonMenuItem InputModeIntegerUnsigned;
    private javax.swing.JMenu InputModeMenu;
    private javax.swing.JMenuBar MenuBar;
    private javax.swing.JRadioButtonMenuItem OutputModeAscii;
    private javax.swing.JRadioButtonMenuItem OutputModeBinary;
    private javax.swing.JRadioButtonMenuItem OutputModeHexadecimal;
    private javax.swing.JMenu OutputModeInteger;
    private javax.swing.JRadioButtonMenuItem OutputModeIntegerSigned;
    private javax.swing.JRadioButtonMenuItem OutputModeIntegerUnsigned;
    private javax.swing.JMenu OutputModeMenu;
    private javax.swing.JLabel PALabel;
    private javax.swing.JTextField PATextField;
    private javax.swing.JLabel PBLabel;
    private javax.swing.JTextField PBTextField;
    private javax.swing.JTextField PC0;
    private javax.swing.JTextField PC1;
    private javax.swing.JTextField PC2;
    private javax.swing.JTextField PC3;
    private javax.swing.JTextField PC4;
    private javax.swing.JTextField PC5;
    private javax.swing.JTextField PC6;
    private javax.swing.JTextField PC7;
    private javax.swing.JLabel PCLowerLabel;
    private javax.swing.JLabel PCUpperLabel;
    private javax.swing.JButton ResetButton;
    private javax.swing.JButton STBPortAButton;
    private javax.swing.JButton STBPortBButton;
    private javax.swing.JMenuItem SchematicsMenuItem;
    private javax.swing.JPopupMenu.Separator Separator;
    private javax.swing.JPanel TopPanel;
    private javax.swing.JMenu UseWith8259Menu;
    private javax.swing.JRadioButtonMenuItem UseWith8259No;
    private javax.swing.JRadioButtonMenuItem UseWith8259Yes;
    // End of variables declaration//GEN-END:variables
    private Emu8255 Main;
    private MySystemTray sTray;
    private final static String IO_FILE = "C:\\emu8086.io";
    private final static String HW_FILE = "C:\\emu8086.hw";
    private final String iconPath = ".\\lib\\icon.png";
    private final int Input = 1;
    private final int Output = 0;
    private final int Ascii = 0;
    private final int Binary = 1;
    private final int Hexadecimal = 2;
    private final int IntegerSigned = 3;
    private final int IntegerUnsigned = 4;
}
