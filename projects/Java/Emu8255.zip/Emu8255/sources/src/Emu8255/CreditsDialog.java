/* Eemu - 8255 peripheral extension for emu8086
 * Copyright (C) <2011>  <Nicola Alessandro Domingo>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package Emu8255;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JRootPane;
import javax.swing.KeyStroke;

/**
 * This class implements the info dialog shown when F2 is pressed.
 */
public class CreditsDialog extends javax.swing.JDialog
{
    /**
     * Parameterized Constructor.
     * @param parent Parent frame.
     * @param modal If it's a modal dialog or not.
     */
    public CreditsDialog(Emu8255GUI parent, boolean modal)
    {
        super(parent, modal);
        GUI = parent;
        initComponents();
        this.setIconImage(new ImageIcon(iconPath).getImage());
        this.setTitle("Credits");
        this.setLocationRelativeTo(parent);
    }

    @Override
    protected JRootPane createRootPane()
    {
        ActionListener actionListener = new ActionListener() {
            public void actionPerformed(ActionEvent actionEvent) {
                setVisible(false);
            }
        };
        JRootPane RootPane = new JRootPane();
        KeyStroke stroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0);
        RootPane.registerKeyboardAction(actionListener, stroke, JComponent.WHEN_IN_FOCUSED_WINDOW);
        return RootPane;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        TopPanel = new javax.swing.JPanel();
        Label1 = new javax.swing.JLabel();
        Label2 = new javax.swing.JLabel();
        Label3 = new javax.swing.JLabel();
        Label4 = new MyHyperlink(GUI, "paolo.bernardi@polito.it", true);
        Label5 = new MyHyperlink(GUI, "http://www.gnu.org/licenses/gpl-3.0.txt", false);
        LogoLabel = new MyHyperlink(GUI, "www.polito.it", false);
        Emu8255Label = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("");
        setBounds(new java.awt.Rectangle(10, 10, 0, 0));
        setModal(true);
        setResizable(false);

        Label1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Label1.setText("Nicola Alessandro Domingo");

        Label2.setFont(new java.awt.Font("Tahoma", 1, 12));
        Label2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Label2.setText("Created by:");

        Label3.setFont(new java.awt.Font("Tahoma", 1, 12));
        Label3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Label3.setText("Supervised by:");

        Label4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Label4.setText("Ing. Paolo Bernardi");

        Label5.setFont(new java.awt.Font("Tahoma", 2, 11));
        Label5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Label5.setText("Free Software. Code released under the terms of GPLv3.");

        LogoLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LogoLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Emu8255/Resources/logo.png"))); // NOI18N

        Emu8255Label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Emu8255/Resources/emu8255.png"))); // NOI18N

        javax.swing.GroupLayout TopPanelLayout = new javax.swing.GroupLayout(TopPanel);
        TopPanel.setLayout(TopPanelLayout);
        TopPanelLayout.setHorizontalGroup(
            TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(TopPanelLayout.createSequentialGroup()
                        .addGroup(TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(TopPanelLayout.createSequentialGroup()
                                .addGap(33, 33, 33)
                                .addComponent(Emu8255Label))
                            .addComponent(Label2)
                            .addComponent(Label1)
                            .addComponent(Label3)
                            .addComponent(Label4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(LogoLabel))
                    .addComponent(Label5, javax.swing.GroupLayout.DEFAULT_SIZE, 284, Short.MAX_VALUE))
                .addContainerGap())
        );
        TopPanelLayout.setVerticalGroup(
            TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(TopPanelLayout.createSequentialGroup()
                        .addComponent(Emu8255Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Label2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Label1)
                        .addGap(13, 13, 13)
                        .addComponent(Label3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Label4)
                        .addGap(12, 12, 12))
                    .addComponent(LogoLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Label5)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * main() method.
     */
    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {}
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Emu8255Label;
    private javax.swing.JLabel Label1;
    private javax.swing.JLabel Label2;
    private javax.swing.JLabel Label3;
    private javax.swing.JLabel Label4;
    private javax.swing.JLabel Label5;
    private javax.swing.JLabel LogoLabel;
    private javax.swing.JPanel TopPanel;
    // End of variables declaration//GEN-END:variables
    private final String iconPath = "lib\\info.png";
    Emu8255GUI GUI;
}
