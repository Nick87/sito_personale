/* Eemu - 8255 peripheral extension for emu8086
 * Copyright (C) <2011>  <Nicola Alessandro Domingo>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package Emu8255;

import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.event.MouseListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

/**
 * This class implements the logic for the System Tray.
 */
public class MySystemTray extends JPopupMenu
{
    private TrayIcon trayIcon;
    private final String iconPath = ".\\lib\\icon.png";
    SystemTray systemTray;
    private Emu8255GUI GUI;
    //private JPopupMenu popupMenu;

    /**
     * Parameterized Constructor.
     * @param gui The Emu8255 gui class.
     * @see Emu8255GUI
     */
    public MySystemTray(Emu8255GUI gui)
    {
        try
        {
            if (SystemTray.isSupported())
            {
                GUI = gui;
                systemTray = SystemTray.getSystemTray();
                trayIcon = new TrayIcon(Toolkit.getDefaultToolkit().getImage(iconPath));
                trayIcon.setImageAutoSize(true);
                systemTray.add(trayIcon);
                trayIcon.addMouseListener((MouseListener) new SystemTrayMouseListener());
                //popupMenu = createPopupMenu();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /*private JPopupMenu createPopupMenu()
    {
        final JPopupMenu p = new JPopupMenu();
        JMenuItem exit = new JMenuItem("Exit     Alt+F4");

        exit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                p.setVisible(false);
            }
        });

        p.add(exit);
        return p;
    }*/

    private class SystemTrayMouseListener extends MouseAdapter
    {
        @Override
        public void mouseClicked(MouseEvent e)
        {
            if (e.getButton() == 1) //Left click
                GUI.setVisible(!GUI.isVisible());
            else if (e.getButton() == 3) { //Right click
                //popupMenu.show(e.getComponent(), e.getX(), e.getY());
                GUI.setVisible(true);
                if(IO.GetXMLValueOf("AskExitConfirmation").equals("0") || IO.GetXMLValueOf("AskExitConfirmation").equals(""))
                    System.exit(0);
                else
                    GUI.AskExitConfirmation();
            }
        }
    }

    /**
     * This method shows a notification above the System Tray Icon
     * @param caption Caption of the notification.
     * @param text Text of the notification.
     * @param mType Type of notification.
     */
    public void Notify(String caption, String text, TrayIcon.MessageType mType)
    {
        trayIcon.displayMessage(caption, text, mType);
    }
}
