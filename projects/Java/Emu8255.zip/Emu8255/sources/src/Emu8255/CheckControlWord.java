/* Eemu - 8255 peripheral extension for emu8086
 * Copyright (C) <2011>  <Nicola Alessandro Domingo>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package Emu8255;

/**
 * This class repeatedly reads from <code>IO_FILE (C:\emu8086.io)</code> every msec milliseconds
 * checking whether or not the control word has changed.
 */
public class CheckControlWord extends Thread
{
    /**
     * Parameterized Constructor.
     * @param gui A reference to the Emu8255 user interface.
     * @param msec Time delay between each reading from file.
     */
    public CheckControlWord(Emu8255 mainclass, Emu8255GUI gui, int msec)
    {
        CW = 0;
        msecSleepTime = msec;
        this.Main = mainclass;
        this.gui = gui;
    }

    /**
     * This method actually reads from file.
     * @see IO
     * @exception InterruptedException
     */
    @Override
    public void run()
    {        
        byte val = 0;
        while(true)
        {
            val = (byte) IO.ReadByte(IO_FILE, BASE+3);

            //A volte compare la parola di controllo "11111111" da non si sa da dove nè perchè
            if(CW != val && CW != 0xFF)
            {
                CW = val;
                Main.SetControlWord((char) CW);
            }
            
            try {
                Thread.sleep(msecSleepTime);
            } catch (InterruptedException ex) {}
        }
    }

    private final String IO_FILE = "C:\\emu8086.io";
    private final int BASE = 128;
    private byte CW;
    private int msecSleepTime;
    private Emu8255 Main;
    private Emu8255GUI gui;
}
