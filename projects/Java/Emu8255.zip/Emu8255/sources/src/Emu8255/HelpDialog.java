/* Eemu - 8255 peripheral extension for emu8086
 * Copyright (C) <2011>  <Nicola Alessandro Domingo>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package Emu8255;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JRootPane;
import javax.swing.KeyStroke;

/**
 * This class implements the help dialog shown when F1 is pressed.
 */
public class HelpDialog extends javax.swing.JDialog
{
    /**
     * Parameterized Constructor.
     * @param parent Parent frame.
     * @param modal If it's a modal dialog or not.
     */
    public HelpDialog(java.awt.Frame parent, boolean modal)
    {
        super(parent, modal);
        initComponents();
        this.setIconImage(new ImageIcon(iconPath).getImage());
        this.setTitle("Help");
        this.setLocationRelativeTo(parent);
    }

    @Override
    protected JRootPane createRootPane()
    {
        ActionListener actionListener = new ActionListener() {
            public void actionPerformed(ActionEvent actionEvent) {
                setVisible(false);
            }
        };
        JRootPane RootPane = new JRootPane();
        KeyStroke stroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0);
        RootPane.registerKeyboardAction(actionListener, stroke, JComponent.WHEN_IN_FOCUSED_WINDOW);
        return RootPane;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Help = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("");
        setModal(true);
        setResizable(false);

        Help.setText("<html>\n<b>Things you should know:</b><br>\n<ul type=\"disc\">\n<li>You can press ESC to exit frames and dialogs.\n<li>Allowed addresses are: 0x80, 0x81, 0x82, 0x83 (Port A, Port B, Port C, Control Port).\n<li>When Mode 2 is detected, since it's not supported by the application, you need to\n press the Reset button and proceed by providing a new Control Word.\n<li>When Ascii Output Mode is set and no output is shown, this may be due to the fact \nthat the character is actually a non-printable ascii character.\n<li>When in Mode 0 Input, since Strobe is not available, values are written to their\ncorresponding ports once the input is complete, according to the input mode that has been set\n(i.e. 8 one/zeros when in binary mode, 1 bit for PCi, 1 character when in Ascii mode,\n2 hex chars when in hexadecimal mode).\nIn the case of Signed/Unsigned input mode, since the number of characters allowed is variable,\nyou need to type '.' (period) once the input is complete.\n<li>When polling on Port A/B checking the IBFa/IBFb bit (respectively PC5 and PC1), after you\nhave read port C, remember to clear that bit or your application will consider another input available\non port A/B.\n<li>If you want to re-program the 8255, don't send a new Control Word \"on-the-fly\",\nbut press the Reset button before doing it.\n<li>The ACK button becomes enabled only when a value is actually sent out to the device.\nThis means that no other operations are allowed until the user presses the Ack button,\n notifying the 8255 the device has received the value.\n<li>If a Text Field is editable, the corresponding port or bit direction is input, otherwise\nthe direction is output.\n<li>It is recommended to not set a step delay in emu8086 shorter than 100 msec.\n<li>Because of underlying limitations, the application is aware of a new value written\nto a port, only when it's different from the previous one. This may obviously lead to an\nunexpected and undesired behaviour.\n</ul>");
        Help.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Help, javax.swing.GroupLayout.PREFERRED_SIZE, 566, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Help, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * main() method.
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {}
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Help;
    // End of variables declaration//GEN-END:variables
    private final String iconPath = "lib\\help.png";
}
