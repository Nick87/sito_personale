/* Eemu - 8255 peripheral extension for emu8086
 * Copyright (C) <2011>  <Nicola Alessandro Domingo>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package Emu8255;

import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URI;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 * This class implements a label opening a web page when clicked.
 */
public class MyHyperlink extends JLabel
{
    /**
     * Parameterized Constructor.
     * @param parent Parent frame,
     * @param text The text of the label.
     * @param url URL of the web page to open.
     * @param mail If we want to open a browser or a mail client.
     * @see Emu8255GUI
     */
    public MyHyperlink (final Emu8255GUI parent, final String url, final boolean mail)
    {
        addMouseListener
        (
            new MouseAdapter()
            {
                @Override
                public void mouseClicked (MouseEvent event)
                {
                    try
                    {
                        if(mail)
                            Desktop.getDesktop().mail(new URI("mailto:" + url + "?subject=Emu8255-Info"));
                        else
                            Desktop.getDesktop().browse(new URI(url));
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(parent, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
                @Override
                public void mouseEntered(MouseEvent event)
                {
                    setCursor(new Cursor(Cursor.HAND_CURSOR));
                }
                @Override
                public void mouseExited(MouseEvent event)
                {
                    setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                }
            }
        );
    }
}