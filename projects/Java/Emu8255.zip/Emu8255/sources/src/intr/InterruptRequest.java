/* Eemu - 8255 peripheral extension for emu8086
 * Copyright (C) <2011>  <Nicola Alessandro Domingo>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package intr;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Calendar;

/**
 * This class describes and Interrupt Request that is sent to the PIC8259.
 */
public class InterruptRequest implements Serializable, Comparable
{
    /**
     * Parameterized constructor.
     * @param ir_id Line Id of the Interrupt Request.
     * @param device A brief description of the device sending the IRQ.
     */
    public InterruptRequest(int ir_id, String device)
    {
        this.ir_id = ir_id;
        this.device = device;
        setTimeStamp();
    }

    /**
     * Return the Id of the IRQ.
     * @return Id of the IRQ.
     */
    public int getIrId() { return(ir_id); }
    /**
     * Returns the description associated to the device.
     * @return The description of the device.
     */
    public String getDevice() { return(device); }
    /**
     * Return the timestamp of when the IRQ was sent.
     * @return The timestamp of the IRQ.
     */
    public Timestamp getTimeStamp() { return(ts); }

    /**
     * Set the current timestamp to this Interrupt Request.
     */
    public void setTimeStamp()
    {
        Calendar calendar = Calendar.getInstance();
        this.ts = new Timestamp(calendar.getTime().getTime());
        return;
    }

    /**
     * This method compares two InterruptRequest objects.
     * It returns a positive value if this InterruptRequest's id is greater than the InterruptRequest's id object<br>
     * passed as argument, a negative value otherwise, 0 if the InterruptRequest id is the same.
     * @param anotherInterrupt An InterruptRequest object we want this InterruptRequest to be compared with.
     * @return A positive number, a negative number or 0.
     */
    public int compareTo(Object anotherInterrupt)
    {
        if(!(anotherInterrupt instanceof InterruptRequest))
            throw new ClassCastException("An InterruptRequest object is expected.");
        int id = ((InterruptRequest) anotherInterrupt).getIrId();
        return (this.ir_id - id);
    }

    private Timestamp ts;
    private int ir_id;
    private String device;
}