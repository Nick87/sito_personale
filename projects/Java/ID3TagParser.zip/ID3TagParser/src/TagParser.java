/**
 * mettere singleton (jsmooth o socket)
 * gestire caratteri cinesi
 */

import javax.swing.SwingWorker;
import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.io.FileUtils;
import org.jaudiotagger.audio.AudioFileIO;
import org.jaudiotagger.audio.mp3.MP3File;
import org.jaudiotagger.tag.Tag;
import org.jaudiotagger.tag.TagField;
import org.jaudiotagger.tag.id3.AbstractID3v2Tag;
import org.jaudiotagger.tag.id3.AbstractTagFrameBody;
import org.jaudiotagger.tag.id3.ID3v1Tag;
import org.jaudiotagger.tag.id3.ID3v24Frame;
import org.jaudiotagger.tag.id3.ID3v24Tag;
import org.jaudiotagger.tag.id3.framebody.FrameBodyAPIC;

public class TagParser extends SwingWorker<Void, Void>
{
    private String DestinationPath;
    private int MP3Rimasti;
    private boolean Estesa;    
    private boolean Cover;
    private String Filtro;
    private volatile boolean cancel;
    private ArrayList FilesToRename;
    private GUI gui;
    private final String ImagesDir = "Cover";

    public TagParser(String dest, ArrayList filesToRename, String filtro,
                     boolean estesa, boolean cover,
                     GUI gui)
    {
        this.DestinationPath = dest;
        this.FilesToRename = filesToRename;
        this.Estesa = estesa;
        this.Cover = cover;
        this.Filtro = filtro;
        this.gui = gui;
        this.MP3Rimasti = filesToRename.size();
        this.cancel = false;
    }
    
    @Override
    protected Void doInBackground()
    {
        for(int i = 0; i < FilesToRename.size(); i++)
            Decode((String)FilesToRename.get(i));
        gui.Fine();
        return null;
    }

    private void Decode(String fileName)
    {
        if(cancel) return;
        String artista = null, titolo = null, album = null;

        artista = GetArtista(fileName);
        titolo = GetTitolo(fileName);
        album = GetAlbum(fileName);

        if(artista != null) artista = FixName(artista, false);
        if(titolo != null)  titolo = FixName(titolo, false);
        if(album != null)   album = FixName(album, true);
        if(Cover && FiltroOk(artista, titolo, album))
            GetCover(fileName, artista, album);

        artista = (artista == null || artista .equals("")) ? "Artista Sconosciuto" : artista;
        titolo = (titolo == null || titolo.equals("")) ? "Titolo Sconosciuto" : titolo;
        album = (album == null || album.equals("")) ? "Album Sconosciuto" : album;
        
        String textToAppend = new File(fileName).getName() + ": " + artista + " - " + titolo + "\n";
        if(FiltroOk(artista, titolo, album))
            gui.logAppendText(textToAppend);
        gui.SetLabelStatusText(null, "MP3 rimasti: " + --MP3Rimasti);

        

        if(FiltroOk(artista, titolo, album))
            CopyFile(fileName, artista, titolo, album);
        gui.Avanza();

        int len = textToAppend.length();
        int currentPos = gui.GetLog().getText().length();
        int newCaretPosition = currentPos-len;
        if(gui.Scroll() && newCaretPosition >= 0)
            gui.GetLog().setCaretPosition(newCaretPosition);
    }

    private void CopyFile(String fileName, String artista, String titolo, String album)
    {
        try
        {
            if(Estesa)
            {
                String Dir = DestinationPath + File.separator + "MP3" + File.separator;
                new File(Dir).mkdir();
                Dir += artista + File.separator;
                new File(Dir).mkdir();
                Dir += album + File.separator;
                new File(Dir).mkdir();
                String nomeFile = artista + " - " + titolo;
                nomeFile = nomeFileWithDuplicate(Dir + nomeFile);
                FileUtils.copyFile(new File(fileName), new File(nomeFile));
            }
            else
            {
                String nomeFile = DestinationPath + File.separator + "MP3" + File.separator + artista + " - " + titolo;
                nomeFile = nomeFileWithDuplicate(nomeFile);
                FileUtils.copyFile(new File(fileName), new File(nomeFile));
            }
        } catch (Exception ex) {
            gui.logAppendText("\n*** ERRORE COPIA FILE ***: " + new File(fileName).getName() + " -> " + ex.toString() + "\n\n");
        }
    }

    private String nomeFileWithDuplicate(String fileName)
    {
        if(!new File(fileName + ".mp3").exists()) return fileName + ".mp3";
        for(int count = 2; ; count++)
            if(!new File(fileName + " (" + count + ").mp3").exists())
                return fileName + " (" + count + ").mp3";
    }

    private String GetArtista(String fileName)
    {
        MP3File mp3 = null;
        ID3v24Tag v24Tag = null;
        ID3v24Frame frame = null;
        Iterator iter = null;
        AbstractTagFrameBody body = null;
        String artista = null;

        try
        {
            mp3 = (MP3File) AudioFileIO.read(new File(fileName));
            v24Tag = (ID3v24Tag)(AbstractID3v2Tag) mp3.getID3v2TagAsv24();
            iter = v24Tag.getFrameOfType("TPE");
            while(iter.hasNext())
            {
                frame = (ID3v24Frame) iter.next();
                body = frame.getBody();
                artista = body.getUserFriendlyValue().trim();
                if(Invalid(artista) || artista.equals("")) continue;
                if(artista != null) break;
            }
        } catch (NullPointerException ex) {
            try
            {
                Tag tag = mp3.getTag();
                ID3v1Tag v1Tag  = (ID3v1Tag)tag;
                List<TagField> list = v1Tag.getArtist();
                artista = list.get(0).toString();
            } catch (Exception e) {}
        } catch(Exception ex) {
            gui.logAppendText("\n*** ERRORE ARTISTA ***: " + new File(fileName).getName() + " -> " + ex.toString() + "\n\n");
            return null;
        }
        return artista;
    }

    private String GetTitolo(String fileName)
    {
        MP3File mp3 = null;
        ID3v24Tag v24Tag = null;
        ID3v24Frame frame = null;
        Iterator iter = null;
        AbstractTagFrameBody body = null;
        String titolo = null;

        try
        {
            mp3 = (MP3File) AudioFileIO.read(new File(fileName));
            v24Tag = (ID3v24Tag)(AbstractID3v2Tag) mp3.getID3v2TagAsv24();
            iter = v24Tag.getFrameOfType("TIT2");
            while(iter.hasNext())
            {
                frame = (ID3v24Frame) iter.next();
                body = frame.getBody();
                titolo = body.getUserFriendlyValue().trim();
                if(Invalid(titolo) || titolo.equals("")) continue;
                if(titolo != null) return titolo;
            }
            iter = v24Tag.getFrameOfType("TIT3");
            while(iter.hasNext())
            {
                frame = (ID3v24Frame) iter.next();
                body = frame.getBody();
                titolo = body.getUserFriendlyValue().trim();
                if(Invalid(titolo) || titolo.equals("")) continue;
                if(titolo != null) return titolo;
            }
        } catch (NullPointerException ex) {
            try
            {
                Tag tag = mp3.getTag();
                ID3v1Tag v1Tag  = (ID3v1Tag)tag;
                List<TagField> list = v1Tag.getTitle();
                titolo = list.get(0).toString();
            } catch (Exception e) {}
        } catch(Exception ex) {
            gui.logAppendText("\n*** ERRORE TITOLO ***: " + new File(fileName).getName() + " -> " + ex.toString() + "\n\n");
            return null;
        }
        return titolo;
    }

    private String GetAlbum(String fileName)
    {
        MP3File mp3 = null;
        ID3v24Tag v24Tag = null;
        ID3v24Frame frame = null;
        Iterator iter = null;
        AbstractTagFrameBody body = null;
        String album = null;

        try
        {
            mp3 = (MP3File) AudioFileIO.read(new File(fileName));
            v24Tag = (ID3v24Tag)(AbstractID3v2Tag) mp3.getID3v2TagAsv24();
            iter = v24Tag.getFrameOfType("TAL");
            while(iter.hasNext())
            {
                frame = (ID3v24Frame) iter.next();
                body = frame.getBody();
                album = body.getUserFriendlyValue().trim();
                if(Invalid(album) || album.equals("")) continue;
                if(album != null) break;
            }
        } catch (NullPointerException ex) {
            try
            {
                Tag tag = mp3.getTag();
                ID3v1Tag v1Tag  = (ID3v1Tag)tag;
                List<TagField> list = v1Tag.getAlbum();
                album = list.get(0).toString();
            } catch (Exception e) {}
        } catch(Exception ex) {
            gui.logAppendText("\n*** ERRORE ALBUM ***: " + new File(fileName).getName() + " -> " + ex.toString() + "\n\n");
            return null;
        }
        return album;
    }

    private void GetCover(String fileName, String artista, String album)
    {
        ID3v24Frame frame = null;
        Iterator iter = null;
        AbstractTagFrameBody body = null;
        MP3File mp3 = null;
        ID3v24Tag v24Tag = null;
        FrameBodyAPIC picture = null;
        RandomAccessFile raf = null;
        try
        {
            mp3 = (MP3File) AudioFileIO.read(new File(fileName));
            v24Tag = (ID3v24Tag)(AbstractID3v2Tag) mp3.getID3v2TagAsv24();
            iter = v24Tag.getFrameOfType("APIC");
            if(iter.hasNext())
            {
                frame = (ID3v24Frame) iter.next();
                picture = (FrameBodyAPIC) frame.getBody();
                
                String ImageDir = DestinationPath + File.separator + ImagesDir + File.separator;
                new File(ImageDir).mkdir();
                String Dir = (artista == null || artista.equals("")) ? "Artista Sconosciuto" : FixName(artista, false);
                String CoverDir = ImageDir + Dir + File.separator;
                new File(CoverDir).mkdir();
                album = (album == null || album.equals("")) ? "Album Sconosciuto" : FixName(album, false);
                String ImageName = CoverDir + album + GetExtension(picture.getMimeType());
                raf = new RandomAccessFile(new File(ImageName), "rw");
                raf.write(picture.getImageData());
                raf.close();
            }
            else
                gui.logAppendText("\n*** ERRORE COVER ***: " + new File(fileName).getName() + " -> Nessuna cover trovata\n\n");
        } catch (NullPointerException ex) {
            gui.logAppendText("\n*** ERRORE COVER ***: " + new File(fileName).getName() + " -> Nessuna cover trovata\n\n");
        } catch (Exception ex) {
            gui.logAppendText("\n*** ERRORE COVER ***: " + new File(fileName).getName() + " -> " + ex.toString() + "\n\n");
        }
    }

    private boolean FiltroOk(String artista, String titolo, String album)
    {
        return (Filtro.equals("") ||
                (
                    (artista != null && artista.toLowerCase().contains(Filtro.toLowerCase())) ||
                    (titolo != null && titolo.toLowerCase().contains(Filtro.toLowerCase()))   ||
                    (album != null && album.toLowerCase().contains(Filtro.toLowerCase()))
                )
               );

    }

    private String GetExtension(String str)
    {
        String[] ext = str.split("/");
        return "." + ext[1];
    }

    public void Cancel()
    {
        cancel = true;
    }

    private boolean Invalid(String str)
    {
        return (str.contains("www.") &&
                (str.contains(".com") || str.contains(".it") ||
                 str.contains(".am") || str.contains(".de")));
    }

    private String FixName(String name, boolean isAlbum)
    {
        String temp = "";

        //Eliminiamo caratteri non ammessi e non stampabili
        for(int i = 0; i < name.length(); i++)
            if(!(NotAllowed(name.charAt(i)) || NonPrintable(name.charAt(i))))
                temp += String.valueOf(name.charAt(i));

        if(temp.length() == 0) return temp;

        /* Il nome di un album sara' quello di una cartella, ed il nome di una cartella
           non ammette il carattere "." alla fine del nome stesso, ne' uno, ne' piu' di uno */
        if(isAlbum)
            while(temp.endsWith("."))
                temp = temp.substring(0, temp.length()-1);

        return temp.trim();
    }

    private boolean NonPrintable(char c)
    {
         return ((c >= 0 && c <= 31) || (c == 127));
    }

    private boolean NotAllowed(char c)
    {
         return ( c == '\\' || c == '/' || c == '*' ||
                  c == '?'  || c == '<' || c == '>' ||
                  c == ':'  || c == '"' || c == '|' );
    }
}
