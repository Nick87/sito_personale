import java.awt.Cursor;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.swing.SwingWorker;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;

public class CountClass extends SwingWorker<Void, Void>
{
    private String SourcePath;
    private ArrayList filesToRename;
    private boolean Hidden;
    private GUI Gui;
    public CountClass(String source, ArrayList filestorename, boolean hidden, GUI gui)
    {
        SourcePath = source;
        filesToRename = filestorename;
        Hidden = hidden;
        Gui = gui;
    }

    @Override
    protected Void doInBackground()
    {
        int count = 0;
        File dir = new File(SourcePath);
        filesToRename.clear();
        List<File> allFiles = (List<File>) FileUtils.listFiles(dir, TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE);
        Gui.setCursor(new Cursor(Cursor.WAIT_CURSOR));
        Gui.GetProgressBar().setIndeterminate(true);
        for (File file : allFiles)
            if(file.isFile() && file.getAbsolutePath().toLowerCase().endsWith(".mp3"))
                if(file.isHidden() == Hidden) {
                     count++;
                     filesToRename.add(file.getAbsolutePath());
                }
        Gui.SetnMP3(count);
        Gui.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        Gui.GetProgressBar().setIndeterminate(false);
        return null;
    }
}
