import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.File;
import java.util.ArrayList;
import java.util.Stack;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class GUI extends javax.swing.JFrame
{
    public GUI(String title)
    {
        super(title);
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException ex) {
        } catch (InstantiationException ex) {
        } catch (IllegalAccessException ex) {
        } catch (UnsupportedLookAndFeelException ex) {}
        initComponents();
        setIconImage(new javax.swing.ImageIcon(iconPath).getImage());
        SourcePath = "";
        DestinationPath = "";
        worker = null;
        stack = new Stack();
        filesToRename = new ArrayList();
        btnAnnulla.setEnabled(false);        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        TopPanel = new javax.swing.JPanel();
        UpPanel = new javax.swing.JPanel();
        Up1Panel = new javax.swing.JPanel();
        CheckBoxPanel = new javax.swing.JPanel();
        checkEstesa = new javax.swing.JCheckBox();
        checkHidden = new javax.swing.JCheckBox();
        checkCover = new javax.swing.JCheckBox();
        ConvertiAzzeraPanel = new javax.swing.JPanel();
        btnConverti = new javax.swing.JButton();
        btnAnnulla = new javax.swing.JButton();
        checkScroll = new javax.swing.JCheckBox();
        jPanel2 = new javax.swing.JPanel();
        Up2Panel = new javax.swing.JPanel();
        btnDa = new javax.swing.JButton();
        labelDa = new javax.swing.JLabel();
        btnA = new javax.swing.JButton();
        labelA = new javax.swing.JLabel();
        Up3Panel = new javax.swing.JPanel();
        ProgressBar = new javax.swing.JProgressBar();
        Up4Panel = new javax.swing.JPanel();
        lblFiltro = new javax.swing.JLabel();
        txtFiltro = new javax.swing.JTextField();
        DownPanel = new javax.swing.JPanel();
        TextAreaPanel = new javax.swing.JPanel();
        scrollPane = new javax.swing.JScrollPane();
        Log = new javax.swing.JTextArea();
        StatusBarPanel = new javax.swing.JPanel();
        StatusBarLeft = new javax.swing.JPanel();
        labelStatus1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        StatusBarRight = new javax.swing.JPanel();
        labelStatus2 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(410, 538));

        TopPanel.setLayout(new java.awt.GridBagLayout());

        UpPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Impostazioni", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N
        UpPanel.setLayout(new java.awt.GridBagLayout());

        Up1Panel.setLayout(new java.awt.GridBagLayout());

        CheckBoxPanel.setLayout(new javax.swing.BoxLayout(CheckBoxPanel, javax.swing.BoxLayout.Y_AXIS));

        checkEstesa.setText("Modalità estesa");
        CheckBoxPanel.add(checkEstesa);

        checkHidden.setText("Includi file nascosti");
        CheckBoxPanel.add(checkHidden);

        checkCover.setText("Estrai cover");
        CheckBoxPanel.add(checkCover);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        Up1Panel.add(CheckBoxPanel, gridBagConstraints);

        ConvertiAzzeraPanel.setLayout(new java.awt.GridBagLayout());

        btnConverti.setText("Converti");
        btnConverti.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConvertiActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        ConvertiAzzeraPanel.add(btnConverti, gridBagConstraints);

        btnAnnulla.setText("Annulla");
        btnAnnulla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnnullaActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        ConvertiAzzeraPanel.add(btnAnnulla, gridBagConstraints);

        checkScroll.setSelected(true);
        checkScroll.setText("Scroll");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        ConvertiAzzeraPanel.add(checkScroll, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        Up1Panel.add(ConvertiAzzeraPanel, gridBagConstraints);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 190, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 69, Short.MAX_VALUE)
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        Up1Panel.add(jPanel2, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        UpPanel.add(Up1Panel, gridBagConstraints);

        Up2Panel.setLayout(new java.awt.GridBagLayout());

        btnDa.setText("Da:");
        btnDa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDaActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        Up2Panel.add(btnDa, gridBagConstraints);

        labelDa.setFont(new java.awt.Font("Tahoma", 1, 11));
        labelDa.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        labelDa.setText(" ");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(0, 4, 0, 0);
        Up2Panel.add(labelDa, gridBagConstraints);

        btnA.setText("A:");
        btnA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        Up2Panel.add(btnA, gridBagConstraints);

        labelA.setFont(new java.awt.Font("Tahoma", 1, 11));
        labelA.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        labelA.setText(" ");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 4, 0, 0);
        Up2Panel.add(labelA, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        UpPanel.add(Up2Panel, gridBagConstraints);

        Up3Panel.setLayout(new java.awt.GridBagLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        Up3Panel.add(ProgressBar, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipady = 12;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(3, 0, 3, 0);
        UpPanel.add(Up3Panel, gridBagConstraints);

        Up4Panel.setLayout(new java.awt.GridBagLayout());

        lblFiltro.setText("Filtro:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        Up4Panel.add(lblFiltro, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        Up4Panel.add(txtFiltro, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        UpPanel.add(Up4Panel, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        TopPanel.add(UpPanel, gridBagConstraints);

        DownPanel.setLayout(new java.awt.GridBagLayout());

        TextAreaPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        TextAreaPanel.setLayout(new java.awt.GridBagLayout());

        Log.setColumns(20);
        Log.setEditable(false);
        Log.setFont(new java.awt.Font("Courier New", 0, 12));
        Log.setRows(5);
        scrollPane.setViewportView(Log);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        TextAreaPanel.add(scrollPane, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 2, 0, 2);
        DownPanel.add(TextAreaPanel, gridBagConstraints);

        StatusBarPanel.setLayout(new java.awt.GridBagLayout());

        StatusBarLeft.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        StatusBarLeft.setLayout(new java.awt.GridBagLayout());

        labelStatus1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        labelStatus1.setText("Pronto");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(0, 2, 0, 0);
        StatusBarLeft.add(labelStatus1, gridBagConstraints);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 157, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 14, Short.MAX_VALUE)
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        StatusBarLeft.add(jPanel1, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        StatusBarPanel.add(StatusBarLeft, gridBagConstraints);

        StatusBarRight.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        StatusBarRight.setLayout(new java.awt.GridBagLayout());

        labelStatus2.setText("Pronto");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(0, 2, 0, 0);
        StatusBarRight.add(labelStatus2, gridBagConstraints);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 157, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 14, Short.MAX_VALUE)
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        StatusBarRight.add(jPanel4, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        StatusBarPanel.add(StatusBarRight, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        DownPanel.add(StatusBarPanel, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        TopPanel.add(DownPanel, gridBagConstraints);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 390, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 500, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnConvertiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConvertiActionPerformed
        if(SourcePath.equals("") || DestinationPath.equals("")){
            JOptionPane.showMessageDialog(this, "Scegliere la cartella sorgente e/o la cartella destinazione.",
                                          "Errore", JOptionPane.ERROR_MESSAGE);
            return;
        }
        worker = new TagParser(DestinationPath, filesToRename, txtFiltro.getText(),
                               checkEstesa.isSelected(), checkCover.isSelected(),
                               gui);

        ProgressBar.setMinimum(0);
        ProgressBar.setValue(0);
        ProgressBar.setMaximum(nMP3);
        Log.setText(null);
        checkBoxSetEnabled(false);
        btnSetEnabled(false, true, false, false);
        txtFiltro.setEditable(false);
        worker.execute();
    }//GEN-LAST:event_btnConvertiActionPerformed

    private void btnAnnullaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnnullaActionPerformed
        if(worker == null) return;

        worker.Cancel();
        checkBoxSetEnabled(true);
        btnSetEnabled(true, false, true, true);
        txtFiltro.setEditable(true);
        Toolkit.getDefaultToolkit().beep();
    }//GEN-LAST:event_btnAnnullaActionPerformed

    private void btnDaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDaActionPerformed
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Scegli la directory sorgente");
        chooser.setCurrentDirectory(new File(System.getenv("USERPROFILE")+"\\Desktop"));
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        if(chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
        {
            SourcePath = chooser.getSelectedFile().getAbsolutePath();
            labelDa.setText(SourcePath);
            gui.setMinimumSize(InitialFrameSize);
            gui.pack();
            if(gui.getSize().getWidth() > FrameSize.getWidth())
            {
                FrameSize = gui.getSize();
                stack.push(FrameSize);
                gui.setMinimumSize(FrameSize);
                gui.setSize(FrameSize);
            }
            else if ((gui.getSize().getWidth() < FrameSize.getWidth()) &&
                        gui.getSize().getWidth() > InitialFrameSize.getWidth())
            {
                try {
                    FrameSize = (Dimension) stack.pop();
                    FrameSize = (Dimension) stack.pop();
                } catch (Exception e) {}
                gui.setMinimumSize(FrameSize);
                gui.setSize(FrameSize);
            }
            if ((gui.getSize().getWidth() < FrameSize.getWidth()) &&
                 gui.getSize().getWidth() < InitialFrameSize.getWidth())
            {
                gui.setMinimumSize(InitialFrameSize);
                gui.setSize(InitialFrameSize);
            }
            ProgressBar.setMinimum(0);
            ProgressBar.setValue(0);
            new CountClass(SourcePath, filesToRename, checkHidden.isSelected(), gui).execute();
        }
    }//GEN-LAST:event_btnDaActionPerformed

    private void btnAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAActionPerformed
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Scegli la directory destinazione");
        chooser.setCurrentDirectory(new File(System.getenv("USERPROFILE")+"\\Desktop"));
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        if(chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
        {
            DestinationPath = chooser.getSelectedFile().getAbsolutePath();
            labelA.setText(DestinationPath);
            gui.setMinimumSize(new Dimension(0, 0));
            gui.pack();
            if(gui.getSize().getWidth() > FrameSize.getWidth()) {
                FrameSize = gui.getSize();
                stack.push(FrameSize);
                gui.setMinimumSize(FrameSize);
                gui.setSize(FrameSize);
            } else if ((gui.getSize().getWidth() < FrameSize.getWidth()) &&
                        gui.getSize().getWidth() > InitialFrameSize.getWidth()){
                FrameSize = (Dimension) stack.pop();
                FrameSize = (Dimension) stack.pop();
                gui.setMinimumSize(FrameSize);
                gui.setSize(FrameSize);
            }
            if ((gui.getSize().getWidth() < FrameSize.getWidth()) &&
                 gui.getSize().getWidth() < InitialFrameSize.getWidth())
            {
                gui.setMinimumSize(InitialFrameSize);
                gui.setSize(InitialFrameSize);
            }
            ProgressBar.setMinimum(0);
            ProgressBar.setValue(0);
        }
    }//GEN-LAST:event_btnAActionPerformed

    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                gui = new GUI("Conversione MP3");
                FrameSize = InitialFrameSize = gui.getSize();
                gui.setMinimumSize(InitialFrameSize);
                gui.setVisible(true);
            }
        });
    }

    public void SetnMP3(int n)
    {
        nMP3 = n;
        ProgressBar.setMaximum(nMP3);
        gui.SetLabelStatusText("Trovati " + nMP3 + " mp3", null);
        gui.SetLabelStatusText(null, "MP3 rimasti: " + nMP3);
    }

    public void checkBoxSetEnabled(boolean val)
    {
        checkEstesa.setEnabled(val);
        checkHidden.setEnabled(val);
        checkCover.setEnabled(val);
    }

    public void btnSetEnabled(boolean val1, boolean val2, boolean val3, boolean val4)
    {
        btnConverti.setEnabled(val1);
        btnAnnulla.setEnabled(val2);
        btnDa.setEnabled(val3);
        btnA.setEnabled(val4);
    }

    public void SetLabelStatusText(String str1, String str2)
    {
        if(str1 != null) labelStatus1.setText(str1);
        if(str2 != null) labelStatus2.setText(str2);
    }

    public void logAppendText(String text)
    {
        Log.append(text);
    }

    public void Fine()
    {
        checkBoxSetEnabled(true);
        btnSetEnabled(true, false, true, true);
        txtFiltro.setEditable(true);
        Toolkit.getDefaultToolkit().beep();
    }

    public void Avanza()
    {
        ProgressBar.setValue(ProgressBar.getValue()+1);
    }

    public javax.swing.JTextArea GetLog()
    {
        return Log;
    }

    public javax.swing.JProgressBar GetProgressBar()
    {
        return ProgressBar;
    }

    public boolean Scroll()
    {
        return checkScroll.isSelected();
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel CheckBoxPanel;
    private javax.swing.JPanel ConvertiAzzeraPanel;
    private javax.swing.JPanel DownPanel;
    private javax.swing.JTextArea Log;
    private javax.swing.JProgressBar ProgressBar;
    private javax.swing.JPanel StatusBarLeft;
    private javax.swing.JPanel StatusBarPanel;
    private javax.swing.JPanel StatusBarRight;
    private javax.swing.JPanel TextAreaPanel;
    private javax.swing.JPanel TopPanel;
    private javax.swing.JPanel Up1Panel;
    private javax.swing.JPanel Up2Panel;
    private javax.swing.JPanel Up3Panel;
    private javax.swing.JPanel Up4Panel;
    private javax.swing.JPanel UpPanel;
    private javax.swing.JButton btnA;
    private javax.swing.JButton btnAnnulla;
    private javax.swing.JButton btnConverti;
    private javax.swing.JButton btnDa;
    private javax.swing.JCheckBox checkCover;
    private javax.swing.JCheckBox checkEstesa;
    private javax.swing.JCheckBox checkHidden;
    private javax.swing.JCheckBox checkScroll;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JLabel labelA;
    private javax.swing.JLabel labelDa;
    private javax.swing.JLabel labelStatus1;
    private javax.swing.JLabel labelStatus2;
    private javax.swing.JLabel lblFiltro;
    private javax.swing.JScrollPane scrollPane;
    private javax.swing.JTextField txtFiltro;
    // End of variables declaration//GEN-END:variables

    private static GUI gui;
    private String SourcePath;
    private String DestinationPath;
    private String iconPath = "icon.png";
    private static Dimension FrameSize;
    private static Dimension InitialFrameSize;
    private static Stack stack;
    private TagParser worker;
    private ArrayList filesToRename;
    private int OldCursorState;
    private volatile int nMP3;
}
