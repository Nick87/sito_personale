#ifndef _CONVERSIONE_MP3_H_
#define _CONVERSIONE_MP3_H_

#include <wx/wx.h>
#include <wx/dir.h>
#include <wx/file.h>

//#include <wx/iconbndl.h>

class ConversioneMP3:public wxFrame
{
    public:
	        ConversioneMP3(const wxString&, const wxSize&);
	        virtual ~ConversioneMP3();

    private:
	        void OnClose(wxCloseEvent&);
	        void OnInfo(wxCommandEvent&);
	        void OnHelp(wxCommandEvent&);
	        void OnConverti(wxCommandEvent&);
	        void OnAzzera(wxCommandEvent&);
	        void OnSfogliaDa(wxCommandEvent&);
	        void OnSfogliaA(wxCommandEvent&);
	        void Stampa(const wxString&, bool);
	        bool NonPrintable(char);
	        bool NotAllowed(char);
	        bool TagArtista(const wxString&);
	        bool TagTitolo(const wxString&);
	        bool TagAlbum(const wxString&);
	        bool NonValido(wxString&);
	        bool Start(bool);
	        bool Filtra(const wxString&);
	        int  MyStrlen(const char *);
	        int  ShowMessage(const wxString&, const wxString& = _T("Messaggio"), int = wxOK | wxICON_INFORMATION);
	        void ParseMP3(const char *, size_t, bool);
	        void GetTagLetteraPerLettera(const char *, int, wxString&);
	        void GetTagFineFile(char *, wxString&, FILE *, int, int);
	        void MyCopyFile(const wxString&, const wxString&, const wxString&);
	        void FixName(wxString&, bool);
	        void FinalMessage();
	        inline void MyMkdir(const wxString&);
	        void Reset();

	        wxIconBundle bundle;

	        wxPanel      * panel;
            wxMenuBar    * menubar;
            wxMenu       * info;
            wxStaticBox  * staticBox;
            wxCheckBox   * estesa;
            wxCheckBox   * ricorsiva;
            wxCheckBox   * nascosti;
            wxButton     * btnConverti;
            wxButton     * btnAzzera;
            wxButton     * btnSfogliaDa;
            wxStaticText * dir_source;
            wxButton     * btnSfogliaA;
            wxStaticText * dir_dest;
            wxStaticText * space;
            wxStaticText * sfilter;
            wxTextCtrl   * filter;
            wxGauge      * gauge;
            wxTextCtrl   * log;

            wxBoxSizer   * vbox;
            wxBoxSizer   * vbox2;
            wxBoxSizer   * vbox3;
            wxBoxSizer   * hbox1;
            wxBoxSizer   * hbox2;
            wxBoxSizer   * hbox3;
            wxBoxSizer   * hbox4;
            wxBoxSizer   * hbox5;
            wxBoxSizer   * hbox6;

            wxStaticBoxSizer * sbox;

            size_t TempoTrascorso;
	        size_t MaxSize;
	        size_t TotMP3;
	        bool CheckRic;
	        bool CheckNascosti;
	        int flags;
	        int nMP3Convertiti;
	        int Errori;
	        int Progr;

	        wxFile logFile;
	        wxFile errFile;

            wxDir DirHandle;
            wxArrayString AllFiles;

	        wxString artista;
	        wxString titolo;
	        wxString album;
	        wxString mp3_dir_source;
	        wxString mp3_dir_dest;
	        wxString err_log_file;
	        wxString log_file;
};

#endif
