#include "ConversioneMP3.h"
#include <wx/filefn.h>
#include <wx/filename.h>
#include <wx/datetime.h>
#include <wx/dirdlg.h>
#include <wx/file.h>

enum
{
    BTN_INFO = 1,
    BTN_HELP,
    BTN_SFOGLIA_DA,
    BTN_SFOGLIA_A,
    BTN_CONVERTI,
    BTN_AZZERA
};

const char * TAG[] = { "AENC", "APIC", "COMM", "COMR", "ENCR", "EQUA", "ETCO", "GEOB",
                       "GRID", "IPLS", "LINK", "MCDI", "MLLT", "OWNE", "PRIV", "PCNT",
                       "POPM", "POSS", "RBUF", "RVAD", "RVRB", "SYLT", "SYTC", "TALB",
                       "TBPM", "TCOM", "TCON", "TCOP", "TDAT", "TDLY", "TENC", "TEXT",
                       "TFLT", "TIME", "TIT1", "TIT2", "TIT3", "TKEY", "TLAN", "TLEN",
                       "TMED", "TOAL", "TOFN", "TOLY", "TOPE", "TORY", "TOWN", "TPE1",
                       "TPE2", "TPE3", "TPE4", "TPOS", "TPUB", "TRCK", "TRDA", "TRSN",
                       "TRSO", "TSIZ", "TSRC", "TSSE", "TYER", "TXXX", "UFID", "USER",
                       "USLT", "WCOM", "WCOP", "WOAF", "WOAR", "WOAS", "WORS", "WPAY",
                       "WPUB", "WXXX", "ASPI", "EQU2", "RVA2", "SEEK", "SIGN", "TDEN",
                       "TDOR", "TDRC", "TDRL", "TDTG", "TIPL", "TMCL", "TMOO", "TPRO",
                       "TSOA", "TSOP", "TSOT", "TSST", "TT1",  "TT2",  "TT3",  "TP1",
                       "TP2",  "TP3",  "TP4",  "TAL",  "TCO",  "TRK",  "TYE",  "TCP",
                       "PIC" };

const char * TAG_Artista_Titolo_Album [] = { "TP1", "TP2", "TP3", "TP4",  "TPE1", "TPE2", "TPE3", "TPE4",
                                             "TT1", "TT2", "TT3", "TIT1", "TIT2", "TIT3", "TAL",  "TALB" };

ConversioneMP3::ConversioneMP3(const wxString& title, const wxSize& minsize)
               :wxFrame(NULL, -1, title, wxPoint(-1, -1), minsize,
                wxDEFAULT_FRAME_STYLE /*& ~(wxRESIZE_BORDER | wxRESIZE_BOX | wxMAXIMIZE_BOX)*/)
{
     panel     = new wxPanel(this, -1);
     menubar   = new wxMenuBar;
     info      = new wxMenu;
     vbox      = new wxBoxSizer(wxVERTICAL);
     vbox2     = new wxBoxSizer(wxVERTICAL);
     vbox3     = new wxBoxSizer(wxVERTICAL);
     staticBox = new wxStaticBox(panel, wxID_ANY, _T("Impostazioni"));
     sbox      = new wxStaticBoxSizer(staticBox, wxVERTICAL);
     hbox1     = new wxBoxSizer(wxHORIZONTAL);
     hbox2     = new wxBoxSizer(wxHORIZONTAL);
     hbox3     = new wxBoxSizer(wxHORIZONTAL);
     hbox4     = new wxBoxSizer(wxHORIZONTAL);
     hbox5     = new wxBoxSizer(wxHORIZONTAL);
     hbox6     = new wxBoxSizer(wxHORIZONTAL);
     MaxSize   = 5000;
     flags     = wxDIR_DEFAULT;
     CheckRic  = CheckNascosti = false;
     TotMP3 = Progr = nMP3Convertiti = Errori = 0;
     mp3_dir_source = err_log_file = log_file = mp3_dir_dest = _T("");

     info->Append(BTN_INFO, _T("&Autore"), _T("Informazioni sull'autore"));
     info->Append(BTN_HELP, _T("&Help\tF1"), _T("Informazioni sul programma"));
     menubar->Append(info, _T("?"));
     SetMenuBar(menubar);

     estesa = new wxCheckBox(panel, wxID_ANY, _("Modalità &estesa"));
     estesa->SetValue(false);
     ricorsiva = new wxCheckBox(panel, wxID_ANY, _T("Includi &sotto-cartelle"));
     ricorsiva->SetValue(false);
     nascosti = new wxCheckBox(panel, wxID_ANY, _T("Includi file &nascosti"));
     nascosti->SetValue(false);
     vbox2->Add(estesa, 0, wxALL, 3);
     vbox2->Add(ricorsiva, 0, wxALL, 3);
     vbox2->Add(nascosti, 0, wxALL, 3);
     hbox1->Add(vbox2, 0, wxALL, 3);

     space = new wxStaticText(panel, wxID_ANY, _T(""));
     btnConverti = new wxButton(panel, BTN_CONVERTI, _T("&Converti"));
     btnAzzera = new wxButton(panel, BTN_AZZERA, _T("A&zzera"));
     hbox1->Add(space, 1, wxEXPAND);
     vbox3->Add(btnConverti, 0, wxTOP | wxRIGHT, 1);
     vbox3->Add(btnAzzera, 0, wxTOP | wxRIGHT, 1);
     hbox1->Add(vbox3, 0, wxEXPAND);
     sbox->Add(hbox1, 0, wxEXPAND);

     btnSfogliaDa = new wxButton(panel, BTN_SFOGLIA_DA, _T("&Da:"), wxDefaultPosition, wxSize(35, 25), wxBU_LEFT);
     dir_source = new wxStaticText(panel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize);
     hbox2->Add(btnSfogliaDa, 0, wxLEFT | wxBOTTOM, 1);
	 hbox2->Add(dir_source, 1, wxLEFT | wxBOTTOM | wxALIGN_LEFT | wxALIGN_CENTRE, 1);
     sbox->Add(hbox2, 0, wxEXPAND);

     btnSfogliaA  = new wxButton(panel, BTN_SFOGLIA_A, _T("&A:"), wxDefaultPosition, wxSize(35, 25), wxBU_LEFT);
     dir_dest = new wxStaticText(panel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize);
     hbox3->Add(btnSfogliaA, 0, wxLEFT | wxBOTTOM, 1);
	 hbox3->Add(dir_dest, 1, wxLEFT | wxBOTTOM | wxALIGN_LEFT | wxALIGN_CENTRE, 1);
     sbox->Add(hbox3, 0, wxEXPAND);

     gauge = new wxGauge(panel, wxID_ANY, 0, wxDefaultPosition, wxDefaultSize, wxGA_HORIZONTAL | wxGA_SMOOTH);
     hbox4->Add(gauge, 1);
     sbox->Add(hbox4, 0, wxEXPAND | wxLEFT | wxRIGHT | wxBOTTOM, 1);

     sfilter = new wxStaticText(panel, wxID_ANY, _T("&Filtro:"));
     filter  = new wxTextCtrl(panel, wxID_ANY, _T(""));
     hbox5->Add(sfilter, 0, wxALIGN_CENTRE | wxLEFT, 2);
     hbox5->Add(filter, 1, wxLEFT | wxTOP | wxALIGN_CENTRE, 2);
     sbox->Add(hbox5, 0, wxEXPAND);

     vbox->Add(sbox, 0, wxEXPAND | wxALL, 5);

     log = new wxTextCtrl(panel, wxID_ANY, _T(""), wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE | wxTE_DONTWRAP | wxTE_READONLY);
     hbox6->Add(log, 1, wxEXPAND);
     vbox->Add(hbox6, 1, wxEXPAND);

     Connect(BTN_INFO, wxEVT_COMMAND_MENU_SELECTED, wxCommandEventHandler(ConversioneMP3::OnInfo));
     Connect(BTN_HELP, wxEVT_COMMAND_MENU_SELECTED, wxCommandEventHandler(ConversioneMP3::OnHelp));
     Connect(BTN_SFOGLIA_DA, wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler(ConversioneMP3::OnSfogliaDa));
     Connect(BTN_SFOGLIA_A, wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler(ConversioneMP3::OnSfogliaA));
     Connect(BTN_CONVERTI, wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler(ConversioneMP3::OnConverti));
     Connect(BTN_AZZERA, wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler(ConversioneMP3::OnAzzera));
	 Connect(wxEVT_CLOSE_WINDOW, wxCloseEventHandler(ConversioneMP3::OnClose));

	 panel->SetSizer(vbox);
     SetMinSize(minsize);
     /*vbox->Fit(this);
     vbox->SetSizeHints(this);*/

	 CreateStatusBar(2);
	 SetStatusText(_T("Pronto"));
	 /*bundle.AddIcon((wxIcon(_T("iPod.ico"))));
	 SetIcons(bundle);*/

	 Centre();
}

ConversioneMP3::~ConversioneMP3() {}

void ConversioneMP3::Reset()
{
     SetStatusText(_T("Pronto"));
     SetStatusText(_T(""), 1);
	 gauge->SetValue(0);
	 flags     = wxDIR_DEFAULT;
     CheckRic  = CheckNascosti = false;
     TotMP3 = Progr = nMP3Convertiti = Errori = 0;
}

void ConversioneMP3::OnAzzera(wxCommandEvent& event)
{
     Reset();
     mp3_dir_source = mp3_dir_dest = _T("");
     dir_source->SetLabel(_T(""));
     dir_dest->SetLabel(_T(""));
     estesa->SetValue(false);
     ricorsiva->SetValue(false);
     nascosti->SetValue(false);
     filter->Clear();
     log->Clear();
}

void ConversioneMP3::OnClose(wxCloseEvent& event)
{
     int ret = ShowMessage(_T("Vuoi realmente uscire?"), _T("Conferma"), wxYES_NO | wxYES_DEFAULT | wxICON_QUESTION);
     if (ret == wxID_YES)
          Destroy();
     else
          event.Veto();
}

void ConversioneMP3::OnInfo(wxCommandEvent& event)
{
     ShowMessage(_T("Realizzato da Nicola Alessandro Domingo."), _T("Autore"));
}

void ConversioneMP3::OnHelp(wxCommandEvent& event)
{
     wxString str;
     str = _T("1. Seleziona la cartella sorgente contentente gli mp3.\n"
	           "2. Seleziona la cartella di destinazione in cui salvare gli mp3.\n"
               "3. Spunta \"Modalità estesa\" se si vuole che il programma\n"
               "    organizzi gli mp3 in cartelle divise per artista e album.\n"
               "4. Spunta \"Includi-sottocartelle\" se si vuole estendere la\n"
               "    conversione anche alle sotto-cartelle.\n"
               "5. Spunta \"Includi file nascosti\" si si vuole estendere la\n"
               "    conversione anche ai file nascosti.\n"
               "6. Scrivi in \"Filtro\" quale stringa cercare in artista, titolo e album\n"
               "    (si può lasciare anche vuoto).\n"
               "7. Premi \"Converti\".");
     ShowMessage(str, _T("Aiuto"));
}

void ConversioneMP3::OnSfogliaDa(wxCommandEvent& event)
{
     wxDirDialog * DirDialog = new wxDirDialog(panel, _T("Cartella sorgente mp3"), wxEmptyString, wxDD_DIR_MUST_EXIST);
     if(DirDialog->ShowModal() == wxID_OK)
          mp3_dir_source = DirDialog->GetPath();
     DirDialog->Destroy();

     if(DirHandle.Open(mp3_dir_source) != true){
         ShowMessage(_T("Impossibile aprire cartella"), _T("Errore"), wxOK | wxICON_ERROR);
         //Reset();
         return;
     }

     if(ricorsiva->IsChecked()){
         CheckRic = true;
         flags |= wxDIR_DIRS;
     }else{
         CheckRic = false;
         flags &= (~wxDIR_DIRS);
     }
     if(nascosti->IsChecked()){
         CheckNascosti = true;
         flags |= wxDIR_HIDDEN;
     }else{
         CheckNascosti = false;
         flags &= (~wxDIR_HIDDEN);
     }

     TotMP3 = DirHandle.GetAllFiles(mp3_dir_source, &AllFiles, _T("*.mp3"), flags);
     if(TotMP3 <= 0){
         ShowMessage(_T("Nessun mp3 trovato nella cartella.\nProva ad includere sotto-cartelle e/o file nascosti."),
                     _T("Errore"), wxOK | wxICON_ERROR);
         //Reset();
         return;
     }

     dir_source->SetLabel(_T(" ") + mp3_dir_source);
     gauge->SetRange(TotMP3);
     SetStatusText(wxString::Format(_T("%d mp3 trovati"), TotMP3));
}

void ConversioneMP3::OnSfogliaA(wxCommandEvent& event)
{
 	 wxDirDialog * DirDialog = new wxDirDialog(panel, _T("Cartella destinazione mp3"));
 	 if(DirDialog->ShowModal() == wxID_OK){
          mp3_dir_dest = DirDialog->GetPath();
	      dir_dest->SetLabel(_T(" ") + mp3_dir_dest);
     }
     DirDialog->Destroy();
}

void ConversioneMP3::OnConverti(wxCommandEvent& event)
{
     int actual_flags = wxDIR_DEFAULT;
     if(mp3_dir_source == _T("") || mp3_dir_dest == _T("")){
         ShowMessage(_T("Selezionare cartella/e"), _T("Errore"), wxOK | wxICON_EXCLAMATION);
         //Reset();
         return;
     }

     #if defined(WIN32) || defined(__MINGW32__)
         log_file = mp3_dir_dest + _T("\\log.txt");
     #else
         log_file = mp3_dir_dest + _T("/log");
     #endif
     if(!logFile.Open(log_file.c_str(), wxFile::write)){
         ShowMessage(_T("Impossibile creare file di log"), _T("Errore"), wxOK | wxICON_ERROR);
         //Reset();
         return;
     }

     #if defined(WIN32) || defined(__MINGW32__)
         err_log_file = mp3_dir_dest + _T("\\errori.txt");
     #else
         err_log_file = mp3_dir_dest + _T("/errori");
     #endif
     if(!errFile.Open(err_log_file.c_str(), wxFile::write)){
         ShowMessage(_T("Impossibile creare file di log per gli errori"), _T("Errore"), wxOK | wxICON_ERROR);
         //Reset();
         return;
     }

     if(!ricorsiva->IsChecked())
         actual_flags &= (~wxDIR_DIRS);
     if(!nascosti->IsChecked())
         actual_flags &= (~wxDIR_HIDDEN);

     if((CheckRic       && ((actual_flags & wxDIR_DIRS) == 0x0000))        ||
        (!CheckRic      && ((actual_flags & wxDIR_DIRS) == wxDIR_DIRS))    ||
        (CheckNascosti  && ((actual_flags & wxDIR_HIDDEN) == 0x0000))      ||
        (!CheckNascosti && ((actual_flags & wxDIR_HIDDEN) == wxDIR_HIDDEN)))
     {
         int ret = ShowMessage(_T("Impostazioni inclusione sotto-cartelle e/o file nascosti cambiate. Continuare?"),
                               _T("Conferma"), wxYES_NO | wxYES_DEFAULT | wxICON_QUESTION);
         if (ret == wxID_NO) goto fine;
     }

     TempoTrascorso = wxDateTime::GetTimeNow();
     Start(estesa->IsChecked());
     TempoTrascorso = wxDateTime::GetTimeNow()-TempoTrascorso;
     FinalMessage();

     fine:
     logFile.Close();
     errFile.Close();
     Reset();
}

void ConversioneMP3::FinalMessage()
{
     wxString str;
     str.Printf(_T("Sono stati convertiti %d mp3 in "), TotMP3);
     if(TempoTrascorso < 60)
         str += wxString::Format(_T("00:%02d\n"), TempoTrascorso);
     else
         str += wxString::Format(_T("%02d:%02d\n"), TempoTrascorso/60, TempoTrascorso%60);
     str += _T("Ricontrollali poichè potrebbero esserci stati degli errori");
     ShowMessage(str);
}

bool ConversioneMP3::Start(bool extended)
{
     wxString AbsoluteFile, filter_str;
     FILE * file;
     size_t i, FileSize;
     char * buffer = NULL;

     log->Clear();
     filter_str = filter->GetValue();
     for(i = 0; i < AllFiles.Count(); i++)
     {
          wxFileName::SplitPath(AllFiles[i], NULL, NULL, &AbsoluteFile, NULL);
          Stampa(wxString::Format(_T("%s.mp3: "), AbsoluteFile.c_str()), false);
          ShowMessage(wxString::Format(_T("file: %s"), (const char *)AllFiles[i].c_str()));
          if((file = fopen((const char *)AllFiles[i].c_str(), "r+b")) == NULL)
          {
                Stampa(wxString::Format(_T("%s: Impossibile aprire il file\n"), AbsoluteFile.c_str()), true);
                Stampa(wxString::Format(_T("Impossibile aprire il file\n")), false);
          }
          else
          {
              fseek(file, 0, SEEK_END);
              FileSize = ftell(file)/3;
              rewind(file);

              buffer = (char *) calloc (FileSize, 1);
              artista = titolo = album = wxString::Format(_T(""));
              fread(buffer, 1, FileSize, file);

              ParseMP3(buffer, FileSize, extended || (!filter->IsEmpty()));

              //ShowMessage(wxString::Format(_T("Artista: %s\nTitolo: %s\nAlbum: %s\n"), artista.c_str(), titolo.c_str(), album.c_str()));

              if(artista.Len() == 0)
                  GetTagFineFile(buffer, artista, file, FileSize, 33);
              if(titolo.Len() == 0)
                  GetTagFineFile(buffer, titolo, file, FileSize, 3);
              if(album.Len() == 0 && (extended || (!filter->IsEmpty())))
                  GetTagFineFile(buffer, album, file, FileSize, 63);

              if(!Filtra(filter_str))
              {
                  Stampa(wxString::Format(_T("\n")), false);
                  Progr++;
                  gauge->SetValue(Progr);
                  SetStatusText(wxString::Format(_T("%d mp3 rimanenti"), TotMP3-Progr), 1);
                  goto next;
              }

              if(artista.Len() == 0 && album.Len() == 0 && titolo.Len() == 0)//000
              {
                    #if defined(WIN32) || defined(__MINGW32__)
                        MyCopyFile(AllFiles[i], AbsoluteFile+_T(".mp3"), mp3_dir_dest+_T("\\")+AbsoluteFile+_T(".mp3"));
                    #else
                        MyCopyFile(AllFiles[i], AbsoluteFile+_T(".mp3"), mp3_dir_dest+_T("/")+AbsoluteFile+_T(".mp3"));
                    #endif
              }
              else if(artista.Len() > 0 && album.Len() > 0 && titolo.Len() > 0)//111
              {
                    if(extended)
                    {
                         #if defined(WIN32) || defined(__MINGW32__)
                             MyMkdir(mp3_dir_dest+_T("\\")+artista+_T("\\"));
                             MyMkdir(mp3_dir_dest+_T("\\")+artista+_T("\\")+album+_T("\\"));
                             MyCopyFile(AllFiles[i],
                                        artista+_T(" - ")+titolo+_T(".mp3"),
                                        mp3_dir_dest+_T("\\")+artista+_T("\\")+album+_T("\\")+artista+_T(" - ")+titolo+_T(".mp3"));
                         #else
                             MyMkdir(mp3_dir_dest+_T("/")+artista+_T("/"));
                             MyMkdir(mp3_dir_dest+_T("/")+artista+_T("/")+album+_T("/"));
                             MyCopyFile(AllFiles[i],
                                        artista+_T(" - ")+titolo+_T(".mp3"),
                                        mp3_dir_dest+_T("/")+artista+_T("/")+album+_T("/")+artista+_T(" - ")+titolo+_T(".mp3"));
                         #endif
                    }
                    else
                    {
                         #if defined(WIN32) || defined(__MINGW32__)
                             MyCopyFile(AllFiles[i],
                                        artista+_T(" - ")+titolo+_T(".mp3"),
                                        mp3_dir_dest+_T("\\")+artista+_T(" - ")+titolo+_T(".mp3"));
                         #else
                             MyCopyFile(AllFiles[i],
                                        artista+_T(" - ")+titolo+_T(".mp3"),
                                        mp3_dir_dest+_T("/")+artista+_T(" - ")+titolo+_T(".mp3"));
                         #endif
                    }
              }
              else if(artista.Len() == 0 && album.Len() == 0 && titolo.Len() > 0)//001
              {
                    #if defined(WIN32) || defined(__MINGW32__)
                        MyCopyFile(AllFiles[i], titolo+_T(".mp3"), mp3_dir_dest+_T("\\")+titolo+_T(".mp3"));
                    #else
                        MyCopyFile(AllFiles[i], titolo+_T(".mp3"), mp3_dir_dest+_T("/")+titolo+_T(".mp3"));
                    #endif
              }
              else if(artista.Len() == 0 && album.Len() > 0 && titolo.Len() == 0)//010
              {
                    if(extended)
                    {
                        #if defined(WIN32) || defined(__MINGW32__)
                            MyMkdir(mp3_dir_dest+_T("\\Artista Sconosciuto\\"));
                            MyMkdir(mp3_dir_dest+_T("\\Artista Sconosciuto\\")+album+_T("\\"));
                            MyCopyFile(AllFiles[i],
                                       AbsoluteFile+_T(".mp3"),
                                       mp3_dir_dest+_T("\\Artista Sconosciuto\\")+album+_T("\\")+AbsoluteFile+_T(".mp3"));
                        #else
                            MyMkdir(mp3_dir_dest+_T("/Artista Sconosciuto/"));
                            MyMkdir(mp3_dir_dest+_T("/Artista Sconosciuto/")+album+_T("/"));
                            MyCopyFile(AllFiles[i],
                                       AbsoluteFile+_T(".mp3"),
                                       mp3_dir_dest+_T("/Artista Sconosciuto/")+album+_T("/")+AbsoluteFile+_T(".mp3"));
                        #endif
                    }
                    else
                    {
                        #if defined(WIN32) || defined(__MINGW32__)
                            MyCopyFile(AllFiles[i],
                                       AbsoluteFile+_T(".mp3"),
                                       mp3_dir_dest+_T("\\")+AbsoluteFile+_T(".mp3"));
                        #else
                            MyCopyFile(AllFiles[i],
                                       AbsoluteFile+_T(".mp3"),
                                       mp3_dir_dest+_T("/")+AbsoluteFile+_T(".mp3"));
                        #endif
                    }
              }
              else if(artista.Len() == 0 && album.Len() > 0 && titolo.Len() > 0)//011
              {
                    if(extended)
                    {
                         #if defined(WIN32) || defined(__MINGW32__)
                             MyMkdir(mp3_dir_dest+_T("\\Artista Sconosciuto\\"));
                             MyMkdir(mp3_dir_dest+_T("\\Artista Sconosciuto\\")+album+_T("\\"));
                             MyCopyFile(AllFiles[i],
                                        titolo+_T(".mp3"),
                                        mp3_dir_dest+_T("\\Artista Sconosciuto\\")+album+_T("\\")+titolo+_T(".mp3"));
                         #else
                             MyMkdir(mp3_dir_dest+_T("/Artista Sconosciuto/"));
                             MyMkdir(mp3_dir_dest+_T("/Artista Sconosciuto/")+album+_T("/"));
                             MyCopyFile(AllFiles[i],
                                        titolo+_T(".mp3"),
                                        mp3_dir_dest+_T("/Artista Sconosciuto/")+album+_T("/")+titolo+_T(".mp3"));
                         #endif
                    }
                    else
                    {
                        #if defined(WIN32) || defined(__MINGW32__)
                            MyCopyFile(AllFiles[i],
                                       titolo+_T(".mp3"),
                                       mp3_dir_dest+_T("\\")+titolo+_T(".mp3"));
                        #else
                            MyCopyFile(AllFiles[i],
                                       titolo+_T(".mp3"),
                                       mp3_dir_dest+_T("/")+titolo+_T(".mp3"));
                        #endif
                    }
              }
              else if(artista.Len() > 0 && album.Len() == 0 && titolo.Len() == 0)//100
              {
                    if(extended)
                    {
                         #if defined(WIN32) || defined(__MINGW32__)
                             MyMkdir(mp3_dir_dest+_T("\\")+artista+_T("\\"));
                             MyMkdir(mp3_dir_dest+_T("\\")+artista+_T("\\Album Sconosciuto\\"));
                             MyCopyFile(AllFiles[i],
                                        AbsoluteFile+_T(".mp3"),
                                        mp3_dir_dest+_T("\\")+artista+_T("\\Album Sconosciuto\\")+AbsoluteFile+_T(".mp3"));
                         #else
                             MyMkdir(mp3_dir_dest+_T("/")+artista+_T("/"));
                             MyMkdir(mp3_dir_dest+_T("/")+artista+_T("/Album Sconosciuto/"));
                             MyCopyFile(AllFiles[i],
                                        AbsoluteFile+_T(".mp3"),
                                        mp3_dir_dest+_T("/")+artista+_T("/Album Sconosciuto/")+AbsoluteFile+_T(".mp3"));
                         #endif
                    }
                    else
                    {
                         #if defined(WIN32) || defined(__MINGW32__)
                             MyCopyFile(AllFiles[i],
                                        AbsoluteFile+_T(".mp3"),
                                        mp3_dir_dest+_T("\\")+artista+_T(".mp3"));
                         #else
                             MyCopyFile(AllFiles[i],
                                        AbsoluteFile+_T(".mp3"),
                                        mp3_dir_dest+_T("/")+artista+_T(".mp3"));
                         #endif
                    }

              }
              else if(artista.Len() > 0 && album.Len() == 0 && titolo.Len() > 0)//101
              {
                    if(extended)
                    {
                         #if defined(WIN32) || defined(__MINGW32__)
                             MyMkdir(mp3_dir_dest+_T("\\")+artista+_T("\\"));
                             MyMkdir(mp3_dir_dest+_T("\\")+artista+_T("\\Album Sconosciuto\\"));
                             MyCopyFile(AllFiles[i],
                                        artista+_T(" - ")+titolo+_T(".mp3"),
                                        mp3_dir_dest+_T("\\")+artista+_T("\\Album Sconosciuto\\")+artista+_T(" - ")+titolo+_T(".mp3"));
                         #else
                             MyMkdir(mp3_dir_dest+_T("/")+artista+_T("/"));
                             MyMkdir(mp3_dir_dest+_T("/")+artista+_T("/Album Sconosciuto/"));
                             MyCopyFile(AllFiles[i],
                                        artista+_T(" - ")+titolo+_T(".mp3"),
                                        mp3_dir_dest+_T("/")+artista+_T("/Album Sconosciuto/")+artista+_T(" - ")+titolo+_T(".mp3"));
                         #endif
                    }
                    else
                    {
                        #if defined(WIN32) || defined(__MINGW32__)
                             MyCopyFile(AllFiles[i],
                                        artista+_T(" - ")+titolo+_T(".mp3"),
                                        mp3_dir_dest+_T("\\")+artista+_T(" - ")+titolo+_T(".mp3"));
                         #else
                             MyCopyFile(AllFiles[i],
                                        artista+_T(" - ")+titolo+_T(".mp3"),
                                        mp3_dir_dest+_T("/")+artista+_T(" - ")+titolo+_T(".mp3"));
                         #endif
                    }
              }
              else if(artista.Len() > 0 && album.Len() > 0 && titolo.Len() == 0)//110
              {
                     if(extended)
                     {
                         #if defined(WIN32) || defined(__MINGW32__)
                             MyMkdir(mp3_dir_dest+_T("\\")+artista+_T("\\"));
                             MyMkdir(mp3_dir_dest+_T("\\")+artista+_T("\\")+album+_T("\\"));
                             MyCopyFile(AllFiles[i],
                                        artista+_T(".mp3"),
                                        mp3_dir_dest+_T("\\")+artista+_T("\\")+album+_T("\\")+artista+_T(".mp3"));
                         #else
                             MyMkdir(mp3_dir_dest+_T("/")+artista+_T("/"));
                             MyMkdir(mp3_dir_dest+_T("/")+artista+_T("/")+album+_T("/"));
                             MyCopyFile(AllFiles[i],
                                        artista+_T(".mp3"),
                                        mp3_dir_dest+_T("/")+artista+_T("/")+album+_T("/")+artista+_T(".mp3"));
                         #endif
                     }
                     else
                     {
                         #if defined(WIN32) || defined(__MINGW32__)
                             MyCopyFile(AllFiles[i],
                                        artista+_T(".mp3"),
                                        mp3_dir_dest+_T("\\")+artista+_T(".mp3"));
                         #else
                             MyCopyFile(AllFiles[i],
                                        artista+_T(".mp3"),
                                        mp3_dir_dest+_T("/")+artista+_T(".mp3"));
                         #endif
                     }
              }
          }
          next:
          fclose(file);
          free(buffer);
     }
     return true;
}

inline void ConversioneMP3::MyMkdir(const wxString& dirname)
{
     if(!wxFileName::DirExists(dirname))  wxMkdir(dirname);
}

void ConversioneMP3::MyCopyFile(const wxString& path1, const wxString& file_renamed, const wxString& path2)
{
     wxCopyFile(path1, path2, false);
     Stampa(wxString::Format(_T("%s\n"), file_renamed.c_str()), false);
     Progr++;
     gauge->SetValue(Progr);
     SetStatusText(wxString::Format(_T("%d mp3 rimanenti"), TotMP3-Progr), 1);
}

void ConversioneMP3::GetTagFineFile(char * buf, wxString& to, FILE * f, int size, int offset)
{
    int i, count;
    memset(buf, 0, size);
    fseek(f, -128, SEEK_END);
    fread(buf, 1, size, f);
    rewind(f);

    if(buf[0] == 'T' && buf[1] == 'A' && buf[2] == 'G')
    {
       for(count = 0, i = offset; buf[i] != 0 && count < 30; i++, count++)
          to.Append(buf[i]);
       FixName(to, 0);
    }
}

void ConversioneMP3::ParseMP3(const char * buf, size_t Size, bool cerca_album)
{
     int tot = 0, j, check, artista_fatto = 0, titolo_fatto = 0, album_fatto = 0;
     register unsigned int i = 0, count, index;
     char * ptr;
     char temp[MaxSize];

	 check = (cerca_album) ? 3 : 2;

     while(i < Size)
     {
         if(NonPrintable(buf[i]))
            i++;
         for(count = 0; count < MaxSize && (buf[i] < 0 || (buf[i] != 0 && buf[i] != 3)); count++, i++)
             temp[count] = buf[i];
         temp[count] = 0;

         for(count = 0; count < sizeof(TAG_Artista_Titolo_Album)/sizeof(char *); count++)
         {
             if(TagAlbum(wxString::Format(_T("%s"), TAG_Artista_Titolo_Album[count])) && !cerca_album)
                continue;
             if(tot == check)
                break;
             ptr = strstr(temp, TAG_Artista_Titolo_Album[count]);
             //A volte il TAG si trova come parte dell'mp3, se dopo di esso non c'e' NUL, non e' un TAG
             if(ptr == NULL || (ptr != NULL && temp[ptr-temp+strlen(TAG_Artista_Titolo_Album[count])] != 0))
                continue;

             ShowMessage(wxString::Format(_T("temp: |%s|%s|"), temp, ptr));

             //A volte dopo c'e' un carattere che rompe le palle, in quel caso
             //ritorniano la posizione successiva (NUL) ad esso
             index = i;
             for(; index < Size && NonPrintable(buf[index]); index++);

             //A volte dopo i NUL dopo il TAG ci sono dei caratteri strani (decimali -1 e -2)
             //In quel caso l'artista e il titolo sono divisi lettera per lettera
             if(buf[index] == -1 && buf[index+1] == -2)
             {
                 if(TagArtista(wxString::Format(_T("%s"), TAG_Artista_Titolo_Album[count]))){
                     if(artista_fatto) continue;
                     GetTagLetteraPerLettera(buf, index+2, artista);
                     FixName(artista, false);
                     if(NonValido(artista)) continue;
                     artista_fatto = 1;
                 }else if(TagTitolo(wxString::Format(_T("%s"), TAG_Artista_Titolo_Album[count]))){
                     if(titolo_fatto) continue;
                     GetTagLetteraPerLettera(buf, index+2, titolo);
                     FixName(titolo, false);
                     if(NonValido(titolo)) continue;
                     titolo_fatto = 1;
                 }else if(TagAlbum(wxString::Format(_T("%s"), TAG_Artista_Titolo_Album[count]))){
                     if(album_fatto) continue;
                     GetTagLetteraPerLettera(buf, index+2, album);
                     FixName(album, true);
                     if(NonValido(album)) continue;
                     album_fatto = 1;
                 }
                 tot++;
                 continue;
             }
             if(MyStrlen(buf+index) == 1)
                 index++;
             else
                 index = i;

             for(; index < Size && NonPrintable(buf[index]); index++);
             if(buf[index] == -1 && buf[index+1] == -2)
             {
                 if(TagArtista(wxString::Format(_T("%s"), TAG_Artista_Titolo_Album[count]))){
                     if(artista_fatto) continue;
                     GetTagLetteraPerLettera(buf, index+2, artista);
                     FixName(artista, false);
                     if(NonValido(artista)) continue;
                     artista_fatto = 1;
                 }else if(TagTitolo(wxString::Format(_T("%s"), TAG_Artista_Titolo_Album[count]))){
                     if(titolo_fatto) continue;
                     GetTagLetteraPerLettera(buf, index+2, titolo);
                     FixName(titolo, false);
                     if(NonValido(titolo)) continue;
                     titolo_fatto = 1;
                 }else if(TagAlbum(wxString::Format(_T("%s"), TAG_Artista_Titolo_Album[count]))){
                     if(album_fatto) continue;
                     GetTagLetteraPerLettera(buf, index+2, album);
                     FixName(album, true);
                     if(NonValido(album)) continue;
                     album_fatto = 1;
                 }
                 tot++;
                 continue;
             }
             else
             {
                 if(TagArtista(wxString::Format(_T("%s"), TAG_Artista_Titolo_Album[count])))
                 {
                     if(artista_fatto)  continue;
                     //Ho beccato l'artista, salto eventuali caratteri di controllo
                     for(; index < Size && NonPrintable(buf[index]); index++);
                     //Copio l'artista con eventuali TAG a seguire che vanno tolti
                     for(j = 0; index < Size && buf[index] != 0; index++, j++)
                             artista.Append(buf[index]);
                     FixName(artista, false);
                     if(NonValido(artista)) continue;
                     artista_fatto = 1;
                 }else if(TagTitolo(wxString::Format(_T("%s"), TAG_Artista_Titolo_Album[count]))){
                     if(titolo_fatto)  continue;
                     //Ho beccato il titolo, salto eventuali caratteri di controllo
                     for(; index < Size && NonPrintable(buf[index]); index++);
                     //Copio il titolo con eventuali TAG a seguire che vanno tolti
                     for(j = 0; index < Size && buf[index] != 0; index++, j++)
                             titolo.Append(buf[index]);
                     FixName(titolo, false);
                     if(NonValido(titolo)) continue;
                     titolo_fatto = 1;
                 }else if(TagAlbum(wxString::Format(_T("%s"), TAG_Artista_Titolo_Album[count]))){
                     if(album_fatto)  continue;
                     //Ho beccato il titolo, salto eventuali caratteri di controllo
                     for(; index < Size && NonPrintable(buf[index]); index++);
                     //Copio il titolo con eventuali TAG a seguire che vanno tolti
                     for(j = 0; index < Size && buf[index] != 0; index++, j++)
                             album.Append(buf[index]);
                     FixName(album, true);
                     if(NonValido(album)) continue;
                     album_fatto = 1;
                 }
                 tot++;
             }
         }
         //Ho gia' trovato artista e titolo (e album eventualmente),
		 //non c'e' motivo di continuare il while
         if(tot == check) break;
     }
}

void ConversioneMP3::FixName(wxString& str, bool is_album)
{
     size_t i;
     wxString temp;
     int index;

     //Eliminiamo caratteri non ammessi e non stampabili
     for(i = 0; i < str.Len(); i++)
        if(!(NotAllowed(str[i]) || NonPrintable(str[i])))
           temp.Append(str[i]);

     if(temp.Len() == 0) goto end;

     //Eliminiamo l'eventuale TAG
     for(i = 0; i < (sizeof(TAG)/sizeof(char *)); i++)
         if((index = temp.Find(wxString::Format(_T("%s"), TAG[i]))) != wxNOT_FOUND){
             temp.Remove(index);
             break;
         }

     if(temp.Len() == 0) goto end;

     /* Il nome di un album sara' quello di una cartella, ed il nome di una cartella
        non ammette il carattere "." alla fine del nome stesso, ne' uno, ne' piu' di uno*/
     if(is_album){
         while(temp[temp.Len()-1] == '.'){
             temp.Remove(temp.Len()-1);
             if(temp.Len() == 0) break;
         }
     }

     if(temp.Len() == 0) goto end;

     //Eliminiamo i leading spaces, cioe' gli spazi finali senza caratteri a seguire, es. "Ciao     "
     while(temp[temp.Len()-1] == ' '){
          temp.Remove(temp.Len()-1);
          if(temp.Len() == 0) break;
     }
     end:
     str = temp;
}

void ConversioneMP3::GetTagLetteraPerLettera(const char * from, int index, wxString& to)
{
     for(; from[index] != 0 && from[index+1] == 0 && strlen(from+index+2) == 1; index += 2)
         to.Append(from[index]);
     to.Append(from[index]);
}

int ConversioneMP3::MyStrlen(const char * str)
{
     int count;
     for(count = 0; !NonPrintable(str[count]); count++);
     return count;
}

void ConversioneMP3::Stampa(const wxString& str, bool err)
{
     if(!err){
         logFile.Write(str, wxConvLocal);
         logFile.Flush();
         log->AppendText(str);
     }else{
         errFile.Write(str, wxConvLocal);
         errFile.Flush();
     }
}

int ConversioneMP3::ShowMessage(const wxString& message, const wxString& caption, int flags)
{
     int ret;
     wxMessageDialog * dial = new wxMessageDialog(NULL, message, caption, flags);
     ret = dial->ShowModal();
     dial->Destroy();
     return ret;
}

bool ConversioneMP3::Filtra(const wxString& str)
{
     if(str.Len() == 0)   return true;

     wxString temp1 = str.Lower();
     wxString temp2 = artista.Lower();
     if(temp2.Find(temp1.c_str()) != wxNOT_FOUND) return true;
     temp2 = titolo.Lower();
     if(temp2.Find(temp1.c_str()) != wxNOT_FOUND) return true;
     temp2 = album.Lower();
     if(temp2.Find(temp1.c_str()) != wxNOT_FOUND) return true;
     return false;
}

bool ConversioneMP3::NonPrintable(char c)
{
     return ((c >= 0 && c <= 31) || (c == 127));
}

bool ConversioneMP3::NotAllowed(char c)
{
     return ( c == '\\' || c == '/' || c == '*' ||
              c == '?'  || c == '<' || c == '>' ||
              c == ':'  || c == '"' || c == '|' );
}

bool ConversioneMP3::TagArtista(const wxString& str)
{
     return (str == wxString::Format(_T("TP1"))  || str == wxString::Format(_T("TP2"))  ||
             str == wxString::Format(_T("TP3"))  || str == wxString::Format(_T("TP4"))  ||
             str == wxString::Format(_T("TPE1")) || str == wxString::Format(_T("TPE2")) ||
             str == wxString::Format(_T("TPE3")) || str == wxString::Format(_T("TPE4")));
}

bool ConversioneMP3::TagTitolo(const wxString& str)
{
     return (str == wxString::Format(_T("TT1"))  || str == wxString::Format(_T("TT2"))  ||
             str == wxString::Format(_T("TT3"))  || str == wxString::Format(_T("TIT1")) ||
             str == wxString::Format(_T("TIT2")) || str == wxString::Format(_T("TIT3")));
}

bool ConversioneMP3::TagAlbum(const wxString& str)
{
     return (str == wxString::Format(_T("TALB")) || str == wxString::Format(_T("TAL")));
}

bool ConversioneMP3::NonValido(wxString& str)
{
     bool res =  ( str.Find(_T("www.")) != wxNOT_FOUND &&
                  (str.Find(_T(".com")) != wxNOT_FOUND || str.Find(_T(".it")) != wxNOT_FOUND ||
                   str.Find(_T(".am"))  != wxNOT_FOUND) );
     if(res) str = _T("");
     return res;
}
