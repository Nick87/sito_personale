#ifndef _MAIN_H_
#define _MAIN_H_

#include "ConversioneMP3.h"
#include <wx/wx.h>
#include <wx/snglinst.h>

class MyApp:public wxApp
{
    public:
            MyApp();
            virtual ~MyApp();
            virtual bool OnInit();
    
    private:
            ConversioneMP3 * frame;
            wxSingleInstanceChecker * mChecker;
};

#endif
