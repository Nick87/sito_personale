#include "main.h"

IMPLEMENT_APP(MyApp)

MyApp::MyApp() {}

MyApp::~MyApp()
{
    delete mChecker;
    delete frame;
}

bool MyApp::OnInit()
{
	const wxString name = wxString::Format(_T("MyApp-%s"), wxGetUserId().c_str());
    mChecker = new wxSingleInstanceChecker(name);

    if (mChecker->IsAnotherRunning()){
       wxLogError(wxString::Format(_T("Programma già in esecuzione. Chiusura.")));
       return false;
    }

    frame = new ConversioneMP3(wxString::Format(_T("Conversione MP3")), wxSize(400, 450));
	frame->Show(true);
	SetTopWindow(frame);

	return true;
}
