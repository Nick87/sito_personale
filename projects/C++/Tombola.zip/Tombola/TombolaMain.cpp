#ifdef WX_PRECOMP
#include "wx_pch.h"
#endif

#ifdef __BORLANDC__
#pragma hdrstop
#endif //__BORLANDC__

#include "TombolaMain.h"

TombolaFrame::TombolaFrame(wxFrame * frame, const wxString& title, const wxSize& minsize)
    : GUIFrame(frame, title, minsize)
{
}

TombolaFrame::~TombolaFrame()
{
}

void TombolaFrame::OnClose(wxCloseEvent &event)
{
    Destroy();
}

void TombolaFrame::OnQuit(wxCommandEvent &event)
{
    Destroy();
}

void TombolaFrame::OnAbout(wxCommandEvent &event)
{
}
