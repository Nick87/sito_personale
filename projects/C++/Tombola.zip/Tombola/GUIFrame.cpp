#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif //__BORLANDC__

#ifndef WX_PRECOMP
#include <wx/wx.h>
#endif //WX_PRECOMP

#include "GUIFrame.h"
#include <time.h>
#include <wx/sound.h>

enum
{
    BtnEstrai = 1001,
    BtnCronologia,
    BtnReset
};

BEGIN_EVENT_TABLE(GUIFrame, wxFrame)
    EVT_BUTTON(BtnEstrai, GUIFrame::OnEstrai)
    EVT_BUTTON(BtnReset, GUIFrame::OnReset)
    EVT_BUTTON(BtnCronologia, GUIFrame::OnCronologia)
    EVT_CLOSE(GUIFrame::OnClose)
END_EVENT_TABLE()

GUIFrame::GUIFrame( wxWindow* parent, const wxString& title, const wxSize& minsize )
    :wxFrame( parent, wxID_ANY, title, wxPoint(0, 0), minsize )
{
    srand(time(NULL));
    topsizer = new wxBoxSizer( wxVERTICAL );
    toppanel = new wxPanel( this, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL );

    for(int i = 0; i < 90; i++)
        VoceNumeri.Add( wxString::Format(wxT("sound\\numero_%d.wav"), i+1) );

    for(int i = 0; i < 90; i++)
        numeri[i] = new wxStaticText( toppanel, wxID_ANY, wxString::Format(wxT("%d"), i+1), wxDefaultPosition, wxDefaultSize, 0 );

    vbox = new wxBoxSizer( wxVERTICAL );
    hbox1 = new wxBoxSizer( wxHORIZONTAL );

    SBSizer1 = new wxStaticBoxSizer( new wxStaticBox( toppanel, wxID_ANY, wxEmptyString ), wxVERTICAL );
    GSizer1 = new wxGridSizer( 3, 5, 0, 0 );
    SBSizer1->Add( GSizer1, 1, wxEXPAND, 5 );

    for(int i = 0; i <= 24; i++)
        if(i <= 4 || (i >= 10 && i <= 14) || (i >= 20 && i <= 24))
            GSizer1->Add( numeri[i], 0, wxALIGN_CENTER|wxALL, 5 );

    hbox1->Add( SBSizer1, 1, wxEXPAND|wxLEFT|wxRIGHT, 5 );
    SBSizer2 = new wxStaticBoxSizer( new wxStaticBox( toppanel, wxID_ANY, wxEmptyString ), wxVERTICAL );
    GSizer2 = new wxGridSizer( 3, 5, 0, 0 );
    SBSizer2->Add( GSizer2, 1, wxEXPAND, 5 );

    for(int i = 5; i <= 29; i++)
        if(i <= 9 || (i >= 15 && i <= 19) || (i >= 25 && i <= 29))
            GSizer2->Add( numeri[i], 0, wxALIGN_CENTER|wxALL, 5 );

    hbox1->Add( SBSizer2, 1, wxEXPAND|wxRIGHT, 5 );
    vbox->Add( hbox1, 3, wxEXPAND, 5 );

    hbox2 = new wxBoxSizer( wxHORIZONTAL );
    SBSizer3 = new wxStaticBoxSizer( new wxStaticBox( toppanel, wxID_ANY, wxEmptyString ), wxVERTICAL );
    GSizer3 = new wxGridSizer( 3, 5, 0, 0 );
    SBSizer3->Add( GSizer3, 1, wxEXPAND, 5 );

    for(int i = 30; i <= 54; i++)
        if(i <= 34 || (i >= 40 && i <= 44) || (i >= 50 && i <= 54))
            GSizer3->Add( numeri[i], 0, wxALIGN_CENTER|wxALL, 5 );

    hbox2->Add( SBSizer3, 1, wxEXPAND|wxLEFT|wxRIGHT, 5 );
    SBSizer4 = new wxStaticBoxSizer( new wxStaticBox( toppanel, wxID_ANY, wxEmptyString ), wxVERTICAL );
    GSizer4 = new wxGridSizer( 3, 5, 0, 0 );
    SBSizer4->Add( GSizer4, 1, wxEXPAND, 5 );

    for(int i = 35; i <= 59; i++)
        if(i <= 39 || (i >= 45 && i <= 49) || (i >= 55 && i <= 59))
            GSizer4->Add( numeri[i], 0, wxALIGN_CENTER|wxALL, 5 );

    hbox2->Add( SBSizer4, 1, wxEXPAND|wxRIGHT, 5 );
    vbox->Add( hbox2, 3, wxEXPAND, 5 );

    hbox3 = new wxBoxSizer( wxHORIZONTAL );
    SBSizer5 = new wxStaticBoxSizer( new wxStaticBox( toppanel, wxID_ANY, wxEmptyString ), wxVERTICAL );
    GSizer5 = new wxGridSizer( 3, 5, 0, 0 );
    SBSizer5->Add( GSizer5, 1, wxEXPAND, 5 );

    for(int i = 60; i <= 84; i++)
        if(i <= 64 || (i >= 70 && i <= 74) || (i >= 80 && i <= 84))
            GSizer5->Add( numeri[i], 0, wxALIGN_CENTER|wxALL, 5 );

    hbox3->Add( SBSizer5, 1, wxEXPAND|wxLEFT|wxRIGHT, 5 );
    SBSizer6 = new wxStaticBoxSizer( new wxStaticBox( toppanel, wxID_ANY, wxEmptyString ), wxVERTICAL );
    GSizer6 = new wxGridSizer( 3, 5, 0, 0 );
    SBSizer6->Add( GSizer6, 1, wxEXPAND, 5 );

    for(int i = 65; i <= 89; i++)
        if(i <= 69 || (i >= 75 && i <= 79) || (i >= 85 && i <= 89))
            GSizer6->Add( numeri[i], 0, wxALIGN_CENTER|wxALL, 5 );

    hbox3->Add( SBSizer6, 1, wxEXPAND|wxRIGHT, 5 );
    vbox->Add( hbox3, 3, wxEXPAND|wxBOTTOM, 5 );

    hbox4 = new wxBoxSizer( wxHORIZONTAL );
    Crono = new wxButton( toppanel, BtnCronologia, wxT("Cronologia"), wxDefaultPosition, wxDefaultSize, 0 );
    hbox4->Add( Crono, 1, wxEXPAND|wxLEFT|wxBOTTOM, 4 );
    Estrai = new wxButton( toppanel, BtnEstrai, wxT("ESTRAI"), wxDefaultPosition, wxDefaultSize, 0 );
    Estrai->SetDefault();
    hbox4->Add( Estrai, 6, wxEXPAND|wxLEFT|wxRIGHT|wxBOTTOM, 4 );
    Reset = new wxButton( toppanel, BtnReset, wxT("Azzera"), wxDefaultPosition, wxDefaultSize, 0 );
    hbox4->Add( Reset, 1, wxEXPAND|wxRIGHT|wxBOTTOM, 4 );
    vbox->Add( hbox4, 1, wxEXPAND, 5 );

    toppanel->SetSizer( vbox );
    toppanel->Layout();
    vbox->Fit( toppanel );
    topsizer->Add( toppanel, 1, wxEXPAND|wxALL, 0 );

    this->SetSizeHints( wxDefaultSize, wxDefaultSize );
    this->SetSizer( topsizer );
    this->Layout();
    SetMinSize(minsize);
    for(int i = 0; i < 90; i++)
        NumeriUsciti[i] = Cronologia[i] = 0;
    NUsciti = 0;
    wxSound(wxString::Format(wxT("sound\\intro.wav"))).Play(wxSOUND_ASYNC);
}

GUIFrame::~GUIFrame() {}

void GUIFrame::OnEstrai(wxCommandEvent& event)
{
    int number = 0;

    if(NUsciti == 90){
        ResetTombola();
        return;
    }

    do{
        number = rand()%90;
    }while(NumeriUsciti[number] == 1);

    if(NUsciti > 0)
        for(int i = 0; i < 90; i++)
            if(NumeriUsciti[i] == 1)
                numeri[i]->SetFont(wxFont(15, wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_BOLD, false));

    Cronologia[NUsciti] = number+1;
    NUsciti++;
    NumeriUsciti[number] = 1;
    numeri[number]->SetFont(wxFont(20, wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_BOLD, true));
    wxSound(VoceNumeri[number]).Play(wxSOUND_ASYNC);
}

void GUIFrame::OnReset(wxCommandEvent& event)
{
    ResetTombola();
}

void GUIFrame::ResetTombola()
{
    if(NUsciti == 0) return;
    for(int i = 0; i < 90; i++)
    {
        numeri[i]->SetFont(wxFont(8, wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL, false));
        NumeriUsciti[i] = Cronologia[i] = 0;
    }
    NUsciti = 0;
}

void GUIFrame::OnCronologia(wxCommandEvent& event)
{
    wxString str;
    if(NUsciti > 0)
    {
        str.Printf(wxT("%d"), Cronologia[0]);
        if(NUsciti > 1)
            for(int i = 1; i < NUsciti; i++)
                str += wxString::Format(wxT(" - %d"), Cronologia[i]);
        wxMessageBox(str, wxT("CRONOLOGIA"));
    }
    else
        wxMessageBox(wxT("Nessun numero uscito!"), wxT("CRONOLOGIA"));
}
