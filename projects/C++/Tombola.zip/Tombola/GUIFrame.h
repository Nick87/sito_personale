#ifndef __GUIFrame__
#define __GUIFrame__

#include <wx/wx.h>

class GUIFrame : public wxFrame
{
    private:
        wxBoxSizer * topsizer;
        wxPanel * toppanel;
        wxBoxSizer * vbox;
        wxBoxSizer * hbox1;
        wxStaticBoxSizer * SBSizer1;
        wxStaticBoxSizer * SBSizer2;
        wxGridSizer * GSizer1;
        wxGridSizer * GSizer2;
        wxBoxSizer * hbox2;
        wxStaticBoxSizer * SBSizer3;
        wxStaticBoxSizer * SBSizer4;
        wxGridSizer * GSizer3;
        wxGridSizer * GSizer4;
        wxBoxSizer * hbox3;
        wxStaticBoxSizer * SBSizer5;
        wxStaticBoxSizer * SBSizer6;
        wxGridSizer* GSizer5;
        wxGridSizer* GSizer6;
        wxBoxSizer * hbox4;
        wxButton * Estrai;
        wxButton * Crono;
        wxButton * Reset;
        wxStaticText * numeri[90];
        int NumeriUsciti[90];
        int Cronologia[90];
        int NUsciti;
        wxArrayString VoceNumeri;

        virtual void OnClose( wxCloseEvent& event ) {event.Skip();}
        void OnEstrai(wxCommandEvent&);
        void OnReset(wxCommandEvent&);
        void OnCronologia(wxCommandEvent&);
        void ResetTombola();

    public:
        GUIFrame( wxWindow* parent, const wxString& title, const wxSize& );
        ~GUIFrame();

    DECLARE_EVENT_TABLE()
};

#endif //__GUIFrame__
