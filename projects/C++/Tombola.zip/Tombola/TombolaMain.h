#ifndef TOMBOLAMAIN_H
#define TOMBOLAMAIN_H

#include "TombolaApp.h"
#include "GUIFrame.h"

class TombolaFrame: public GUIFrame
{
public:
    TombolaFrame(wxFrame *frame, const wxString&, const wxSize&);
    ~TombolaFrame();
private:
    virtual void OnClose(wxCloseEvent& event);
    virtual void OnQuit(wxCommandEvent& event);
    virtual void OnAbout(wxCommandEvent& event);
};

#endif // TOMBOLAMAIN_H
