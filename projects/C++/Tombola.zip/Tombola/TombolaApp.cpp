#ifdef WX_PRECOMP
#include "wx_pch.h"
#endif

#ifdef __BORLANDC__
#pragma hdrstop
#endif //__BORLANDC__

#include "TombolaApp.h"
#include "TombolaMain.h"

IMPLEMENT_APP(TombolaApp);

bool TombolaApp::OnInit()
{
    TombolaFrame* frame = new TombolaFrame(0L, wxT("TOMBOLA"), wxSize(700, 600));
    frame->SetIcon(wxICON(icon)); // To Set App Icon
    frame->Show();
    return true;
}
