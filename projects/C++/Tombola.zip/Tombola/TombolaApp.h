#ifndef TOMBOLAAPP_H
#define TOMBOLAAPP_H

#include <wx/app.h>

class TombolaApp : public wxApp
{
public:
    virtual bool OnInit();
};

#endif // TOMBOLAAPP_H
