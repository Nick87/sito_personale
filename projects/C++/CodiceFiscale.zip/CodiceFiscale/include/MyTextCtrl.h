#ifndef MYTEXTCTRL_H
#define MYTEXTCTRL_H

#include <wx/textctrl.h>
#include "Comune.h"

#define UPPER 0x00000001
#define SPACE 0x00000002

/*! \class MyTextCtrl MyTextCtrl.h "include/MyTextCtrl.h"
 *  \brief Classe MyTextCtrl.
 *
 *  Questa classe deriva da wxTextCtrl e la estende
 *  implementando l'autocompletamento.
 */
class MyTextCtrl:public wxTextCtrl
{
    public:
        MyTextCtrl(wxWindow * parent,
                   wxWindowID id,
                   int flags,
                   const wxString& value = wxEmptyString,
                   const wxPoint& pos = wxDefaultPosition,
                   const wxSize& size = wxDefaultSize,
                   long  style = 0,
                   const wxValidator& validator = wxDefaultValidator,
                   const wxString& name = wxTextCtrlNameStr); ///< Costruttore con parametri.
        virtual ~MyTextCtrl();///< Distruttore

        /*! \brief Setta il vettore dei comuni

            Ci serve tale riferimento per effettuare la ricerca
            e mostrare nella casella di testo il primo match.
        */
        void SetComuni(Comune * c) {comuni = c;}
		
        /*! \brief Imposta il numero dei comuni
            @param n Numero dei comuni.
        */
        void SetNComuni(int n) {nComuni = n;}

        /*! \brief Imposta i flag della casella di testo.
            @param f Flag da impostare.
        */
        void SetFlags(int f) {Flags = f;}

        /*! \brief Ritorna i flag.
            @return Ritorna i flag della casella di testo.
        */
        int GetFlags() {return Flags;}

    private:
        void TextEntered(wxCommandEvent&);
        void DoIdle(wxIdleEvent&);
        void DoKeyDown(wxKeyEvent&);
        bool MyStartsWith(const wxString&, const wxString&);
        wxString GetFirstMatch(const wxString&);
        wxString MyUpper(const wxString&);
        wxString Space(const wxString&);

        bool IgnoreNextTextEdit; ///< Se dobbiamo il prossimo inserimento.
        int Flags; ///< Flag della casella di testo.
        int nComuni; ///< Numero comuni.
        Comune * comuni; ///< Vettore dei comuni.
        wxString LastMatch; ///< Ultimo match trovato.

        DECLARE_EVENT_TABLE()
};

#endif // MYTEXTCTRL_H
