#ifndef MYDIALOG_H
#define MYDIALOG_H

#include <wx/wx.h>

/*! \class MyDialog MyDialog.h "include/MyDialog.h"
 *  \brief Classe MyDialog.
 *
 *  La classe che rappresenta la finestra di dialogo all'uscita
 *  dell'applicazione.
 */
class MyDialog:public wxDialog
{
    public:
        MyDialog(wxWindow* parent,
                 wxWindowID id,
                 const wxString& title);///< Costruttore con parametri
        ~MyDialog(); ///< Distruttore

    private:
        void OnSi(wxCommandEvent&);
        void OnNo(wxCommandEvent&);
        void OnCheckBox(wxCommandEvent&);

        /*! \brief CheckBox

            La CheckBox con la quale si sceglie di non chiedere
            la conferma della chiusura in futuro.
        */
        wxCheckBox * CheckBox;

        DECLARE_EVENT_TABLE()
};

#endif // MYDIALOG_H
