#ifndef COMUNE_H
#define COMUNE_H

#include <wx/string.h>

/*! \class Comune Comune.h "include/Comune.h"
 *  \brief Classe Comune.
 *
 *  La classe che descrive ogni comune.
 */
class Comune
{
    public:
        Comune(); ///< Costruttore di default
        Comune(const wxString&, const wxString&, const wxString&); ///< Costruttore con parametri
        virtual ~Comune(); ///< Distruttore
        wxString GetNome() const {return Nome;} ///< Ritorna il nome del Comune @return Nome del Comune.
        wxString GetProvincia() const {return Provincia;} ///< Ritorna il nome della Provincia. @return Nome della Provincia.
        wxString GetCodice() const {return Codice;} ///< Ritorna il codice catastale del Comune. @return Codice catastale del Comune.
        void SetNome(const wxString& n){Nome = n;} ///< Setta il nome del Comune @param n Nome del comune.
        void SetProvincia(const wxString& p){Provincia = p;} ///< Setta il nome della Provincia @param p Nome della Provincia.
        void SetCodice(const wxString& c){Codice = c;} ///< Setta il codice catastale del Comune @param c Codice catastale del Comune.

    private:
        wxString Nome; ///< Nome del Comune
        wxString Provincia; ///< Nome della Provincia di appartenenza
        wxString Codice; ///< Codice catastale del Comune
};

#endif
