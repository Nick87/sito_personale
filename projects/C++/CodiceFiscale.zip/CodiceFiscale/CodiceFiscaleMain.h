#ifndef CODICEFISCALEMAIN_H
#define CODICEFISCALEMAIN_H

#ifdef WX_GCH
#include <wx_pch.h>
#else
#include <wx/wx.h>
#endif

#include "include/Comune.h"
#include "include/MyTextCtrl.h"
#include <wx/notebook.h>

/*! \class CodiceFiscaleFrame CodiceFiscaleMain.h "CodiceFiscaleMain.h"
 *  \brief Classe CodiceFiscaleFrame.
 *
 *  La classe frame principale.
 */
class CodiceFiscaleFrame:public wxFrame
{
    public:
        friend class CodiceFiscaleApp;
        CodiceFiscaleFrame(wxWindow* parent,
                           const wxString& title,
                           const wxSize& minsize,
                           int flags = wxDEFAULT_FRAME_STYLE);///< Costruttore con parametri.
        ~CodiceFiscaleFrame();///< Distruttore.

        /*! \brief Enumerazione dei sessi. */
        enum Sex
        {
            Maschio, /*!< Maschio. */
            Femmina, /*!< Femmina. */
            Inv_Sesso /*!< Sesso non valido. */
        };

    private:
        int ShowMessage(const wxString&, const wxString& = wxT("Messaggio"), int = wxOK | wxICON_INFORMATION);
        wxWindow * CreateFirstPage(wxWindow *);
        wxWindow * CreateSecondPage(wxWindow *);
        void OnClose(wxCloseEvent&);
        void OnInfo(wxCommandEvent&);
        void OnExit(wxCommandEvent&);
        void OnExtra(wxCommandEvent&);
        void OnCalcola(wxCommandEvent&);
        void OnVerifica(wxCommandEvent&);
        void InitComuni();
        bool CheckInput();
        bool IsVocale(wxChar);
        bool IsValido(const wxString&);
        wxChar CalcolaCodiceControllo(const wxString&);
        int TrovaComune(const wxString&);
        wxString GetValueOption(const wxString&);

        bool ExtraToggled; ///< Indica se il bottone della spaziatura &egrave; premuto.

        //Prima scheda
        enum Sex Sesso; ///< Il sesso attuale.

        wxString Cognome, ///< Cognome
                 Nome, ///< Nome
                 ComuneNascita, ///< Comune di nascita
                 CodiceComune, ///< Codice catastale del Comune
                 CodiceFiscale; ///< Codice Fiscale

        wxComboBox   * CBSesso; ///< ComboBox per il sesso.
        MyTextCtrl   * MTCComuneNascita; ///< Casella di testo del Comune di nascita.
        wxTextCtrl   * TCCognome; ///< Casella di testo del Cognome.
        wxTextCtrl   * TCNome; ///< Casella di testo del Nome.
        wxComboBox   * CBGiorno; ///< ComboBox del giorno di nascita.
        wxComboBox   * CBMese; ///< ComboBox del mese di nascita.
        wxTextCtrl   * TCAnno; ///< Casella di testo dell'anno di nascita.
        wxStaticText * STProvincia2; ///< StaticText della Provincia.
        wxStaticText * STCodiceFiscale2; ///< StaticText del Codice Fiscale.

        size_t nComuni; ///< Numero dei Comuni.
        int Giorno /*! \brief Giorno di nascita. */,
            Mese /*! \brief Mese di nascita. */;
        unsigned long  Anno; ///< Anno di nascita.
        Comune * comuni; ///< Vettore dei Comuni.

        //Seconda scheda
        MyTextCtrl * CF; ///< Casella di testo del Codice Fiscale.
        wxStaticText * Cognome2; ///< StaticText del Cognome.
        wxStaticText * Nome2; ///< StaticText del Nome.
        wxStaticText * Sesso2; ///< StaticText del Sesso.
        wxStaticText * Comune2; ///< StaticText del Comune.
        wxStaticText * Provincia2; ///< StaticText della Provincia.
        wxStaticText * Data2; ///< StaticText della data di nascita.

        DECLARE_EVENT_TABLE()
};
#endif // CODICEFISCALEMAIN_H
