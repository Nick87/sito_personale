#ifdef WX_PRECOMP
#include "wx_pch.h"
#endif

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#include "CodiceFiscaleMain.h"
#include "include/MyDialog.h"
#include <wx/tokenzr.h>
#include <wx/datetime.h>
#include <wx/font.h>
#include <wx/textfile.h>
#include <wx/utils.h>

enum
{
    BtnCalcola = 1001,
    BtnVerifica,
    BtnInfo,
    BtnExit,
    BtnExtra
};

BEGIN_EVENT_TABLE(CodiceFiscaleFrame, wxFrame)
    EVT_BUTTON(BtnCalcola, CodiceFiscaleFrame::OnCalcola)
    EVT_BUTTON(BtnVerifica, CodiceFiscaleFrame::OnVerifica)
    EVT_TOOL(BtnExtra, CodiceFiscaleFrame::OnExtra)
    EVT_TOOL(BtnInfo, CodiceFiscaleFrame::OnInfo)
    EVT_TOOL(BtnExit, CodiceFiscaleFrame::OnExit)
    EVT_CLOSE(CodiceFiscaleFrame::OnClose)
END_EVENT_TABLE()

/*! @param frame frame Genitore.
    @param title Titolo del frame.
    @param size Dimensione iniziale del frame.
    @param flags Flag del frame.
*/
CodiceFiscaleFrame::CodiceFiscaleFrame(wxWindow * frame, const wxString& title, const wxSize& minsize, int flags)
    :wxFrame(frame, wxID_ANY, title, wxDefaultPosition, minsize, flags)
{
    //TODO Inserire toppanel in un topsizer
    wxBoxSizer * topsizer = new wxBoxSizer(wxVERTICAL);
    wxPanel * panel = new wxPanel(this, wxID_ANY);
    wxBoxSizer * vbox = new wxBoxSizer(wxVERTICAL);
    int ToolbarFlags = wxTB_HORZ_TEXT | wxTB_NODIVIDER | wxTB_FLAT | wxTB_HORIZONTAL;
    wxToolBar * toolbar = new wxToolBar(panel, wxID_ANY, wxDefaultPosition, wxDefaultSize, ToolbarFlags);

    toolbar->AddTool(BtnExtra, wxT("Spaziatura"), wxBitmap(wxT("images/Extra.bmp"), wxBITMAP_TYPE_ANY), wxT("Attiva spaziatura CF"), wxITEM_CHECK);
    toolbar->AddSeparator();
    toolbar->AddTool(BtnInfo, wxT("Info"), wxBitmap(wxT("images/InfoBox-icon.bmp"), wxBITMAP_TYPE_ANY), wxT("Info sull'autore"));
    toolbar->AddTool(BtnExit, wxT("Esci"), wxBitmap(wxT("images/exit-icon.bmp"), wxBITMAP_TYPE_ANY), wxT("Esci dall'applicazione"));
    toolbar->Realize();
    vbox->Add(toolbar, 0, wxEXPAND);

    wxNotebook * notebook = new wxNotebook(panel, wxID_ANY);
    notebook->AddPage(CreateFirstPage(notebook), wxT("Creazione Codice Fiscale"));
    notebook->AddPage(CreateSecondPage(notebook), wxT("Verifica Codice Fiscale"));
    vbox->Add(notebook, 1, wxLEFT | wxTOP | wxEXPAND, 1);

    panel->SetSizer(vbox);
    topsizer->Add(panel, 1, wxEXPAND);

    this->SetSizer(topsizer);
    SetMinSize(minsize);
    Centre();
}

CodiceFiscaleFrame::~CodiceFiscaleFrame()
{
    delete[] comuni;
}

/*! \brief Funzione \c OnClose.

    La funzione viene chiamata quando si chiude il programma dalla X del frame.
*/
void CodiceFiscaleFrame::OnClose(wxCloseEvent &event)
{
    if(GetValueOption(wxT("CONFIRM_ON_EXIT")) == wxT("0")){
        Destroy();
        return;
    }
    MyDialog * dialog = new MyDialog(this, wxID_ANY, wxT("Chiudi CodiceFiscale"));
    if(dialog->ShowModal() == wxID_YES)
        Destroy();
    else
        event.Veto();
    dialog->Destroy();
}

/*! \brief Funzione \c OnExit.

    La funzione viene chiamata quando si chiude il programma col pulsante della ToolBar.
*/
void CodiceFiscaleFrame::OnExit(wxCommandEvent &event)
{
    if(GetValueOption(wxT("CONFIRM_ON_EXIT")) == wxT("0")){
        Destroy();
        return;
    }
    MyDialog * dialog = new MyDialog(this, wxID_ANY, wxT("Chiudi CodiceFiscale"));
    if(dialog->ShowModal() == wxID_YES)
        Destroy();
    dialog->Destroy();
}

/*! \brief Funzione \c OnExtra.

    La funzione viene chiamata quando si preme il pulsante della spaziatura.
*/
void CodiceFiscaleFrame::OnExtra(wxCommandEvent &event)
{
    ExtraToggled = (ExtraToggled) ? false : true;
    if(ExtraToggled){
        CF->SetFlags(CF->GetFlags() | SPACE);
        CF->SetMaxLength(20);
    }else{
        CF->SetFlags(CF->GetFlags() & (~SPACE));
        CF->SetMaxLength(16);
    }
}

/*! \brief Funzione \c GetValueOption.
    @param opt Opzione del file di configurazione di cui prendere il valore.
    @return Il valore corrispondente all'opzione \c opt.

    La funzione serve a recuperare informazioni dal file di configurazione.
*/
wxString CodiceFiscaleFrame::GetValueOption(const wxString& opt)
{
    wxTextFile File;
    wxStringTokenizer stk;
    wxString ret = wxEmptyString;
    File.Open(wxT("config.ini"), wxConvUTF8);

    if(!File.IsOpened()){
        wxLogError(wxT("Impossibile aprire il file di configurazione (config.ini)"));
        return wxEmptyString;
    }

    for(size_t i = 0; i < File.GetLineCount(); i++)
    {
        if(File.GetLine(i).Len() == 0) continue;
        stk.SetString(File.GetLine(i), wxT("="), wxTOKEN_RET_EMPTY_ALL);
        if(stk.CountTokens() != 2) continue;

        if(stk.GetNextToken().Trim().Trim(false) == opt){
            ret = stk.GetNextToken().Trim().Trim(false);
            break;
        }
    }
    File.Close();
    return ret;
}

/*! \brief Funzione \c OnInfo.

    La funzione mostra informazioni sull'autore.
*/
void CodiceFiscaleFrame::OnInfo(wxCommandEvent &event)
{
    ShowMessage(wxT("Realizzato da Nicola Alessandro Domingo."));
}

/*! \brief Funzione \c CreateFirstPage.
    @param parent Genitore.
    @return La pagina del Notebook.

    La funzione crea la prima pagina del Notebook.
*/
wxWindow * CodiceFiscaleFrame::CreateFirstPage(wxWindow * parent)
{
    //TODO Vedere il parent
    wxPanel * panel = new wxPanel(parent, wxID_ANY);
    wxBoxSizer * vbox  = new wxBoxSizer(wxVERTICAL);
    wxBoxSizer * hbox1 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer * hbox2 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer * hbox3 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer * hbox4 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer * hbox5 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer * hbox6 = new wxBoxSizer(wxHORIZONTAL);
    nComuni      = 0;
    ExtraToggled = false;

    wxStaticText * STCognome = new wxStaticText(panel, wxID_ANY, wxT("Cognome"));
    TCCognome = new wxTextCtrl(panel, wxID_ANY);
    wxStaticText * STNome = new wxStaticText(panel, wxID_ANY, wxT("Nome"));
    TCNome = new wxTextCtrl(panel, wxID_ANY);
    wxStaticText * STSesso = new wxStaticText(panel, wxID_ANY, wxT("Sesso"));
    CBSesso = new wxComboBox(panel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0, NULL, wxCB_READONLY);
    CBSesso->Append(wxT("M"));
    CBSesso->Append(wxT("F"));
    wxStaticText * STComuneNascita = new wxStaticText(panel, wxID_ANY, wxT("Comune di nascita"));
    MTCComuneNascita = new MyTextCtrl(panel, wxID_ANY, 0);
    wxStaticText * STProvincia1 = new wxStaticText(panel, wxID_ANY, wxT("Provincia"));
    STProvincia2 = new wxStaticText(panel, wxID_ANY, wxT("   "));
    STProvincia2->SetFont(wxFont(8, wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_BOLD));;
    wxStaticText * EmptySpace = new wxStaticText(panel, wxID_ANY, wxEmptyString);
    wxStaticText * STDataNascita  = new wxStaticText(panel, wxID_ANY, wxT("Data di nascita"));

    CBGiorno = new wxComboBox(panel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0, NULL, wxCB_READONLY);
    for(int i = 1; i <= 31; i++)
        CBGiorno->Append(wxString::Format(wxT("%d"), i));
    CBMese = new wxComboBox(panel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0, NULL, wxCB_READONLY);
    CBMese->Append(wxT("Gennaio"));    CBMese->Append(wxT("Febbraio"));
    CBMese->Append(wxT("Marzo"));      CBMese->Append(wxT("Aprile"));
    CBMese->Append(wxT("Maggio"));     CBMese->Append(wxT("Giugno"));
    CBMese->Append(wxT("Luglio"));     CBMese->Append(wxT("Agosto"));
    CBMese->Append(wxT("Settembre"));  CBMese->Append(wxT("Ottobre"));
    CBMese->Append(wxT("Novembre"));   CBMese->Append(wxT("Dicembre"));

    TCAnno = new wxTextCtrl(panel, wxID_ANY, wxT(""), wxDefaultPosition, wxSize(40, 20), wxTE_RIGHT);
    wxButton     * BCalcola  = new wxButton(panel, BtnCalcola, wxT("&Calcola"));
    wxStaticText * STCodiceFiscale1 = new wxStaticText(panel, wxID_ANY, wxT("CODICE FISCALE:"));
    STCodiceFiscale2 = new wxStaticText(panel, wxID_ANY, wxEmptyString);
    STCodiceFiscale2->SetFont(wxFont(8, wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_BOLD));

    hbox1->Add(STCognome, 0, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    hbox1->Add(TCCognome, 1, wxLEFT | wxRIGHT | wxTOP | wxALIGN_CENTER_VERTICAL, 5);
    vbox->Add(hbox1, 1, wxEXPAND);

    hbox2->Add(STNome, 0, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    hbox2->Add(TCNome, 1, wxLEFT | wxTOP | wxALIGN_CENTER_VERTICAL, 5);
    hbox2->Add(STSesso, 0, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    hbox2->Add(CBSesso, 0, wxLEFT | wxRIGHT | wxALIGN_CENTER_VERTICAL, 5);
    vbox->Add(hbox2, 1, wxEXPAND);

    hbox3->Add(STComuneNascita, 0, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    hbox3->Add(MTCComuneNascita, 1, wxLEFT | wxRIGHT | wxALIGN_CENTER_VERTICAL, 5);
    vbox->Add(hbox3, 1, wxEXPAND);

    hbox4->Add(STProvincia1, 0, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    hbox4->Add(STProvincia2, 0, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    hbox4->Add(EmptySpace, 2, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    hbox4->Add(STDataNascita, 0, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    hbox4->Add(CBGiorno, 0, wxLEFT | wxALIGN_CENTER_VERTICAL, 3);
    hbox4->Add(CBMese, 0, wxLEFT | wxRIGHT | wxALIGN_CENTER_VERTICAL, 5);
    hbox4->Add(TCAnno, 0, wxRIGHT | wxALIGN_CENTER_VERTICAL, 5);
    vbox->Add(hbox4, 1, wxEXPAND);

    hbox5->Add(BCalcola, 1, wxLEFT | wxRIGHT | wxEXPAND, 3);
    vbox->Add(hbox5, 1, wxEXPAND);

    hbox6->Add(STCodiceFiscale1, 0, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    hbox6->Add(STCodiceFiscale2, 1, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    vbox->Add(hbox6, 1, wxEXPAND);

    panel->SetSizer(vbox);
    InitComuni();
    MTCComuneNascita->SetComuni(comuni);
    MTCComuneNascita->SetNComuni(nComuni);
    Cognome = Nome = ComuneNascita = CodiceFiscale = CodiceComune = wxEmptyString;
    Sesso = Inv_Sesso;
    return panel;
}

/*! \brief Funzione \c CreateSecondPage.
    @param parent Genitore.
    @return La pagina del Notebook.

    La funzione crea la seconda pagina del Notebook.
*/
wxWindow * CodiceFiscaleFrame::CreateSecondPage(wxWindow * parent)
{
    //TODO Vedere il parent
    wxPanel * panel = new wxPanel(parent, wxID_ANY);
    wxBoxSizer * vbox  = new wxBoxSizer(wxVERTICAL);
    wxBoxSizer * hbox  = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer * vbox1 = new wxBoxSizer(wxVERTICAL);
    wxBoxSizer * vbox2 = new wxBoxSizer(wxVERTICAL);
    wxBoxSizer * hbox1 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer * hbox2 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer * hbox3 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer * hbox4 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer * hbox5 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer * hbox6 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer * hbox7 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer * hbox8 = new wxBoxSizer(wxHORIZONTAL);

    wxStaticText * CodiceFiscale = new wxStaticText(panel, wxID_ANY, wxT("Codice Fiscale"));
    CF = new MyTextCtrl(panel, wxID_ANY, UPPER);
    if(!ExtraToggled) CF->SetMaxLength(16);
    wxStaticText * Cognome1 = new wxStaticText(panel, wxID_ANY, wxT("Cognome:"));
    Cognome2 = new wxStaticText(panel, wxID_ANY, wxEmptyString);
    Cognome2->SetFont(wxFont(8, wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_BOLD));
    wxStaticText * Nome1 = new wxStaticText(panel, wxID_ANY, wxT("Nome:"));
    Nome2 = new wxStaticText(panel, wxID_ANY, wxEmptyString);
    Nome2->SetFont(wxFont(8, wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_BOLD));
    wxStaticText * Sesso1 = new wxStaticText(panel, wxID_ANY, wxT("Sesso:"));
    Sesso2 = new wxStaticText(panel, wxID_ANY, wxEmptyString);
    Sesso2->SetFont(wxFont(8, wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_BOLD));
    wxStaticText * Comune1 = new wxStaticText(panel, wxID_ANY, wxT("Comune di nascita:"));
    Comune2 = new wxStaticText(panel, wxID_ANY, wxEmptyString);
    Comune2->SetFont(wxFont(8, wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_BOLD));
    wxStaticText * Provincia1 = new wxStaticText(panel, wxID_ANY, wxT("Provincia:"));
    Provincia2 = new wxStaticText(panel, wxID_ANY, wxEmptyString);
    Provincia2->SetFont(wxFont(8, wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_BOLD));
    wxStaticText * Data1 = new wxStaticText(panel, wxID_ANY, wxT("Data di nascita:"));
    Data2 = new wxStaticText(panel, wxID_ANY, wxEmptyString);
    Data2->SetFont(wxFont(8, wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_BOLD));


    hbox1->Add(CodiceFiscale, 0, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    hbox1->Add(CF, 1, wxLEFT | wxRIGHT | wxTOP | wxALIGN_CENTER_VERTICAL, 5);
    vbox->Add(hbox1, 0, wxEXPAND);

    hbox2->Add(Cognome1, 0, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    hbox2->Add(Cognome2, 1, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    hbox3->Add(Nome1, 0, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    hbox3->Add(Nome2, 1, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    hbox4->Add(Sesso1, 0, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    hbox4->Add(Sesso2, 1, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    vbox1->Add(hbox2, 1, wxEXPAND);
    vbox1->Add(hbox3, 1, wxEXPAND);
    vbox1->Add(hbox4, 1, wxEXPAND);

    hbox5->Add(Comune1, 0, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    hbox5->Add(Comune2, 1, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    hbox6->Add(Provincia1, 0, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    hbox6->Add(Provincia2, 1, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    hbox7->Add(Data1, 0, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    hbox7->Add(Data2, 1, wxLEFT | wxALIGN_CENTER_VERTICAL, 5);
    vbox2->Add(hbox5, 1, wxEXPAND);
    vbox2->Add(hbox6, 1, wxEXPAND);
    vbox2->Add(hbox7, 1, wxEXPAND);

    hbox->Add(vbox1, 1, wxEXPAND);
    hbox->Add(vbox2, 2, wxEXPAND);
    vbox->Add(hbox, 4, wxEXPAND);

    //TODO Vedere parent
    wxButton * Verifica  = new wxButton(panel, BtnVerifica, wxT("&Verifica"));
    hbox8->Add(Verifica, 1, wxEXPAND);
    vbox->Add(hbox8, 1, wxEXPAND);

    panel->SetSizer(vbox);
    return panel;
}

/*! \brief Funzione \c OnVerifica.

    La funzione verifica la correttezza del Codice Fiscale e lo mostra.
*/
void CodiceFiscaleFrame::OnVerifica(wxCommandEvent &event)
{
    wxString CFiscale = CF->GetValue().Trim().Upper();
    CFiscale.Replace(wxT(" "), wxT(""));

    //Verifica lunghezza codice fiscale
    if(CFiscale.Len() != 16){
        ShowMessage(wxT("Codice Fiscale mancante o non valido"), wxT("Errore"), wxICON_ERROR);
        CF->SetSelection(-1, -1);
        CF->SetFocus();
        return;
    }

    //Verifica cognome
    if(CFiscale[0] < 'A' || CFiscale[0] > 'Z' ||
       CFiscale[1] < 'A' || CFiscale[1] > 'Z' ||
       CFiscale[2] < 'A' || CFiscale[2] > 'Z')
    {
        ShowMessage(wxT("Cognome non valido"), wxT("Errore"), wxICON_ERROR);
        CF->SetSelection(0, 3);
        CF->SetFocus();
        return;
    }

    //Verifica nome
    if(CFiscale[3] < 'A' || CFiscale[3] > 'Z' ||
       CFiscale[4] < 'A' || CFiscale[4] > 'Z' ||
       CFiscale[5] < 'A' || CFiscale[5] > 'Z')
    {
        ShowMessage(wxT("Nome non valido"), wxT("Errore"), wxICON_ERROR);
        if(CF->GetFlags()&SPACE)
            CF->SetSelection(4, 7);
        else
            CF->SetSelection(3, 6);
        CF->SetFocus();
        return;
    }

    //Verifica anno di nascita
    if(CFiscale[6] < (wxChar)'0' || CFiscale[6] > (wxChar)'9' ||
       CFiscale[7] < (wxChar)'0' || CFiscale[7] > (wxChar)'9')
    {
        ShowMessage(wxT("Anno di nascita non valido"), wxT("Errore"), wxICON_ERROR);
        if(CF->GetFlags()&SPACE)
            CF->SetSelection(8, 10);
        else
            CF->SetSelection(6, 8);
        CF->SetFocus();
        return;
    }

    //Verifica mese di di nascita
    if(CFiscale[8] != (wxChar)'A' && CFiscale[8] != (wxChar)'B' && CFiscale[8] != (wxChar)'C' &&
       CFiscale[8] != (wxChar)'D' && CFiscale[8] != (wxChar)'E' && CFiscale[8] != (wxChar)'H' &&
       CFiscale[8] != (wxChar)'L' && CFiscale[8] != (wxChar)'M' && CFiscale[8] != (wxChar)'P' &&
       CFiscale[8] != (wxChar)'R' && CFiscale[8] != (wxChar)'S' && CFiscale[8] != (wxChar)'T')
    {
        ShowMessage(wxT("Mese di nascita non valido"), wxT("Errore"), wxICON_ERROR);
        if(CF->GetFlags()&SPACE)
            CF->SetSelection(10, 11);
        else
            CF->SetSelection(8, 9);
        CF->SetFocus();
        return;
    }

    //Verifica giorno di nascita
    if(CFiscale[9] <  (wxChar)'0' || CFiscale[9] > (wxChar)'9' ||
       CFiscale[10] < (wxChar)'0' || CFiscale[10] > (wxChar)'9')
    {
        ShowMessage(wxT("Giorno di nascita non valido"), wxT("Errore"), wxICON_ERROR);
        if(CF->GetFlags()&SPACE)
            CF->SetSelection(11, 13);
        else
            CF->SetSelection(9, 11);
        CF->SetFocus();
        return;
    }

    long giorno = 0;
    wxString str;
    str.Append(CFiscale[9]);
    str.Append(CFiscale[10]);
    str.ToLong(&giorno, 10);
    str.Empty();

    if((giorno > 31 && giorno < 41) || giorno > 71)
    {
        ShowMessage(wxT("Giorno di nascita non valido"), wxT("Errore"), wxICON_ERROR);
        if(CF->GetFlags()&SPACE)
            CF->SetSelection(11, 13);
        else
            CF->SetSelection(9, 11);
        CF->SetFocus();
        return;
    }

    //Verifica codice del comune
    if(CFiscale[11] < (wxChar)'A' || CFiscale[11] > 'Z' ||
       CFiscale[12] < (wxChar)'0' || CFiscale[12] > '9' ||
       CFiscale[13] < (wxChar)'0' || CFiscale[13] > '9' ||
       CFiscale[14] < (wxChar)'0' || CFiscale[14] > '9')
    {
        ShowMessage(wxT("Codice comune non valido"), wxT("Errore"), wxICON_ERROR);
        if(CF->GetFlags()&SPACE)
            CF->SetSelection(14, 18);
        else
            CF->SetSelection(11, 15);
        CF->SetFocus();
        return;
    }

    bool found = false;
    wxString ComFound, ProvFound;
    for(int i = 11; i < 15; i++)
        str.Append(CFiscale[i]);
    //Verifica il codice del comune
    for(size_t i = 0; i < nComuni; i++)
    {
        if(comuni[i].GetCodice().IsSameAs(str)){
            found = true;
            ComFound = comuni[i].GetNome();
            ProvFound = comuni[i].GetProvincia();
            break;
        }
    }

    if(!found){
        ShowMessage(wxT("Codice comune inesistente"), wxT("Errore"), wxICON_ERROR);
        if(CF->GetFlags()&SPACE)
            CF->SetSelection(14, 18);
        else
            CF->SetSelection(11, 15);
        CF->SetFocus();
        return;
    }

    //Verifica del codice di controllo
    str.Empty();
    str = CFiscale;
    str.RemoveLast();

    if(CFiscale[15] != CalcolaCodiceControllo(str)){
        ShowMessage(wxT("Codice di controllo errato"), wxT("Errore"), wxICON_ERROR);
        if(CF->GetFlags()&SPACE)
            CF->SetSelection(19, 20);
        else
            CF->SetSelection(15, 16);
        CF->SetFocus();
        return;
    }

    //Arrivati qui il codice fiscale e' valido
    str.Empty();
    str.Append(CFiscale[0]);
    str.Append(CFiscale[1]);
    str.Append(CFiscale[2]);
    Cognome2->SetLabel(str);
    str.Empty();
    str.Append(CFiscale[3]);
    str.Append(CFiscale[4]);
    str.Append(CFiscale[5]);
    Nome2->SetLabel(str);

    if(giorno <= 31)
        Sesso2->SetLabel(wxT("M"));
    else
        Sesso2->SetLabel(wxT("F"));

    Comune2->SetLabel(ComFound);
    Provincia2->SetLabel(ProvFound);

    str.Empty();
    if(giorno <= 31)
        str.Append(wxString::Format(wxT("%02d/"), giorno));
    else
        str.Append(wxString::Format(wxT("%02d/"), giorno-40));

    switch(CFiscale[8])
    {
        case 'A':
                str.Append(wxString::Format(wxT("01/**")));
                break;
        case 'B':
                str.Append(wxString::Format(wxT("02/**")));
                break;
        case 'C':
                str.Append(wxString::Format(wxT("03/**")));
                break;
        case 'D':
                str.Append(wxString::Format(wxT("04/**")));
                break;
        case 'E':
                str.Append(wxString::Format(wxT("05/**")));
                break;
        case 'H':
                str.Append(wxString::Format(wxT("06/**")));
                break;
        case 'L':
                str.Append(wxString::Format(wxT("07/**")));
                break;
        case 'M':
                str.Append(wxString::Format(wxT("08/**")));
                break;
        case 'P':
                str.Append(wxString::Format(wxT("09/**")));
                break;
        case 'R':
                str.Append(wxString::Format(wxT("10/**")));
                break;
        case 'S':
                str.Append(wxString::Format(wxT("11/**")));
                break;
        case 'T':
                str.Append(wxString::Format(wxT("12/**")));
                break;
    }
    str.Append(CFiscale[6]);
    str.Append(CFiscale[7]);
    Data2->SetLabel(str);

    CF->SetSelection(-1, -1);
    CF->SetFocus();
}

/*! \brief Funzione \c OnCalcola.

    La funzione calcola il Codice Fiscale e lo mostra.
*/
void CodiceFiscaleFrame::OnCalcola(wxCommandEvent &event)
{
    if(!CheckInput())   return;
    wxString cognome = Cognome.Upper(), nome = Nome.Upper(), vocali, consonanti;
    CodiceFiscale.Empty();

    //Rimuoviamo eventuali spazi bianchi da destra e sinistra
    cognome.Trim();
    cognome.Trim(false);
    nome.Trim();
    nome.Trim(false);

    //Rimuoviamo eventuali spazi bianchi ed apostrofi interni
    cognome.Replace(wxT(" "), wxT(""));
    nome.Replace(wxT(" "), wxT(""));
    cognome.Replace(wxT("'"), wxT(""));
    nome.Replace(wxT("'"), wxT(""));

    //Costruiamo la parte del cognome
    for(size_t i = 0; i < cognome.Len(); i++)
        if(IsVocale(cognome[i]))
            vocali.Append(cognome[i]);
        else
            consonanti.Append(cognome[i]);

    if(consonanti.Len() >= 3){
        for(int i = 0; i < 3; i++)
            CodiceFiscale.Append(consonanti[i]);
    }else if(consonanti.Len() == 2 && cognome.Len() >= 3){
        CodiceFiscale.Append(consonanti[0]);
        CodiceFiscale.Append(consonanti[1]);
        CodiceFiscale.Append(vocali[0]);
    }else if(consonanti.Len() == 1 && cognome.Len() >= 3){
        CodiceFiscale.Append(consonanti[0]);
        CodiceFiscale.Append(vocali[0]);
        CodiceFiscale.Append(vocali[1]);
    }else if(consonanti.Len() == 0){
        CodiceFiscale.Append(vocali[0]);
        CodiceFiscale.Append(vocali[1]);
        if(vocali.Len() >= 3)
            CodiceFiscale.Append(vocali[2]);
        else
            CodiceFiscale.Append('X');
    }else if(cognome.Len() < 3){
        int count = 0;
        for(size_t i = 0; i < consonanti.Len() && count < 3; i++, count++)
            CodiceFiscale.Append(consonanti[i]);
        for(size_t i = 0; i < vocali.Len() && count < 3; i++, count++)
            CodiceFiscale.Append(vocali[i]);
        if(count == 2)
            CodiceFiscale.Append('X');
    }
    CodiceFiscale.Append(' ');

    //Costruiamo la parte del nome
    vocali.Empty();
    consonanti.Empty();
    for(size_t i = 0; i < nome.Len(); i++)
        if(IsVocale(nome[i]))
            vocali.Append(nome[i]);
        else
            consonanti.Append(nome[i]);

    if(consonanti.Len() >= 4){
        CodiceFiscale.Append(consonanti[0]);
        CodiceFiscale.Append(consonanti[2]);
        CodiceFiscale.Append(consonanti[3]);
    }else if(consonanti.Len() == 3){
        for(int i = 0; i < 3; i++)
            CodiceFiscale.Append(consonanti[i]);
    }else if(consonanti.Len() == 2 && nome.Len() >= 3){
        CodiceFiscale.Append(consonanti[0]);
        CodiceFiscale.Append(consonanti[1]);
        CodiceFiscale.Append(vocali[0]);
    }else if(consonanti.Len() == 1 && nome.Len() >= 3){
        CodiceFiscale.Append(consonanti[0]);
        CodiceFiscale.Append(vocali[0]);
        CodiceFiscale.Append(vocali[1]);
    }else if(consonanti.Len() == 0){
        CodiceFiscale.Append(vocali[0]);
        CodiceFiscale.Append(vocali[1]);
        if(vocali.Len() >= 3)
            CodiceFiscale.Append(vocali[2]);
        else
            CodiceFiscale.Append('X');
    }else if(nome.Len() < 3){
        int count = 0;
        for(size_t i = 0; i < consonanti.Len() && count < 3; i++, count++)
            CodiceFiscale.Append(consonanti[i]);
        for(size_t i = 0; i < vocali.Len() && count < 3; i++, count++)
            CodiceFiscale.Append(vocali[i]);
        if(count == 2)
            CodiceFiscale.Append('X');
    }
    CodiceFiscale.Append(' ');

    //Costruisco la parte della data di nascita e del sesso
    CodiceFiscale.Append(wxString::Format(wxT("%02d"), Anno%100));
    wxString Lettere(wxT("ABCDEHLMPRST"));
    CodiceFiscale.Append(Lettere[Mese-1]);
    if(Sesso == Maschio)
        CodiceFiscale.Append(wxString::Format(wxT("%02d"), Giorno));
    else
        CodiceFiscale.Append(wxString::Format(wxT("%d"), Giorno+40));
    CodiceFiscale.Append(' ');

    //Inserisco il codice del comune di nascita
    CodiceFiscale.Append(CodiceComune);
    CodiceFiscale.Trim();
    CodiceFiscale.Append(' ');

    //Inserisco il codice di controllo
    CodiceFiscale.Append(CalcolaCodiceControllo(CodiceFiscale));

    STCodiceFiscale2->SetLabel(CodiceFiscale);
}

/*! \brief Funzione \c CalcolaCodiceControllo.
    @param CF Il Codice Fiscale di cui calcolare il codice di controllo.
    @return Il codice di controllo.

    La funzione calcola il codice di controllo a partire dal Codice Fiscale parziale.
*/
wxChar CodiceFiscaleFrame::CalcolaCodiceControllo(const wxString& CF)
{
    wxString CFRaw = CF, Alfabeto(wxT("ABCDEFGHIJKLMNOPQRSTUVWXYZ"));
    int val = 0;
    CFRaw.Replace(wxT(" "), wxT(""));

    for(size_t i = 0; i < CFRaw.Len(); i++)
    {
        if(i%2){//Indice dispari, posizione pari
            if(CFRaw[i] == 'A' || CFRaw[i] == '0')
                val += 0;
            else if(CFRaw[i] == 'B' || CFRaw[i] == '1')
                val += 1;
            else if(CFRaw[i] == 'C' || CFRaw[i] == '2')
                val += 2;
            else if(CFRaw[i] == 'D' || CFRaw[i] == '3')
                val += 3;
            else if(CFRaw[i] == 'E' || CFRaw[i] == '4')
                val += 4;
            else if(CFRaw[i] == 'F' || CFRaw[i] == '5')
                val += 5;
            else if(CFRaw[i] == 'G' || CFRaw[i] == '6')
                val += 6;
            else if(CFRaw[i] == 'H' || CFRaw[i] == '7')
                val += 7;
            else if(CFRaw[i] == 'I' || CFRaw[i] == '8')
                val += 8;
            else if(CFRaw[i] == 'J' || CFRaw[i] == '9')
                val += 9;
            else if(CFRaw[i] == 'K')
                val += 10;
            else if(CFRaw[i] == 'L')
                val += 11;
            else if(CFRaw[i] == 'M')
                val += 12;
            else if(CFRaw[i] == 'N')
                val += 13;
            else if(CFRaw[i] == 'O')
                val += 14;
            else if(CFRaw[i] == 'P')
                val += 15;
            else if(CFRaw[i] == 'Q')
                val += 16;
            else if(CFRaw[i] == 'R')
                val += 17;
            else if(CFRaw[i] == 'S')
                val += 18;
            else if(CFRaw[i] == 'T')
                val += 19;
            else if(CFRaw[i] == 'U')
                val += 20;
            else if(CFRaw[i] == 'V')
                val += 21;
            else if(CFRaw[i] == 'W')
                val += 22;
            else if(CFRaw[i] == 'X')
                val += 23;
            else if(CFRaw[i] == 'Y')
                val += 24;
            else if(CFRaw[i] == 'Z')
                val += 25;
        }else{//Indice pari, posizione dispari
            if(CFRaw[i] == 'A' || CFRaw[i] == '0')
                val += 1;
            else if(CFRaw[i] == 'B' || CFRaw[i] == '1')
                val += 0;
            else if(CFRaw[i] == 'C' || CFRaw[i] == '2')
                val += 5;
            else if(CFRaw[i] == 'D' || CFRaw[i] == '3')
                val += 7;
            else if(CFRaw[i] == 'E' || CFRaw[i] == '4')
                val += 9;
            else if(CFRaw[i] == 'F' || CFRaw[i] == '5')
                val += 13;
            else if(CFRaw[i] == 'G' || CFRaw[i] == '6')
                val += 15;
            else if(CFRaw[i] == 'H' || CFRaw[i] == '7')
                val += 17;
            else if(CFRaw[i] == 'I' || CFRaw[i] == '8')
                val += 19;
            else if(CFRaw[i] == 'J' || CFRaw[i] == '9')
                val += 21;
            else if(CFRaw[i] == 'K')
                val += 2;
            else if(CFRaw[i] == 'L')
                val += 4;
            else if(CFRaw[i] == 'M')
                val += 18;
            else if(CFRaw[i] == 'N')
                val += 20;
            else if(CFRaw[i] == 'O')
                val += 11;
            else if(CFRaw[i] == 'P')
                val += 3;
            else if(CFRaw[i] == 'Q')
                val += 6;
            else if(CFRaw[i] == 'R')
                val += 8;
            else if(CFRaw[i] == 'S')
                val += 12;
            else if(CFRaw[i] == 'T')
                val += 14;
            else if(CFRaw[i] == 'U')
                val += 16;
            else if(CFRaw[i] == 'V')
                val += 10;
            else if(CFRaw[i] == 'W')
                val += 22;
            else if(CFRaw[i] == 'X')
                val += 25;
            else if(CFRaw[i] == 'Y')
                val += 24;
            else if(CFRaw[i] == 'Z')
                val += 23;
        }
    }
    return Alfabeto[val%26];
}

/*! \brief Funzione \c InitComuni.

    La funzione carica i Comuni dal file di testo al vettore dei Comuni.
*/
void CodiceFiscaleFrame::InitComuni()
{
    int index;
    wxTextFile File;
    wxStringTokenizer stk;

    File.Open(wxT("lista.txt"), wxConvUTF8);
    if(!File.IsOpened()){
        ShowMessage(wxT("Impossibilie aprire la lista dei comuni (lista.txt)"), wxT("Errore"), wxICON_ERROR);
        Destroy();
        return;
    }
    nComuni = File.GetLineCount();
    comuni = new Comune[nComuni];

    for(size_t i = 0; i < nComuni; i++)
    {
        if(File.GetLine(i).Len() == 0) continue;
        stk.SetString(File.GetLine(i), wxT(":"), wxTOKEN_RET_EMPTY_ALL);
        if(stk.CountTokens() != 3) continue;
        index = 0;
        while(stk.HasMoreTokens())
        {
            if(index  == 0)
                comuni[i].SetNome(stk.GetNextToken());
            else if(index  == 1)
                comuni[i].SetProvincia(stk.GetNextToken());
            else
                comuni[i].SetCodice(stk.GetNextToken());
            index++;
        }
    }
    File.Close();
}

/*! \brief Funzione \c CheckInput.
    @return \c true se l'input &egrave; valido, \c false altrimenti.

    La funzione verifica che l'input per il calcolo del Codice Fiscale sia valido.
*/
bool CodiceFiscaleFrame::CheckInput()
{
    bool Check = true;
    Cognome = TCCognome->GetValue();
    Nome    = TCNome->GetValue();
    ComuneNascita  = MTCComuneNascita->GetValue();
    Giorno  = CBGiorno->GetCurrentSelection();
    Mese    = CBMese->GetCurrentSelection();
    wxString SAnno    = TCAnno->GetValue();
    SAnno.ToULong(&Anno, 10);

    if(Cognome.Len() == 0){
        ShowMessage(wxT("Inserire Cognome"), wxT("Errore"), wxICON_EXCLAMATION);
        Check = false;
    }else if(Cognome.Len() == 1 || (Cognome.Len() > 0 && !IsValido(Cognome))){
        ShowMessage(wxT("Cognome non valido"), wxT("Errore"), wxICON_EXCLAMATION);
        Check = false;
    }

    if(Nome.Len() == 0){
        ShowMessage(wxT("Inserire Nome"), wxT("Errore"), wxICON_EXCLAMATION);
        Check = false;
    }else if(Nome.Len() == 1 || (Nome.Len() > 0 && !IsValido(Nome))){
        ShowMessage(wxT("Nome non valido"), wxT("Errore"), wxICON_EXCLAMATION);
        Check = false;
    }

    if(CBSesso->GetCurrentSelection() < 0){
        ShowMessage(wxT("Scegliere il sesso"), wxT("Errore"), wxICON_EXCLAMATION);
        Check = false;
    }else if(CBSesso->GetCurrentSelection() == 0)
        Sesso = Maschio;
    else
        Sesso = Femmina;

    if(ComuneNascita.Len() == 0){
        ShowMessage(wxT("Inserire Comune di nascita"), wxT("Errore"), wxICON_EXCLAMATION);
        Check = false;
    }else{
        int index = 0;
        if(ComuneNascita.Len() > 0 && (index = TrovaComune(ComuneNascita)) == -1){
            ShowMessage(wxT("Comune inesistente"), wxT("Errore"), wxICON_EXCLAMATION);
            Check = false;
        }else{
            STProvincia2->SetLabel(comuni[index].GetProvincia());
            CodiceComune = comuni[index].GetCodice();
        }
    }

    if(Giorno == -1 || Mese == -1 || SAnno.Len() == 0){
        ShowMessage(wxT("Inserire Data di nascita"), wxT("Errore"), wxICON_EXCLAMATION);
        Check = false;
    }else if(!SAnno.IsNumber() || Anno < 1900 || Anno > (unsigned int)wxDateTime::GetCurrentYear()){
        ShowMessage(wxT("Anno non valido"), wxT("Errore"), wxICON_EXCLAMATION);
        Check = false;
    }else{
        //La selezione della ComboBox parte da 0
        Giorno++;
        Mese++;

        wxDateTime Time;
        Time.SetDay((unsigned short)Giorno);
        if(Mese == 1)
            Time.SetMonth(wxDateTime::Jan);
        else if(Mese == 2)
            Time.SetMonth(wxDateTime::Feb);
        else if(Mese == 3)
            Time.SetMonth(wxDateTime::Mar);
        else if(Mese == 4)
            Time.SetMonth(wxDateTime::Apr);
        else if(Mese == 5)
            Time.SetMonth(wxDateTime::May);
        else if(Mese == 6)
            Time.SetMonth(wxDateTime::Jun);
        else if(Mese == 7)
            Time.SetMonth(wxDateTime::Jul);
        else if(Mese == 8)
            Time.SetMonth(wxDateTime::Aug);
        else if(Mese == 9)
            Time.SetMonth(wxDateTime::Sep);
        else if(Mese == 10)
            Time.SetMonth(wxDateTime::Oct);
        else if(Mese == 11)
            Time.SetMonth(wxDateTime::Nov);
        else if(Mese == 12)
            Time.SetMonth(wxDateTime::Dec);
        Time.SetYear(Anno);

        if(Time.IsLaterThan(wxDateTime::Today()) && !Time.IsSameDate(wxDateTime::Today())){
            ShowMessage(wxT("Data non valida"), wxT("Errore"), wxICON_EXCLAMATION);
            Check = false;
        }
    }
    return Check;
}

/*! \brief Funzione \c IsVocale.
    @param c Caraterre da verificare.
    @return \c true se il carattere &egrave; una vocale valido, \c false altrimenti.

    La funzione verifica che l'argomento sia o meno una vocale.
*/
bool CodiceFiscaleFrame::IsVocale(wxChar c)
{
    return (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U');
}

/*! \brief Funzione \c IsValido.
    @param str String da verificare.
    @return \c true se la stringa &egrave; valida, \c false altrimenti.

    La funzione verifica che l'argomento contenga solo carattere validi.
*/
bool CodiceFiscaleFrame::IsValido(const wxString& str)
{
    wxString ValidChars(wxT("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz' "));
    for(size_t i = 0; i < str.Len(); i++)
        if(ValidChars.Find(str[i]) == wxNOT_FOUND)
            return false;
    return true;
}

/*! \brief Funzione \c TrovaComune.
    @param com Comune da trovare.
    @return Indice nel vettore del Comune, se presente, -1 in caso contrario.

    La funzione ritorna l'indice nel vettore del Comune passato per argomento.
*/
int CodiceFiscaleFrame::TrovaComune(const wxString& com)
{
    for(size_t i = 0; i < nComuni; i++)
        if(!comuni[i].GetNome().CmpNoCase(com))
            return i;
    return -1;
}

/*! \brief Funzione \c ShowMessage.
    @param message Messaggio da visualizzare.
    @param caption Titolo del dialogo.
    @param flags Flag del dialogo.
    @return Il valore di ritorno della ShowModal() del dialogo.

    La funzione mostra semplicemente un messaggio.
*/
int CodiceFiscaleFrame::ShowMessage(const wxString& message, const wxString& caption, int flags)
{
     int ret;
     wxMessageDialog * dial = new wxMessageDialog(NULL, message, caption, flags);
     ret = dial->ShowModal();
     dial->Destroy();
     return ret;
}
