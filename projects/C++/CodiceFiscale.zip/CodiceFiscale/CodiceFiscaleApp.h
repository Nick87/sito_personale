#ifndef CODICEFISCALEAPP_H
#define CODICEFISCALEAPP_H

#include <wx/app.h>
#include "CodiceFiscaleMain.h"
#include <wx/snglinst.h>

/*! \mainpage Codice Fiscale 1.0
 * \section Autore
 * Nicola Alessandro Domingo.
 * \section Anno
 * 2010
 * \section Licenza
 * GNU GPLv3
 */

/*! \class CodiceFiscaleApp CodiceFiscaleApp.h "CodiceFiscaleApp.h"
 *  \brief Classe CodiceFiscaleApp.
 *
 *  La classe dell'applicazione principale.
 */
class CodiceFiscaleApp:public wxApp
{
    public:
        CodiceFiscaleApp(); ///< Costruttore di default.
        ~CodiceFiscaleApp(); ///< Distruttore.
        virtual bool OnInit();

    private:
        CodiceFiscaleFrame * frame; ///< Frame principale.
        wxSingleInstanceChecker * mChecker; ///< Per il controllo dell'istanza del programma.
        int FilterEvent(wxEvent&);
};

#endif
