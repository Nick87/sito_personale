#include "MyDialog.h"
#include <wx/tokenzr.h>
#include <wx/textfile.h>
#include <wx/statline.h>

enum
{
    ButtonSi = 1030,
    ButtonNo,
    CBox,
};

BEGIN_EVENT_TABLE(MyDialog, wxDialog)
    EVT_BUTTON(ButtonSi, MyDialog::OnSi)
    EVT_BUTTON(ButtonNo, MyDialog::OnNo)
    EVT_CHECKBOX(CBox, MyDialog::OnCheckBox)
END_EVENT_TABLE()

/*! @param parent Genitore
    @param id id della fnestra
    @param title Titolo della finestra
*/
MyDialog::MyDialog(wxWindow* parent, wxWindowID id, const wxString& title)
                   :wxDialog(parent, id, title, wxDefaultPosition, wxSize(230, 182), (wxCAPTION | wxTHICK_FRAME) & ~(wxRESIZE_BORDER))
{
    wxBoxSizer * topsizer = new wxBoxSizer(wxVERTICAL);
    wxPanel * panel = new wxPanel(this, wxID_ANY);
    wxBoxSizer * vbox = new wxBoxSizer(wxVERTICAL);
    wxBoxSizer * hbox1 = new wxBoxSizer(wxHORIZONTAL);
    wxStaticText * Text = new wxStaticText(panel, wxID_ANY, wxT("Sei sicuro di voler uscire?"));
    wxStaticLine * line = new wxStaticLine(panel, wxID_ANY);
    wxBoxSizer * hbox2 = new wxBoxSizer(wxHORIZONTAL);
    wxButton * BtnSi  = new wxButton(panel, ButtonSi, wxT("&S�"));
    wxButton * BtnNo  = new wxButton(panel, ButtonNo, wxT("&No"));
    CheckBox = new wxCheckBox(panel, CBox, wxT("Non chiederlo nuovamente"));
    wxBoxSizer * hbox3 = new wxBoxSizer(wxHORIZONTAL);

    wxStaticBitmap * bmpConferma = new wxStaticBitmap(panel, wxID_ANY, wxBitmap(wxT("images/Conferma.bmp"), wxBITMAP_TYPE_ANY));
	hbox1->Add(bmpConferma, 0, wxALIGN_CENTER_VERTICAL);
	hbox1->Add(Text, 0, wxALIGN_CENTER_VERTICAL | wxLEFT, 10);
	vbox->Add(hbox1, 0, wxTOP | wxBOTTOM, 10);
	vbox->Add(line, 0, wxEXPAND | wxLEFT | wxRIGHT, 10);
	hbox2->AddStretchSpacer(1);
	hbox2->Add(BtnSi, 0, wxALIGN_CENTER_VERTICAL);
	hbox2->Add(BtnNo, 0, wxALIGN_CENTER_VERTICAL);
	hbox2->AddStretchSpacer(1);
	vbox->Add(hbox2, 1, wxEXPAND);
	hbox3->Add(CheckBox, 0, wxLEFT | wxTOP, 10);
	vbox->Add(hbox3, 1, wxTOP, 5);

	wxTextFile File(wxT("config.ini"));
    if(!File.Exists())
        CheckBox->Enable(false);
    else
        CheckBox->Enable(true);
    File.Close();

	panel->SetSizer(vbox);
	topsizer->Add(panel, 1, wxEXPAND);
	this->SetSizer(topsizer);
	this->Centre();
}

MyDialog::~MyDialog() {}

/*! Funzione chiamata se si clicca S&igrave; */
void MyDialog::OnSi(wxCommandEvent& event)
{
    EndModal(wxID_YES);
}

/*! Funzione chiamata se si clicca No */
void MyDialog::OnNo(wxCommandEvent& event)
{
    EndModal(wxID_NO);
}

/*! Funzione chiamata se si clicca sulla CheckBox del dialogo */
void MyDialog::OnCheckBox(wxCommandEvent& event)
{
    wxTextFile File;
    wxStringTokenizer stk;
    File.Open(wxT("config.ini"), wxConvUTF8);

    if(!File.IsOpened()){
        wxLogError(wxT("Impossibile aprire il file di configurazione (config.ini)"));
        return;
    }

    for(size_t i = 0; i < File.GetLineCount(); i++)
    {
        if(File.GetLine(i).Len() == 0) continue;
        stk.SetString(File.GetLine(i), wxT("="), wxTOKEN_RET_EMPTY_ALL);
        if(stk.CountTokens() != 2) continue;

        if(stk.GetNextToken().Trim().Trim(false) == wxT("CONFIRM_ON_EXIT"))
        {
            if(CheckBox->GetValue()){
                File.RemoveLine(i);
                File.InsertLine(wxT("CONFIRM_ON_EXIT=0"), i, wxTextFileType_Dos);
            }else{
                File.RemoveLine(i);
                File.InsertLine(wxT("CONFIRM_ON_EXIT=1"), i, wxTextFileType_Dos);
            }
            break;
        }
    }
    File.Write(wxTextFileType_Dos, wxConvUTF8);
    File.Close();
}
