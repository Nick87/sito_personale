#include "Comune.h"

/*! \brief Setta il nome del Comune, della Provincia,
    e il Codice catastale a wxEmptyString
*/
Comune::Comune()
{
    Nome = Provincia = Codice = wxEmptyString;
}

/*! @param n Nome del comune
    @param p Nome della privincia
    @param c Codice catastale del comune
*/
Comune::Comune(const wxString& n, const wxString& p, const wxString& c)
{
    Nome = n;
    Provincia = p;
    Codice = c;
}

/*! \brief Distruttore virtuale */
Comune::~Comune() {}
