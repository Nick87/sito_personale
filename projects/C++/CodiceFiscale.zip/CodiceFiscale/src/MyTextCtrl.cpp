#include "MyTextCtrl.h"

BEGIN_EVENT_TABLE(MyTextCtrl, wxTextCtrl)
    EVT_TEXT(wxID_ANY, MyTextCtrl::TextEntered)
    EVT_IDLE(MyTextCtrl::DoIdle)
    EVT_KEY_DOWN(MyTextCtrl::DoKeyDown)
END_EVENT_TABLE()

/*! @param parent Genitore.
    @param id id Finestra.
    @param f Flags.
    @param value Valore iniziale della casella di testo.
    @param pos Posizione della casella di testo.
    @param size Dimensione della casella di testo.
    @param style Stile della casella di testo.
    @param validator Validator della casella di testo.
    @param name Nome della casella di testo.

    Il parametro \c f pu&ograve; essere l'OR di UPPER (0x00000001) e SPACE (0x00000002).
*/
MyTextCtrl::MyTextCtrl(wxWindow * parent, wxWindowID id, int f, const wxString& value, const wxPoint& pos,
                       const wxSize& size, long style, const wxValidator& validator, const wxString& name)
:wxTextCtrl(parent, id, value, pos, size, style, validator, name)
{
    IgnoreNextTextEdit = false;
    Flags = f;
    nComuni = 0;
}

/*! Distruttore virtuale. */
MyTextCtrl::~MyTextCtrl() {}

/*! \brief Funzione \c DoIdle.

    La funziona setta a \c false il parametro IgnoreNextTextEdit
    durante cicli di idle del programma.
*/
void MyTextCtrl::DoIdle(wxIdleEvent& event)
{
    IgnoreNextTextEdit = false;
    event.Skip();
}

/*! \brief Funzione \c TextEntered.

    La funzione viene eseguita ogni volta che viene effettuato un inserimento
    nella casella di testo.
*/
void MyTextCtrl::TextEntered(wxCommandEvent& event)
{
    wxString temp, match;
    long InsPoint = GetInsertionPoint();

    if(Flags&UPPER)
        temp = MyUpper(GetValue());

    //FIXME Sistemare sostituzione dopo selezione
    if(Flags&SPACE)
    {
        //Per non ignorare le cancellazioni
        if(IgnoreNextTextEdit)
            return;

        ChangeValue(Space(temp));
        short len = GetValue().Len();
        if(len <= 3)
            SetInsertionPoint(InsPoint);
        else if(len <= 6)
            SetInsertionPoint(InsPoint+1);
        else if(len <= 11)
            SetInsertionPoint(InsPoint+2);
        else if(len <= 15)
            SetInsertionPoint(InsPoint+3);
        else
            SetInsertionPoint(InsPoint+4);
        return;
    }
    if((Flags&UPPER) || (Flags&SPACE)){
        ChangeValue(temp);
        SetInsertionPoint(InsPoint);
    }

    if(IgnoreNextTextEdit){
        event.Skip();
        return;
    }
    InsPoint = GetInsertionPoint();

    //Per l'auto completamento dobbiamo essere nell'ultima posizione
    if(GetInsertionPoint() != GetLastPosition() || GetValue() == LastMatch){
        event.Skip();
        return;
    }
    if((match = GetFirstMatch(GetValue())) != wxEmptyString){
        ChangeValue(match);
        SetSelection(InsPoint, -1);
    }
}

/*! \brief Funzione \c MyUpper.
    @param str Stringa da trasformare in maiuscolo.
    @return Stringa trasformata in maiuscolo

    La funzione trasforma in maiuscolo la stringa passata.
    Si &egrave; deciso di implementarla poich&egrave; \c str potrebbe
    contenere numeri, e ci&ograve; causa problemi.
*/
wxString MyTextCtrl::MyUpper(const wxString& str)
{
    wxString temp = str, UP(wxT("ABCDEFGHIJKLMNOPQRSTUVWXYZ"));
    for(size_t i = 0; i < temp.Len(); i++)
        if(temp[i] >= 'a' && temp[i] <= 'z')
            temp[i] = UP[temp[i]-'a'];
    return temp;
}

/*! \brief Funzione \c Space.
    @param str Stringa da spaziare.
    @return Stringa spaziata.

    La funzione aggiunge gli spazi all'interno della stringa
    per migliorare la leggibilit&agrave; del Codice Fiscale.
*/
wxString MyTextCtrl::Space(const wxString& str)
{
    wxString temp;
    size_t i, Len = str.Len();

    if(Len == 20)
        return str;
    if(Len <= 3){
        temp = str;
        if(Len == 3)
            temp.Append((wxChar)' ');
    }else if(Len <= 7){
        for(i = 0; i <= 2; i++)
            temp.Append(str[i]);
        temp.Append((wxChar)' ');
        for(i = 4; i < Len; i++)
            temp.Append(str[i]);
        if(Len == 7)
            temp.Append((wxChar)' ');
    }else if(Len <= 13){
        for(i = 0; i <= 2; i++)
            temp.Append(str[i]);
        temp.Append((wxChar)' ');
        for(i = 4; i <= 6; i++)
            temp.Append(str[i]);
        temp.Append((wxChar)' ');
        for(i = 8; i < Len; i++)
            temp.Append(str[i]);
        if(Len == 13)
            temp.Append((wxChar)' ');
    }else if(Len <= 18){
        for(i = 0; i <= 2; i++)
            temp.Append(str[i]);
        temp.Append((wxChar)' ');
        for(i = 4; i <= 6; i++)
            temp.Append(str[i]);
        temp.Append((wxChar)' ');
        for(i = 8; i <= 12; i++)
            temp.Append(str[i]);
        temp.Append((wxChar)' ');
        for(i = 14; i < Len; i++)
            temp.Append(str[i]);
        if(Len == 18)
            temp.Append((wxChar)' ');
    }else{
        for(i = 0; i <= 2; i++)
            temp.Append(str[i]);
        temp.Append((wxChar)' ');
        for(i = 4; i <= 6; i++)
            temp.Append(str[i]);
        temp.Append((wxChar)' ');
        for(i = 8; i <= 12; i++)
            temp.Append(str[i]);
        temp.Append((wxChar)' ');
        for(i = 14; i <= 17; i++)
            temp.Append(str[i]);
        temp.Append((wxChar)' ');
        temp.Append(str[19]);
    }
    return temp;
}

/*! \brief Funzione \c DoKeyDown.

    La funzione viene eseguita alla pressione di un tasto.
    In particolare, se &egrave; la spaziatura gli spazi vengono rifiutati, e nel caso
    stiamo cancellando dalla casella di testo, disattiviamo l'auto-completamento,
    impostando \c IgnoreNextTextEdit a \c true.
*/
void MyTextCtrl::DoKeyDown(wxKeyEvent& event)
{
    int KeyCode = event.GetKeyCode();
    if(KeyCode == WXK_SPACE && (Flags&&SPACE))
        return;
    if(KeyCode == WXK_DELETE || KeyCode == WXK_NUMPAD_DELETE || KeyCode == WXK_BACK || KeyCode == WXK_CLEAR)
       IgnoreNextTextEdit = true;
    else
       IgnoreNextTextEdit = false;
    event.Skip();
}

/*! \brief Funzione \c GetFirstMatch.
    @param str Stringa di cui trovare il primo match.
    @return Il primo match trovato.

    La funzione ricerca nel vettore dei comuni Comuni e ritorna il primo
    Comune che inizia con la stringa \c str passata come parametro.
*/
wxString MyTextCtrl::GetFirstMatch(const wxString& str)
{
    for(int i = 0; i < nComuni; i++)
    {
        if(MyStartsWith(comuni[i].GetNome(), str)){
            LastMatch = comuni[i].GetNome();
            return LastMatch;
        }
    }
    return wxEmptyString;
}

/*! \brief Funzione \c MyStartsWith.
    @param s1 Prima stringa.
    @param s2 Seconda stringa.
    @return \c true se \c s1 inizia con \c s2.

    La funzione verifica che \c s1 inizi con \c s2, senza distinzione
    tra maiuscole e minuscole.
*/
bool MyTextCtrl::MyStartsWith(const wxString& s1, const wxString& s2)
{
    return (s1.Lower().StartsWith(s2.Lower().GetData()));
}
