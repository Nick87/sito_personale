#ifdef WX_PRECOMP
#include "wx_pch.h"
#endif

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#include "CodiceFiscaleApp.h"

IMPLEMENT_APP(CodiceFiscaleApp);

CodiceFiscaleApp::CodiceFiscaleApp(){}

CodiceFiscaleApp::~CodiceFiscaleApp()
{
    delete mChecker;
}

/*! \brief Funzione \c OnInit
    @return \c false se &egrave; in esecuzione un'altra instanza del programma,
    \c true in caso contrario.

    La funzione principale che crea il frame principale e avvia l'applicazione.
*/
bool CodiceFiscaleApp::OnInit()
{
    const wxString name = wxString::Format(wxT("CodiceFiscale-%s"), wxGetUserId().c_str());
    int Flags = wxDEFAULT_FRAME_STYLE;
    mChecker = new wxSingleInstanceChecker(name);
    if (mChecker->IsAnotherRunning()){
       wxLogWarning(wxT("Non ti basta una sola istanza del programma?"));
       return false;
    }

    Flags = Flags & ~(wxRESIZE_BORDER | wxRESIZE_BOX | wxMAXIMIZE_BOX);
    frame = new CodiceFiscaleFrame(0L, wxT("Calcolo Codice Fiscale"), wxSize(400, 250), Flags);
    frame->SetIcon(wxICON(icon));
    frame->Show();

    return true;
}

/*! \brief Funzione \c FilterEvent

    La funzione intercetta la pressione del tasto ESC per la chiusura del programma.
*/
int CodiceFiscaleApp::FilterEvent(wxEvent& event)
{
    if (event.GetEventType() == wxEVT_KEY_DOWN && ((wxKeyEvent&)event).GetKeyCode() == WXK_ESCAPE){
        frame->OnClose((wxCloseEvent&) event);
        return true;
    }
    return -1;
}
