﻿namespace VariabiliGlobali
{
    public class Globals
    {
        public static string basePath = string.Empty;
    }
}