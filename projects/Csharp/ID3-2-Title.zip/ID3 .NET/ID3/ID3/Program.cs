﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace ID3
{
    static class Program
    {
        /// <summary>
        /// Punto di ingresso principale dell'applicazione.
        /// </summary>
        [STAThread]
        static void Main()
        {
            bool ok;
            System.Threading.Mutex mutex = new System.Threading.Mutex(true, "NicolaAlessandroDomingo", out ok);
            if (!ok) {
                MessageBox.Show("Un'istanza dell'applicazione è già in esecuzione.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
            GC.KeepAlive(mutex);
        }
    }
}
