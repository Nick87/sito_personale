﻿namespace ID3
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sfogliaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salvaInToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estraiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fermaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pausaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selezioneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selezionaTuttoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deselezionaTuttoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.invertiSelezioneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.creditsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listView = new System.Windows.Forms.ListView();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.percentLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.progressBar = new System.Windows.Forms.ToolStripProgressBar();
            this.statusBarText = new System.Windows.Forms.ToolStripStatusLabel();
            this.estraiStatusBar = new System.Windows.Forms.ToolStripStatusLabel();
            this.modalitàEstrazioneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sempliceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estesaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.selezioneToolStripMenuItem,
            this.toolStripMenuItem1});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.menuStrip.Size = new System.Drawing.Size(334, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "menuStrip1";
            this.menuStrip.DoubleClick += new System.EventHandler(this.menuStrip_DoubleClick);
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sfogliaToolStripMenuItem,
            this.modalitàEstrazioneToolStripMenuItem,
            this.salvaInToolStripMenuItem,
            this.estraiToolStripMenuItem,
            this.fermaToolStripMenuItem,
            this.pausaToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // sfogliaToolStripMenuItem
            // 
            this.sfogliaToolStripMenuItem.Name = "sfogliaToolStripMenuItem";
            this.sfogliaToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.sfogliaToolStripMenuItem.Text = "Sfoglia...";
            this.sfogliaToolStripMenuItem.Click += new System.EventHandler(this.sfogliaToolStripMenuItem_Click);
            // 
            // salvaInToolStripMenuItem
            // 
            this.salvaInToolStripMenuItem.Name = "salvaInToolStripMenuItem";
            this.salvaInToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.salvaInToolStripMenuItem.Text = "Estrai in...";
            this.salvaInToolStripMenuItem.Click += new System.EventHandler(this.salvaInToolStripMenuItem_Click);
            // 
            // estraiToolStripMenuItem
            // 
            this.estraiToolStripMenuItem.Name = "estraiToolStripMenuItem";
            this.estraiToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.estraiToolStripMenuItem.Text = "Estrai";
            this.estraiToolStripMenuItem.Click += new System.EventHandler(this.estraiToolStripMenuItem_Click);
            // 
            // fermaToolStripMenuItem
            // 
            this.fermaToolStripMenuItem.Name = "fermaToolStripMenuItem";
            this.fermaToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.fermaToolStripMenuItem.Text = "Ferma";
            this.fermaToolStripMenuItem.Click += new System.EventHandler(this.fermaToolStripMenuItem_Click);
            // 
            // pausaToolStripMenuItem
            // 
            this.pausaToolStripMenuItem.Name = "pausaToolStripMenuItem";
            this.pausaToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.pausaToolStripMenuItem.Text = "Pausa";
            this.pausaToolStripMenuItem.Click += new System.EventHandler(this.pausaToolStripMenuItem_Click);
            // 
            // selezioneToolStripMenuItem
            // 
            this.selezioneToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.selezionaTuttoToolStripMenuItem,
            this.deselezionaTuttoToolStripMenuItem,
            this.invertiSelezioneToolStripMenuItem});
            this.selezioneToolStripMenuItem.Name = "selezioneToolStripMenuItem";
            this.selezioneToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.selezioneToolStripMenuItem.Text = "Selezione";
            // 
            // selezionaTuttoToolStripMenuItem
            // 
            this.selezionaTuttoToolStripMenuItem.Name = "selezionaTuttoToolStripMenuItem";
            this.selezionaTuttoToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.selezionaTuttoToolStripMenuItem.Text = "Seleziona tutto";
            this.selezionaTuttoToolStripMenuItem.Click += new System.EventHandler(this.selezionaTuttoToolStripMenuItem_Click);
            // 
            // deselezionaTuttoToolStripMenuItem
            // 
            this.deselezionaTuttoToolStripMenuItem.Name = "deselezionaTuttoToolStripMenuItem";
            this.deselezionaTuttoToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.deselezionaTuttoToolStripMenuItem.Text = "Deseleziona tutto";
            this.deselezionaTuttoToolStripMenuItem.Click += new System.EventHandler(this.deselezionaTuttoToolStripMenuItem_Click);
            // 
            // invertiSelezioneToolStripMenuItem
            // 
            this.invertiSelezioneToolStripMenuItem.Name = "invertiSelezioneToolStripMenuItem";
            this.invertiSelezioneToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.invertiSelezioneToolStripMenuItem.Text = "Inverti selezione";
            this.invertiSelezioneToolStripMenuItem.Click += new System.EventHandler(this.invertiSelezioneToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.creditsToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(24, 20);
            this.toolStripMenuItem1.Text = "?";
            // 
            // creditsToolStripMenuItem
            // 
            this.creditsToolStripMenuItem.Name = "creditsToolStripMenuItem";
            this.creditsToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.creditsToolStripMenuItem.Text = "Credits";
            this.creditsToolStripMenuItem.Click += new System.EventHandler(this.creditsToolStripMenuItem_Click);
            // 
            // listView
            // 
            this.listView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.listView.CheckBoxes = true;
            this.listView.Location = new System.Drawing.Point(0, 24);
            this.listView.Name = "listView";
            this.listView.Size = new System.Drawing.Size(334, 214);
            this.listView.TabIndex = 1;
            this.listView.UseCompatibleStateImageBehavior = false;
            this.listView.View = System.Windows.Forms.View.Details;
            this.listView.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.listView_ColumnClick);
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxSearch.Location = new System.Drawing.Point(199, 2);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(134, 20);
            this.textBoxSearch.TabIndex = 3;
            this.textBoxSearch.TextChanged += new System.EventHandler(this.textBoxSearch_TextChanged);
            this.textBoxSearch.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxSearch_KeyPress);
            this.textBoxSearch.MouseUp += new System.Windows.Forms.MouseEventHandler(this.textBoxSearch_MouseUp);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.percentLabel,
            this.progressBar,
            this.statusBarText,
            this.estraiStatusBar});
            this.statusStrip1.Location = new System.Drawing.Point(0, 238);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(334, 24);
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // percentLabel
            // 
            this.percentLabel.Name = "percentLabel";
            this.percentLabel.Size = new System.Drawing.Size(23, 19);
            this.percentLabel.Text = "0%";
            // 
            // progressBar
            // 
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(150, 18);
            // 
            // statusBarText
            // 
            this.statusBarText.Name = "statusBarText";
            this.statusBarText.Size = new System.Drawing.Size(43, 19);
            this.statusBarText.Text = "Pronto";
            // 
            // estraiStatusBar
            // 
            this.estraiStatusBar.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.estraiStatusBar.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.estraiStatusBar.Name = "estraiStatusBar";
            this.estraiStatusBar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.estraiStatusBar.Size = new System.Drawing.Size(4, 19);
            // 
            // modalitàEstrazioneToolStripMenuItem
            // 
            this.modalitàEstrazioneToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sempliceToolStripMenuItem,
            this.estesaToolStripMenuItem});
            this.modalitàEstrazioneToolStripMenuItem.Name = "modalitàEstrazioneToolStripMenuItem";
            this.modalitàEstrazioneToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.modalitàEstrazioneToolStripMenuItem.Text = "Modalità estrazione";
            // 
            // sempliceToolStripMenuItem
            // 
            this.sempliceToolStripMenuItem.Checked = true;
            this.sempliceToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.sempliceToolStripMenuItem.Name = "sempliceToolStripMenuItem";
            this.sempliceToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.sempliceToolStripMenuItem.Text = "Semplice";
            this.sempliceToolStripMenuItem.Click += new System.EventHandler(this.sempliceToolStripMenuItem_Click);
            // 
            // estesaToolStripMenuItem
            // 
            this.estesaToolStripMenuItem.Name = "estesaToolStripMenuItem";
            this.estesaToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.estesaToolStripMenuItem.Text = "Estesa";
            this.estesaToolStripMenuItem.Click += new System.EventHandler(this.estesaToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(334, 262);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.textBoxSearch);
            this.Controls.Add(this.listView);
            this.Controls.Add(this.menuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip;
            this.MinimumSize = new System.Drawing.Size(350, 300);
            this.Name = "Form1";
            this.Text = "ID3-2-Title";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.SizeChanged += new System.EventHandler(this.Form1_SizeChanged);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sfogliaToolStripMenuItem;
        private System.Windows.Forms.ListView listView;
        private System.Windows.Forms.ToolStripMenuItem estraiToolStripMenuItem;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.ToolStripMenuItem salvaInToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selezioneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selezionaTuttoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem invertiSelezioneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deselezionaTuttoToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripProgressBar progressBar;
        private System.Windows.Forms.ToolStripStatusLabel statusBarText;
        private System.Windows.Forms.ToolStripStatusLabel estraiStatusBar;
        private System.Windows.Forms.ToolStripStatusLabel percentLabel;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem creditsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fermaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pausaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modalitàEstrazioneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sempliceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estesaToolStripMenuItem;
    }
}

