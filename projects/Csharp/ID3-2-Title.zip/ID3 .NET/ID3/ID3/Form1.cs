﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Media;
using VariabiliGlobali;
using Windows7.DesktopIntegration.WindowsForms;
using HundredMilesSoftware.UltraID3Lib;

namespace ID3
{
    public partial class Form1 : Form
    {
        private class MyItem
        {
            public ListViewItem listItem;
            public String filePath;

            public MyItem(ListViewItem item, String path)
            {
                this.listItem = item;
                this.filePath = path;
            }
        }

        private enum Parsing { OK = 0, PAUSE, STOP, CLOSE };
        private enum Mode { SIMPLE = 0, EXTENDED };
        private List<MyItem> FilesList;
        private List<MyItem> FilesListForFilter;
        private int lastLengthOfFilter;
        private string outputPath;
        private bool isRunning;
        private Parsing keepParsing;
        private Mode ExtractMode;
        private bool isFirstExtract;
        private ListViewColumnSorter lvwColumnSorter;
        private delegate void UpdateProgressBarDelegate();
        private delegate void SetProgressBarForExtract();
        private delegate void UpdateStatusBarText(int check);
        private delegate void AddItemToList(ListViewItem item);
        
        public Form1()
        {
            InitializeComponent();
            lvwColumnSorter = new ListViewColumnSorter();
            this.isFirstExtract = true;
            this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.DoubleBuffer, true);
            this.listView.ListViewItemSorter = lvwColumnSorter;
            this.keepParsing = Parsing.OK;
            this.ExtractMode = Mode.SIMPLE;
            this.isRunning = false;
            this.textBoxSearch.ForeColor = Color.Gray;
            this.textBoxSearch.Text = "Cerca...\r";
            this.estraiStatusBar.Text = Directory.GetCurrentDirectory();
            FilesList = new List<MyItem>();
            FilesListForFilter = null;
            this.lastLengthOfFilter = -1;
            this.outputPath = String.Empty;
            this.progressBar.Style = ProgressBarStyle.Continuous;
            if (isVistaOr7())
                this.SetTaskbarProgressState(Windows7.DesktopIntegration.Windows7Taskbar.ThumbnailProgressState.Normal);
            this.listView.Clear();
            createColumns();
        }

        private bool isVistaOr7()
        {
            if (Environment.OSVersion.Platform != PlatformID.Win32NT || Environment.OSVersion.Version.Major < 6)
                return false;
            return true;
        }

        private void menuStrip_DoubleClick(object sender, EventArgs e)
        {
            this.listView.Columns[0].Width = 20;
            int width = (this.ClientSize.Width - 20) / 4;
            for (int i = 1; i < 5; i++)
                this.listView.Columns[i].Width = width;
        }

        private void createColumns()
        {
            listView.View = View.Details;
            listView.CheckBoxes = true;            
            listView.GridLines = true;
            listView.FullRowSelect = true;
            ColumnHeader checkColumn = new ColumnHeader();
            checkColumn.Text = " ";
            checkColumn.Width = 20;
            checkColumn.TextAlign = HorizontalAlignment.Center;
            listView.Columns.Add(checkColumn);
            ColumnHeader fileNameColumn = new ColumnHeader();
            fileNameColumn.Text = "Nome file";
            fileNameColumn.Width = 80;
            fileNameColumn.TextAlign = HorizontalAlignment.Left;
            listView.Columns.Add(fileNameColumn);
            ColumnHeader artistColumn = new ColumnHeader();
            artistColumn.Text = "Artista";
            artistColumn.Width = 80;
            artistColumn.TextAlign = HorizontalAlignment.Left;
            listView.Columns.Add(artistColumn);
            ColumnHeader songColumn = new ColumnHeader();
            songColumn.Text = "Brano";
            songColumn.Width = 80;
            songColumn.TextAlign = HorizontalAlignment.Left;
            listView.Columns.Add(songColumn);
            ColumnHeader albumColumn = new ColumnHeader();
            albumColumn.Text = "Album";
            albumColumn.Width = 80;
            albumColumn.TextAlign = HorizontalAlignment.Left;
            listView.Columns.Add(albumColumn);
        }

        private void sfogliaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "Seleziona la cartella sorgente dei file mp3:";
            dialog.RootFolder = Environment.SpecialFolder.Desktop;
            if (dialog.ShowDialog() == DialogResult.OK && dialog.SelectedPath != String.Empty)
            {
                VariabiliGlobali.Globals.basePath = dialog.SelectedPath + "\\";
                FilesList.Clear();
                this.listView.Clear();
                createColumns();
                this.statusBarText.Text = "Pronto";
                this.progressBar.Value = 0;
                this.progressBar.Maximum = Int32.MaxValue;
                this.progressBar.Style = ProgressBarStyle.Marquee;
                if (isVistaOr7())
                    this.SetTaskbarProgressState(Windows7.DesktopIntegration.Windows7Taskbar.ThumbnailProgressState.Indeterminate);
                this.isFirstExtract = true;
                this.percentLabel.Text = "0%";
                this.keepParsing = Parsing.OK;
                new Thread(new ThreadStart(this.UpdateListView)).Start();
            }
        }

        private void UpdateListView()
        {
            this.isRunning = true;
            this.Cursor = Cursors.WaitCursor;
            this.textBoxSearch.Enabled = false;
            if (GetFileNames(VariabiliGlobali.Globals.basePath) == Parsing.CLOSE) return;
            this.textBoxSearch.Enabled = true;
            this.Cursor = Cursors.Default;
            this.isRunning = false;
            this.Invoke(new SetProgressBarForExtract(this.doSetProgressBarForExtract));
            this.Invoke(new UpdateStatusBarText(this.doUpdateStatusBarText), new object[] { 0 });
        }

        private void doSetProgressBarForExtract()
        {
            this.progressBar.Style = ProgressBarStyle.Continuous;
            if (isVistaOr7())
                this.SetTaskbarProgressState(Windows7.DesktopIntegration.Windows7Taskbar.ThumbnailProgressState.Normal);
            this.progressBar.Value = 0;
            this.progressBar.Minimum = 0;
            this.progressBar.Maximum = 1;
            if (isVistaOr7())
                this.progressBar.SetTaskbarProgress();
        }

        private Parsing GetFileNames(string path)
        {
            DirectoryInfo root = new DirectoryInfo(path);
            DirectoryInfo[] dirs = root.GetDirectories();
            foreach (DirectoryInfo dir in dirs) {
                Parsing ret = GetFileNames(path + "\\" + dir.Name);
                if (ret != Parsing.OK) return ret;
            }

            listView.ItemCheck -= new ItemCheckEventHandler(this.listView_ItemCheck);
            foreach (string filePath in Directory.GetFiles(path))
            {
                if (this.keepParsing == Parsing.CLOSE)
                    return Parsing.CLOSE;
                else if (this.keepParsing == Parsing.STOP)
                    break;
                else if (this.keepParsing == Parsing.PAUSE)
                {
                    if (isVistaOr7()) {
                        this.SetTaskbarProgressState(Windows7.DesktopIntegration.Windows7Taskbar.ThumbnailProgressState.Paused);
                        this.progressBar.SetTaskbarProgress();
                    }
                    this.Cursor = Cursors.Default;

                    while(this.keepParsing == Parsing.PAUSE) {
                        Thread.Sleep(50);
                        continue;
                    }

                    if (this.keepParsing == Parsing.CLOSE)
                        return Parsing.CLOSE;
                    else if (this.keepParsing == Parsing.STOP)
                        break;

                    this.Cursor = Cursors.WaitCursor;
                    if (isVistaOr7()) {
                        this.SetTaskbarProgressState(Windows7.DesktopIntegration.Windows7Taskbar.ThumbnailProgressState.Indeterminate);
                        this.progressBar.SetTaskbarProgress();
                    }
                }
                
                if (Path.GetExtension(filePath).ToLower() == ".mp3")
                {
                    try
                    {
                        String fileName = Path.GetFileName(filePath);
                        ListViewItem item = new ListViewItem();
                        item.Checked = false;
                        UltraID3 u = new UltraID3();
                        u.Read(filePath);

                        item.SubItems.Add(fileName);
                        if (u.Artist == String.Empty && u.Title == String.Empty && u.Album == String.Empty) {
                            item.SubItems.Add(fileName);
                            item.SubItems.Add(fileName);
                            item.SubItems.Add(fileName);
                        } else {
                            item.SubItems.Add(u.Artist);
                            item.SubItems.Add(u.Title);
                            item.SubItems.Add(u.Album);
                        }

                        MyItem myitem = new MyItem(item, filePath);
                        FilesList.Add(myitem);
                        this.Invoke(new AddItemToList(this.doAddItemToList), new object[] { myitem.listItem });
                    }
                    catch (Exception) { }
                }
            }
            listView.ItemCheck += new ItemCheckEventHandler(this.listView_ItemCheck);
            return this.keepParsing;
        }

        private void doAddItemToList(ListViewItem item)
        {
            listView.Items.Add(item);
        }

        private void doUpdateStatusBarText(int check)
        {
            if (this.FilesListForFilter != null)
                this.statusBarText.Text = "Elementi: " + this.FilesListForFilter.Count.ToString() + " - Selezionati: " + check;
            else if (this.FilesList != null)
                this.statusBarText.Text = "Elementi: " + this.FilesList.Count.ToString() + " - Selezionati: " + check;
        }

        private void doUpdateListView()
        {
            this.progressBar.Value = ++this.progressBar.Value;
            if (isVistaOr7())
                this.progressBar.SetTaskbarProgress();
            int percent = (int)(((double)(this.progressBar.Value - this.progressBar.Minimum) / (double)(this.progressBar.Maximum - this.progressBar.Minimum)) * 100);
            this.percentLabel.Text = percent.ToString() + "%";
            /*using (Graphics g = this.progressBar.ProgressBar.CreateGraphics())
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.DrawString(percent.ToString() + "%",
                             SystemFonts.DefaultFont,
                             Brushes.Black,
                             new PointF(this.progressBar.Width / 2 - (g.MeasureString(percent.ToString() + "%",SystemFonts.DefaultFont).Width / 2.0F),
                             this.progressBar.Height / 2 - (g.MeasureString(percent.ToString() + "%",
                             SystemFonts.DefaultFont).Height / 2.0F)));
            }*/
        }

        protected override void WndProc(ref Message message)
        {
            const int WM_PAINT = 0xf;
            switch (message.Msg)
            {
                case WM_PAINT:
                    this.listView.Columns[this.listView.Columns.Count - 1].Width = -2;
                    break;
            }
            base.WndProc(ref message);
        }

        private void estraiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.isRunning = true;
            this.progressBar.Value = 0;
            if (isVistaOr7())
                this.progressBar.SetTaskbarProgress();
            this.keepParsing = Parsing.OK;
            new Thread(new ThreadStart(this.Estrai)).Start();            
        }

        private void Estrai()
        {
            this.Cursor = Cursors.WaitCursor;
            this.textBoxSearch.Enabled = false;

            List<MyItem> FilesListOrTemp = null;          
            FilesListOrTemp = (this.FilesListForFilter != null) ? this.FilesListForFilter : FilesList;
            if (FilesListOrTemp == null) return;

            if (this.isFirstExtract) {
                this.isFirstExtract = false;
                this.progressBar.Maximum--;
            }

            this.sempliceToolStripMenuItem.Enabled = false;
            this.estesaToolStripMenuItem.Enabled = false;

            for (int i = 0; i < FilesListOrTemp.Count; i++)
            {
                if (this.keepParsing == Parsing.STOP)
                    break;
                else if (this.keepParsing == Parsing.CLOSE)
                    return;
                else if (this.keepParsing == Parsing.PAUSE)
                {
                    if(this.isVistaOr7())
                        this.SetTaskbarProgressState(Windows7.DesktopIntegration.Windows7Taskbar.ThumbnailProgressState.Paused);
                    this.Cursor = Cursors.Default;
                    
                    while (this.keepParsing == Parsing.PAUSE) {
                        Thread.Sleep(50);
                        continue;
                    }

                    if (this.keepParsing == Parsing.CLOSE)
                        return;
                    else if (this.keepParsing == Parsing.STOP)
                        break;

                    this.Cursor = Cursors.WaitCursor;
                    if (this.isVistaOr7())
                        this.SetTaskbarProgressState(Windows7.DesktopIntegration.Windows7Taskbar.ThumbnailProgressState.Indeterminate);
                }

                MyItem item = FilesListOrTemp.ElementAt(i);
                if (item.listItem.Checked)
                {
                    try
                    {
                        UltraID3 u = new UltraID3();
                        u.Read(item.filePath);
                        string fileName;
                        if (u.Artist == String.Empty && u.Title == String.Empty && u.Album == String.Empty)
                            fileName = Path.GetFileName(item.filePath);
                        else
                            fileName = u.Artist + " - " + u.Title + ".mp3";
                        fileName = Fix(fileName);
                        if (this.ExtractMode == Mode.SIMPLE)
                            File.Copy(item.filePath, this.outputPath + fileName, true);
                        else
                            WriteFileExtended(item.filePath, this.outputPath, u.Album, u.Artist, u.Title);
                        this.Invoke(new UpdateProgressBarDelegate(this.doUpdateListView));
                    }
                    catch (Exception)
                    {
                        try {
                            this.Invoke(new UpdateProgressBarDelegate(this.doUpdateListView));
                        }
                        catch (Exception) { }
                    }
                }
            }
            this.isRunning = false;
            this.sempliceToolStripMenuItem.Enabled = true;
            this.estesaToolStripMenuItem.Enabled = true;
            SystemSounds.Beep.Play();
            this.Cursor = Cursors.Default;
            this.textBoxSearch.Enabled = true;
        }

        private void WriteFileExtended(string from, string to, string album, string artist, string title)
        {
            string destPath = to + "\\" + album + "\\" + artist + "\\";
            Directory.CreateDirectory(destPath);
            File.Copy(from, destPath + artist + " - " + title + ".mp3", true);
        }

        private string Fix(string fileName)
        {
            string ret = fileName;
            ret = fileName.Replace("\\", "");
            ret = ret.Replace("/", "");
            ret = ret.Replace(":", "");
            ret = ret.Replace("*", "");
            ret = ret.Replace("?", "");
            ret = ret.Replace("\"", "");
            ret = ret.Replace("<", "");
            ret = ret.Replace(">", "");
            ret = ret.Replace("|", "");
            return ret;
        }

        private void textBoxSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (this.textBoxSearch.Text == "Cerca...\r" && (int)e.KeyChar != 8)
            {
                this.textBoxSearch.Text = e.KeyChar.ToString();
                this.textBoxSearch.SelectionStart = this.textBoxSearch.Text.Length;
                this.textBoxSearch.SelectionLength = 0;
                this.textBoxSearch.ForeColor = Color.Black;
                e.Handled = true;
            }
        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            if (this.textBoxSearch.Text == String.Empty) {
                this.FilesListForFilter = null;
                this.textBoxSearch.Text = "Cerca...\r";
                this.textBoxSearch.ForeColor = Color.Gray;
            }

            this.progressBar.Value = 0;
            if (isVistaOr7())
                this.progressBar.SetTaskbarProgress();
            this.percentLabel.Text = "0%";
            this.isFirstExtract = true;
            this.listView.Clear();
            createColumns();
            ListViewItem newitem;

            List<MyItem> FilesListOrTemp;
            List<MyItem> newFilesListForFilter = new List<MyItem>();

            if (this.textBoxSearch.Text.Length > this.lastLengthOfFilter) {
                this.lastLengthOfFilter = this.textBoxSearch.Text.Length;
                FilesListOrTemp = (this.FilesListForFilter != null) ? this.FilesListForFilter : FilesList;
            }
            else
                FilesListOrTemp = FilesList;

            if (FilesListOrTemp == null) return;

            this.Cursor = Cursors.WaitCursor;
            foreach (MyItem item in FilesListOrTemp)
            {
                newitem = new ListViewItem();
                newitem.Checked = false;
                UltraID3 u = new UltraID3();
                u.Read(item.filePath);

                string fileName = Path.GetFileName(item.filePath);
                string artista = u.Artist;
                string title = u.Title;
                string album = u.Album;

                if (this.textBoxSearch.Text != "Cerca...\r" && !Matches(artista.ToLower(), title.ToLower(), album.ToLower(), this.textBoxSearch.Text.ToLower()))
                    continue;

                newitem.SubItems.Add(fileName);
                newitem.SubItems.Add(artista);
                newitem.SubItems.Add(title);
                newitem.SubItems.Add(album);
                listView.Items.Add(newitem);
                newFilesListForFilter.Add(new MyItem(newitem, item.filePath));
            }
            this.Cursor = Cursors.Default;
            this.FilesListForFilter = newFilesListForFilter;
            this.progressBar.Maximum = 1;
            this.Invoke(new UpdateStatusBarText(this.doUpdateStatusBarText), new object[] { 0 });
        }

        private bool Matches(string artista, string title, string album, string text)
        {
            return (artista.Contains(text) || title.Contains(text) || album.Contains(text));
        }

        private void salvaInToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.FolderBrowserDialog dialog = new System.Windows.Forms.FolderBrowserDialog();
            dialog.Description = "Seleziona la cartella in cui salvare gli mp3:";
            dialog.RootFolder = Environment.SpecialFolder.Desktop;
            if (dialog.ShowDialog() == DialogResult.OK && dialog.SelectedPath != String.Empty) {
                this.outputPath = dialog.SelectedPath + "\\";
                this.estraiStatusBar.Text = this.outputPath;
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.isRunning)
                this.keepParsing = Parsing.CLOSE;
        }

        private void selezionaTuttoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.FilesListForFilter != null) {
                this.Cursor = Cursors.WaitCursor;
                foreach (MyItem item in this.FilesListForFilter)
                    item.listItem.Checked = true;
                this.progressBar.Maximum = this.FilesListForFilter.Count;
                this.Invoke(new UpdateStatusBarText(this.doUpdateStatusBarText), new object[] { this.progressBar.Maximum });
                this.Cursor = Cursors.Default;
            } else  if (this.FilesList != null) {
                this.Cursor = Cursors.WaitCursor;
                foreach (MyItem item in this.FilesList)
                    item.listItem.Checked = true;
                this.progressBar.Maximum = this.FilesList.Count;
                this.Invoke(new UpdateStatusBarText(this.doUpdateStatusBarText), new object[] { this.progressBar.Maximum });
                this.Cursor = Cursors.Default;
            }
        }

        private void deselezionaTuttoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.FilesListForFilter != null) {
                this.Cursor = Cursors.WaitCursor;
                foreach (MyItem item in this.FilesListForFilter)
                    item.listItem.Checked = false;
                this.progressBar.Maximum = 1;
                this.Invoke(new UpdateStatusBarText(this.doUpdateStatusBarText));
                this.Cursor = Cursors.Default;
            } else if (this.FilesList != null) {
                this.Cursor = Cursors.WaitCursor;
                foreach (MyItem item in this.FilesList)
                    item.listItem.Checked = false;
                this.progressBar.Maximum = 1;
                this.Invoke(new UpdateStatusBarText(this.doUpdateStatusBarText), new object[] { 0 });
                this.Cursor = Cursors.Default;
            }
        }

        private void invertiSelezioneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listView.ItemCheck -= new ItemCheckEventHandler(this.listView_ItemCheck);
            if (this.FilesListForFilter != null) {
                int nChecked = 0;
                foreach (MyItem item in this.FilesListForFilter) {
                    if (!item.listItem.Checked) nChecked++;
                    item.listItem.Checked = !item.listItem.Checked;
                }
                this.progressBar.Maximum = nChecked;
                this.Invoke(new UpdateStatusBarText(this.doUpdateStatusBarText), new object[] { nChecked });
            } else if (this.FilesList != null) {
                int nChecked = 0;
                foreach (MyItem item in this.FilesList) {
                    if (!item.listItem.Checked) nChecked++;
                    item.listItem.Checked = !item.listItem.Checked;
                }
                this.progressBar.Maximum = nChecked;
                this.Invoke(new UpdateStatusBarText(this.doUpdateStatusBarText), new object[] { nChecked });
            }
            listView.ItemCheck += new ItemCheckEventHandler(this.listView_ItemCheck);
        }

        void listView_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            this.progressBar.Value = 0;
            if (isVistaOr7())
                this.progressBar.SetTaskbarProgress();
            this.percentLabel.Text = "0%";

            if (e.CurrentValue == CheckState.Unchecked)
                this.progressBar.Maximum++;
            else
                this.progressBar.Maximum--;
            
            if (this.isFirstExtract)
                this.Invoke(new UpdateStatusBarText(this.doUpdateStatusBarText), new object[] { this.progressBar.Maximum - 1 });
            else
                this.Invoke(new UpdateStatusBarText(this.doUpdateStatusBarText), new object[] { this.progressBar.Maximum });
        }

        private void Form1_SizeChanged(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Maximized)
            {
                int width = (this.ClientSize.Width - 20) / 4;
                for (int i = 1; i < 5; i++)
                    this.listView.Columns[i].Width = width;
            }
        }

        private void listView_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            // Determine if clicked column is already the column that is being sorted.
            if (e.Column == lvwColumnSorter.SortColumn)
            {
                // Reverse the current sort direction for this column.  
                if (lvwColumnSorter.Order == System.Windows.Forms.SortOrder.Ascending)
                    lvwColumnSorter.Order = System.Windows.Forms.SortOrder.Descending;
                else
                    lvwColumnSorter.Order = System.Windows.Forms.SortOrder.Ascending;
            }
            else
            {
                // Set the column number that is to be sorted; default to ascending.  
                lvwColumnSorter.SortColumn = e.Column;
                lvwColumnSorter.Order = System.Windows.Forms.SortOrder.Ascending;
            }

            // Perform the sort with these new sort options.  
            this.listView.Sort();  
        }

        private void creditsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CreditsDialog dialog = new CreditsDialog();
            dialog.StartPosition = FormStartPosition.Manual;
            int x = this.Width/2 - dialog.Width/2;
            int y = this.Height / 2 - dialog.Height / 2;
            dialog.Location = this.PointToScreen(new Point(x, y));
            dialog.ShowDialog(this);
        }

        private void fermaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.isRunning) {
                this.keepParsing = Parsing.STOP;
                this.pausaToolStripMenuItem.Text = "Pausa";
            }
        }

        private void pausaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.isRunning)
            {
                if (this.keepParsing == Parsing.OK)
                {
                    this.keepParsing = Parsing.PAUSE;
                    this.pausaToolStripMenuItem.Text = "Riprendi";
                }
                else if (this.keepParsing == Parsing.PAUSE)
                {
                    this.keepParsing = Parsing.OK;
                    this.pausaToolStripMenuItem.Text = "Pausa";
                }
            }
        }

        private void textBoxSearch_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Middle)
                this.textBoxSearch.Text = String.Empty;
        }

        private void sempliceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.sempliceToolStripMenuItem.Checked = true;
            this.estesaToolStripMenuItem.Checked = false;
            this.ExtractMode = Mode.SIMPLE;
        }

        private void estesaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.sempliceToolStripMenuItem.Checked = false;
            this.estesaToolStripMenuItem.Checked = true;
            this.ExtractMode = Mode.EXTENDED;
        }
    }
}
