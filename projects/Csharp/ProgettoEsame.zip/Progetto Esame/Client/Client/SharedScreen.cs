﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Client
{
    public partial class SharedScreen : Form
    {
        private Thread thread;

        public SharedScreen()
        {
            InitializeComponent();

            this.thread = new Thread(new ThreadStart(this.doShareScreen));
            this.Show();
            this.thread.Start();
        }


        private void doShareScreen()
        {

                    try
                    {
                        while (true)
                        {
                            lock (VariabiliGlobali.Globals.screen_mutex)
                            {
                                this.pictureBox.Image = (Image)VariabiliGlobali.Globals.screen;
                            }
                        }
                    }
                    catch (Exception) { }

            VariabiliGlobali.Globals.screen = null;
        }


        private void SharedScreen_Load(object sender, EventArgs e)
        {

        }
    }
}
