﻿using System.Net;
using System.Drawing;
using Client;

namespace VariabiliGlobali
{
    public class Globals
    {
        public static string Password = string.Empty;
        public static string Nickname = string.Empty;
        public static IPAddress ipAddress;
        public static ushort Porta = 0;
        public static MainForm main = null;
        public static string ClipboardPath = string.Empty;
        public static bool RecursiveClipboardShare = false;
        public static object screen_mutex = new object();
        public static object socket_mutex = new object();
        public static Image screen = null;
        public static Size imageSize = new Size(-1, -1);
        public static int receiveScreenDelay = 50;
        public static bool configurationOK = false;

        public static Size Size_old = new Size(-1, -1);
    }
}
