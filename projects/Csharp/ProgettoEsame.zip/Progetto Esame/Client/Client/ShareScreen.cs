﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using Win32Api;

namespace Client
{
    public delegate void UpdateScreenHandler(object sender, EventArgs e);
    public delegate void StopSharedScreenHandler(object sender, EventArgs e);
    
    public partial class ShareScreen : Form
    {
        public class UpdateClientSizeArgs : EventArgs
        {
            private Size _clientSize;

            public UpdateClientSizeArgs(Size s)
            {
                _clientSize = s;
            }

            public Size ClientSize
            {
                get { return _clientSize; }
            }
        }
        
        private Thread thread;
        private delegate void UpdateClientSizeHandler(object sender, UpdateClientSizeArgs e);
        private delegate void UpdateClientSize(Size s);
        private delegate void AbleDisableScreenSharingHandler(object sender, EventArgs e);
        private delegate void AbleDisableScreenSharing();
        public delegate void StopSharedScreen();
        private event UpdateClientSizeHandler UpdateSize;
        private event AbleDisableScreenSharingHandler AbleDisableScreenSharingEvent;
        private bool captureEnabled;
        private bool keepSharing;
        private AutoResetEvent wait;
        private IntPtr formHandle;
        private const int CP_NOCLOSE_BUTTON = 0x200;

        public ShareScreen(bool firstTimeIsCaptureEnabled, AutoResetEvent wait)
        {
            InitializeComponent();
            this.wait = wait;
            this.keepSharing = true;
            this.formHandle = this.Handle;
            this.MaximizeBox = false;
            ToolTip toolTip = new ToolTip();
            toolTip.AutoPopDelay = 3000;
            toolTip.InitialDelay = 1000;
            toolTip.ReshowDelay = 100;
            toolTip.ShowAlways = false;
            toolTip.SetToolTip(this.pictureBox, "Doppio click per tornare alle dimensioni originali");
            this.captureEnabled = firstTimeIsCaptureEnabled;
            this.UpdateSize += new UpdateClientSizeHandler(this.UpdateClientSizeFunction);
            this.AbleDisableScreenSharingEvent += new AbleDisableScreenSharingHandler(this.AbleDisableScreenSharingFunction);
            this.thread = new Thread(new ThreadStart(this.doShareScreen));
            this.Show();
            this.thread.Start();
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams myCp = base.CreateParams;
                myCp.ClassStyle = myCp.ClassStyle | CP_NOCLOSE_BUTTON;
                return myCp;
            }
        }

        public void AbleDisableScreenSharingMethod()
        {
            AbleDisableScreenSharingEvent(this, null);
        }

        private void AbleDisableScreenSharingFunction(object sender, EventArgs e)
        {
            this.Invoke(new AbleDisableScreenSharing(this.doAbleDisableScreenSharing), null);
        }

        private void doAbleDisableScreenSharing()
        {
            this.captureEnabled = !this.captureEnabled;
        }

        private void UpdateClientSizeFunction(object sender, UpdateClientSizeArgs arg)
        {
            this.Invoke(new UpdateClientSize(this.doUpdateClientSize), new object[] { arg.ClientSize });
        }

        private void doUpdateClientSize(Size newsize)
        {
            this.ClientSize = newsize;
        }

        private void doShareScreen()
        {
            bool firstTime = true;
            while (this.keepSharing)
            {
                if (!this.captureEnabled)
                {
                    Pen pen = new Pen(Color.Red, 5);
                    using (Graphics g = this.pictureBox.CreateGraphics())
                    {
                        try
                        {
                            g.DrawRectangle(new Pen(Color.Red, 10), 0, 0, this.pictureBox.Size.Width, this.pictureBox.Size.Height);
                            g.DrawLine(pen, 0, 0, this.pictureBox.Size.Width, this.pictureBox.Size.Height);
                            g.DrawLine(pen, this.pictureBox.Size.Width, 0, 0, this.pictureBox.Size.Height);
                        }
                        catch (Exception) { }
                    }
                    continue;
                }
                
                lock (VariabiliGlobali.Globals.screen_mutex)
                {
                    if (VariabiliGlobali.Globals.screen != null)
                    {
                        if (firstTime)
                        {
                            firstTime = false;
                            UpdateSize(this, new UpdateClientSizeArgs(VariabiliGlobali.Globals.screen.Size));
                        }
                        try
                        {
                            using (Graphics g = this.pictureBox.CreateGraphics())
                            {
                                g.DrawImage((Image)VariabiliGlobali.Globals.screen.Clone(), 0, 0, this.pictureBox.Size.Width, this.pictureBox.Size.Height);
                            }
                        }
                        catch (Exception) { }
                    }
                }
                Thread.Sleep(VariabiliGlobali.Globals.receiveScreenDelay);
            }
            this.UpdateSize -= new UpdateClientSizeHandler(this.UpdateClientSizeFunction);
            this.AbleDisableScreenSharingEvent -= new AbleDisableScreenSharingHandler(this.AbleDisableScreenSharingFunction);
            this.wait.Set();
            Win32.SendMessage(this.formHandle, Win32.WM_CLOSE, (IntPtr)0, (IntPtr)0);
        }

        public void StopSharingScreen(object sender, EventArgs e)
        {
            if (this.InvokeRequired)
            {
                try {
                    this.Invoke(new StopSharedScreen(this.doStopSharing), null);
                } catch (Exception) { }
            }
            else
            {
                this.keepSharing = false;
                this.Close();
            }
        }

        private void doStopSharing()
        {
            this.keepSharing = false;
            this.Close();
        }

        private void pictureBox_DoubleClick(object sender, EventArgs e)
        {
            if (VariabiliGlobali.Globals.screen != null)
                UpdateSize(this, new UpdateClientSizeArgs(VariabiliGlobali.Globals.imageSize));
        }
    }
}
