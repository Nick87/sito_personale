﻿using Win32Api;

namespace Client
{
    partial class MainForm
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            Win32.ChangeClipboardChain(this.Handle, nextClipboardViewer);   
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.Impostazioni = new System.Windows.Forms.ToolStripDropDownButton();
            this.impostazioniToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.condivisioneClipboardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.onToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.offToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.esciToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnConnettiDisconnetti = new System.Windows.Forms.ToolStripButton();
            this.MyMessageBox = new System.Windows.Forms.TextBox();
            this.btnInvia = new System.Windows.Forms.Button();
            this.LogBox = new System.Windows.Forms.RichTextBox();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Impostazioni,
            this.btnConnettiDisconnetti});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(381, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // Impostazioni
            // 
            this.Impostazioni.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Impostazioni.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.impostazioniToolStripMenuItem,
            this.condivisioneClipboardToolStripMenuItem,
            this.esciToolStripMenuItem});
            this.Impostazioni.Image = ((System.Drawing.Image)(resources.GetObject("Impostazioni.Image")));
            this.Impostazioni.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Impostazioni.Name = "Impostazioni";
            this.Impostazioni.Size = new System.Drawing.Size(29, 22);
            this.Impostazioni.Text = "Impostazioni";
            // 
            // impostazioniToolStripMenuItem
            // 
            this.impostazioniToolStripMenuItem.Name = "impostazioniToolStripMenuItem";
            this.impostazioniToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.impostazioniToolStripMenuItem.Text = "Impostazioni";
            this.impostazioniToolStripMenuItem.Click += new System.EventHandler(this.ShowSettingsDialog);
            // 
            // condivisioneClipboardToolStripMenuItem
            // 
            this.condivisioneClipboardToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.onToolStripMenuItem,
            this.offToolStripMenuItem});
            this.condivisioneClipboardToolStripMenuItem.Name = "condivisioneClipboardToolStripMenuItem";
            this.condivisioneClipboardToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.condivisioneClipboardToolStripMenuItem.Text = "Condivisione clipboard";
            // 
            // onToolStripMenuItem
            // 
            this.onToolStripMenuItem.CheckOnClick = true;
            this.onToolStripMenuItem.Name = "onToolStripMenuItem";
            this.onToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Alt)
                        | System.Windows.Forms.Keys.Z)));
            this.onToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.onToolStripMenuItem.Text = "On";
            this.onToolStripMenuItem.ToolTipText = "Condividi la clipboard ogni qualvolta il suo contenuto cambia (Rtf, Ascii, Bitmap" +
                ")";
            this.onToolStripMenuItem.Click += new System.EventHandler(this.onShareClipboardOn);
            // 
            // offToolStripMenuItem
            // 
            this.offToolStripMenuItem.Checked = true;
            this.offToolStripMenuItem.CheckOnClick = true;
            this.offToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.offToolStripMenuItem.Name = "offToolStripMenuItem";
            this.offToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Alt)
                        | System.Windows.Forms.Keys.X)));
            this.offToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.offToolStripMenuItem.Text = "Off";
            this.offToolStripMenuItem.Click += new System.EventHandler(this.onShareClipboardOff);
            // 
            // esciToolStripMenuItem
            // 
            this.esciToolStripMenuItem.Name = "esciToolStripMenuItem";
            this.esciToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.esciToolStripMenuItem.Text = "Esci";
            this.esciToolStripMenuItem.Click += new System.EventHandler(this.onExit);
            // 
            // btnConnettiDisconnetti
            // 
            this.btnConnettiDisconnetti.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnConnettiDisconnetti.Image = ((System.Drawing.Image)(resources.GetObject("btnConnettiDisconnetti.Image")));
            this.btnConnettiDisconnetti.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnConnettiDisconnetti.Name = "btnConnettiDisconnetti";
            this.btnConnettiDisconnetti.Size = new System.Drawing.Size(23, 22);
            this.btnConnettiDisconnetti.Text = "Connetti";
            this.btnConnettiDisconnetti.Click += new System.EventHandler(this.btnConnettiDisconnetti_Click);
            // 
            // MyMessageBox
            // 
            this.MyMessageBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.MyMessageBox.Location = new System.Drawing.Point(4, 231);
            this.MyMessageBox.Name = "MyMessageBox";
            this.MyMessageBox.Size = new System.Drawing.Size(317, 20);
            this.MyMessageBox.TabIndex = 2;
            this.MyMessageBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MyMessageBox_KeyPress);
            // 
            // btnInvia
            // 
            this.btnInvia.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnInvia.Location = new System.Drawing.Point(323, 229);
            this.btnInvia.Name = "btnInvia";
            this.btnInvia.Size = new System.Drawing.Size(55, 23);
            this.btnInvia.TabIndex = 3;
            this.btnInvia.Text = "Invia";
            this.btnInvia.UseVisualStyleBackColor = true;
            this.btnInvia.Click += new System.EventHandler(this.btnInvia_Click);
            // 
            // LogBox
            // 
            this.LogBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.LogBox.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.LogBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.LogBox.Location = new System.Drawing.Point(4, 23);
            this.LogBox.Name = "LogBox";
            this.LogBox.ReadOnly = true;
            this.LogBox.Size = new System.Drawing.Size(374, 203);
            this.LogBox.TabIndex = 1;
            this.LogBox.Text = "";
            this.LogBox.WordWrap = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(381, 254);
            this.Controls.Add(this.LogBox);
            this.Controls.Add(this.btnInvia);
            this.Controls.Add(this.MyMessageBox);
            this.Controls.Add(this.toolStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(250, 200);
            this.Name = "MainForm";
            this.Text = "Client";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripDropDownButton Impostazioni;
        private System.Windows.Forms.ToolStripMenuItem impostazioniToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem esciToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton btnConnettiDisconnetti;
        private System.Windows.Forms.TextBox MyMessageBox;
        private System.Windows.Forms.Button btnInvia;
        private System.Windows.Forms.ToolStripMenuItem condivisioneClipboardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem onToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem offToolStripMenuItem;
        private System.Windows.Forms.RichTextBox LogBox;
    }
}

