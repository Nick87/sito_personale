﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Client
{
    public partial class PictureFrame : Form
    {
        Image image;
        public PictureFrame(Image img, string username)
        {
            InitializeComponent();
            this.Text = "<CLIPBOARD:" + username + ">";
            this.image = img;
            this.pictureBox.Image = img;
        }

        private void onMouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button != System.Windows.Forms.MouseButtons.Right) return;
            contextMenuStrip.Show(this.PointToScreen(e.Location));
        }

        private void salvaToolStrip_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Bitmap|*.bmp";
            sfd.FilterIndex = 1;

            if (sfd.ShowDialog(this) == DialogResult.OK)
                this.image.Save(sfd.FileName);
        }
    }
}
