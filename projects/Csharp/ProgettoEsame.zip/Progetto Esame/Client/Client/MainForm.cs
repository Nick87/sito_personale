﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;
using ClassLibrary;
using Win32Api;

namespace Client
{
    public partial class MainForm : Form
    {
        private class Arg
        {
            private Image _image;
            private string _username;

            public Arg(Image img, string usr)
            {
                this._image = img;
                this._username = usr;
            }

            public Image image { get { return this._image; } }
            public string username { get { return this._username; } }
        }

        private class CloseConnectionArg : EventArgs
        {
            private string _reason;

            public CloseConnectionArg(string reason)
            {
                _reason = reason;
            }

            public string reason
            {
                get { return _reason; }
            }
        }

        private NetworkStream stream;
        private IFormatter formatter;
        private TcpClient tcpServer;
        private delegate void UpdateLogBox(MyMessage message);
        private AutoResetEvent waitEvent = new AutoResetEvent(false);
        private Thread workerThread;
        private bool Connected;
        private bool isClosing;
        private bool keepSharingClipboard;
        private bool disconnectOnClose;
        private string lastUsername;
        private delegate void CloseConnectionDelegate(string reason);
        private delegate void CloseConnectionEventHandler (object sender, CloseConnectionArg e);
        private event CloseConnectionEventHandler CloseConnectionEvent;
        private event StopSharedScreenHandler StopSharing;
        ShareScreen sharedScreen;
        IntPtr nextClipboardViewer; //Prossima finestra della catena a cui inviare il messaggio

        public MainForm()
        {
            InitializeComponent();
            nextClipboardViewer = (IntPtr)Win32.SetClipboardViewer((int) this.Handle);
            this.MyMessageBox.Enabled = false;
            this.btnInvia.Enabled = false;
            this.Connected = false;
            this.isClosing = false;
            this.disconnectOnClose = false;
            this.keepSharingClipboard = false;
            this.lastUsername = "";
            VariabiliGlobali.Globals.main = this;
        }

        public void changeTitle(string title)
        {
            this.Text = title;
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData.ToString().CompareTo("F4, Alt") == 0)
            {
                this.Close();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {

            if (!this.isClosing)
            {
                if(MessageBox.Show("Vuoi realmente uscire?", "Conferma", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    e.Cancel = true;
                    return;
                }
            }
            if (this.Connected)
            {                
                SendToServer(new AdminTextMessage("<CLIENT CLOSE>", VariabiliGlobali.Globals.Nickname));
                this.disconnectOnClose = true;
                this.waitEvent.WaitOne();
                this.Connected = false;
                this.stream.Close();
                this.tcpServer.Close();
            }
        }

        private void onExit(object sender, EventArgs e)
        {
            if(MessageBox.Show("Vuoi realmente uscire?", "Conferma", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                return;
            if (this.Connected)
            {
                SendToServer(new AdminTextMessage("<CLIENT CLOSE>", VariabiliGlobali.Globals.Nickname));
                this.disconnectOnClose = true;
                this.waitEvent.WaitOne();
                this.Connected = false;
                this.stream.Close();
                this.tcpServer.Close();
            }
            this.isClosing = true;
            this.Close();
        }

        private bool SendToServer(object obj)
        {
            try
            {
                lock (VariabiliGlobali.Globals.socket_mutex)
                {
                    formatter.Serialize(stream, obj);
                }
                stream.Flush();
            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }

        private MyMessage ReceiveFromServer()
        {
            object obj;
            try
            {
                lock (VariabiliGlobali.Globals.socket_mutex)
                {
                    obj = formatter.Deserialize(stream);
                }
                stream.Flush();
                return (MyMessage)obj;
            }
            catch (Exception)
            {
                return null;
            }
        }

        private void ShowSettingsDialog(object sender, EventArgs e)
        {
            new SettingsForm(this.Connected).ShowDialog(this);
        }

        private void btnConnettiDisconnetti_Click(object sender, EventArgs e)
        {
            if (!VariabiliGlobali.Globals.configurationOK) {
                this.LogBox.SelectionFont = new Font("Verdana", 8, FontStyle.Bold);
                this.LogBox.SelectionColor = Color.Red;
                this.LogBox.AppendText("Impossibile avviare la sessione. Controllare le impostazioni.\r\n");
                return;
            }

            if (!this.Connected)
                InitializeConnection();
            else
                SendToServer(new AdminTextMessage("<CLIENT CLOSE>", VariabiliGlobali.Globals.Nickname));
        }

        private void InitializeConnection()
        {
            AdminTextMessage risposta;
            bool isFirstTimeCaptureEnabled;
            this.tcpServer = new TcpClient();
            this.CloseConnectionEvent = new CloseConnectionEventHandler(this.CloseConnection);

            try {
                this.Cursor = Cursors.WaitCursor;
                this.tcpServer.Connect(VariabiliGlobali.Globals.ipAddress, VariabiliGlobali.Globals.Porta);
            } catch (Exception) {
                this.Invoke(new UpdateLogBox(this.UpdateLog), new AdminTextMessage("Server irraggiungibile e/o inesistente. Controllare IP e Porta.", ""));
                tcpServer = null;
                this.Cursor = Cursors.Default;
                return;
            }

            this.Cursor = Cursors.Default;
            this.stream = tcpServer.GetStream();
            this.formatter = new BinaryFormatter();
            SendToServer(new AdminTextMessage(VariabiliGlobali.Globals.Nickname + "|" + SHA512(VariabiliGlobali.Globals.Password), VariabiliGlobali.Globals.Nickname));

            tcpServer.ReceiveTimeout = 500;
            try {
                risposta = (AdminTextMessage) ReceiveFromServer();
            } catch(Exception) {
                this.stream.Close();
                this.stream = null;
                CloseConnectionEvent(this, new CloseConnectionArg("Server irraggiungibile e/o inesistente. Controllare IP e Porta."));
                return;
            }

            if (risposta == null)
            {
                this.stream.Close();
                this.stream = null;
                CloseConnectionEvent(this, new CloseConnectionArg("Server irraggiungibile e/o inesistente. Controllare IP e Porta."));
                return;
            }

            if (risposta.message.StartsWith("0"))
            {
                tcpServer.ReceiveTimeout = 0;
                this.Invoke(new UpdateLogBox(this.UpdateLog), new AdminTextMessage("Connessione al server riuscita.", ""));
                this.btnConnettiDisconnetti.Image = System.Drawing.Image.FromFile("images/stop.png");
                this.btnConnettiDisconnetti.Text = "Disconnetti";
                this.Connected = true;
                this.MyMessageBox.Enabled = true;
                this.btnInvia.Enabled = true;
                isFirstTimeCaptureEnabled = (risposta.message[1] == '1') ? true : false;
                this.sharedScreen = new ShareScreen(isFirstTimeCaptureEnabled, waitEvent);
                this.StopSharing  = new StopSharedScreenHandler(sharedScreen.StopSharingScreen);
                this.workerThread = new Thread(new ThreadStart(ReceiveMessages));
                this.workerThread.Start();
            }
            else
            {
                string Reason = "Connessione al server non riuscita: " + risposta.message.Substring(2, risposta.message.Length - 2);
                this.stream.Close();
                this.stream = null;
                CloseConnectionEvent(this, new CloseConnectionArg(Reason));
                return;
            }
        }

        private string SHA512(string phrase)
        {
            UTF8Encoding encoder = new UTF8Encoding();
            SHA512Managed sha512hasher = new SHA512Managed();
            byte[] hashedDataBytes = sha512hasher.ComputeHash(encoder.GetBytes(phrase));
            StringBuilder output = new StringBuilder("");
            for (int i = 0; i < hashedDataBytes.Length; i++)
                output.Append(hashedDataBytes[i].ToString("x2"));
            return output.ToString();
        }

        private void CloseConnection(object sender, CloseConnectionArg arg)
        {
            this.Invoke(new CloseConnectionDelegate(this.doCloseConnection), new object[] { arg.reason });
        }

        private void doCloseConnection(string reason)
        {
            this.btnConnettiDisconnetti.Image = System.Drawing.Image.FromFile("images/play.png");
            this.btnConnettiDisconnetti.Text = "Connetti";
            this.lastUsername = "";
            this.Connected = false;
            this.Invoke(new UpdateLogBox(this.UpdateLog), new AdminTextMessage(reason, ""));
            this.MyMessageBox.Enabled = false;
            this.btnInvia.Enabled = false;
            if (this.keepSharingClipboard)
            {
                this.onToolStripMenuItem.Checked = true;
                this.offToolStripMenuItem.Checked = false;
            }
            else
            {
                this.offToolStripMenuItem.Checked = true;
                this.onToolStripMenuItem.Checked = false;
            }
        }

        private void ReceiveMessages()
        {
            MyMessage message;

            while (this.Connected)
            {
                if ((message = ReceiveFromServer()) == null)
                {
                    string reason = "Il server ha chiuso la connessione o ci sono stati problemi nella ricezione.";
                    CloseConnectionEvent(this, new CloseConnectionArg(reason));
                    StopSharing(this, null);
                    waitEvent.WaitOne();
                    this.Connected = false;
                    break;
                }
                switch (message.type)
                {
                    case TYPE.CLIENT_MESSAGE:
                        this.Invoke(new UpdateLogBox(this.UpdateLog), (ClientTextMessage)message);
                        break;
                    case TYPE.ADMIN_MESSAGE:
                        {
                            AdminTextMessage admin_message = (AdminTextMessage) message;
                            if (admin_message.message.StartsWith("RefreshRate:"))
                            {
                                string[] str = admin_message.message.Split(':');
                                string refreshRate = str[1].Substring(1, str[1].Length-1);
                                VariabiliGlobali.Globals.receiveScreenDelay = Int32.Parse(refreshRate);
                                break;
                            }
                            switch(admin_message.message)
                            {
                                case "<SERVER CLOSE>":
                                    {
                                        SendToServer(new AdminTextMessage("<SERVER CLOSE OK>", VariabiliGlobali.Globals.Nickname));
                                        CloseConnectionEvent(this, new CloseConnectionArg("Il server ha chiuso la connessione."));
                                        StopSharing(this, null);
                                        waitEvent.WaitOne();
                                        this.Connected = false;
                                        return;
                                    }
                                case "<CLIENT CLOSE OK>":
                                    {
                                        if (this.disconnectOnClose)
                                        {
                                            this.waitEvent.Set();
                                            this.Connected = false;
                                        }
                                        else
                                        {
                                            StopSharing(this, null);
                                            waitEvent.WaitOne();
                                            CloseConnectionEvent(this, new CloseConnectionArg("Disconnessione su richiesta dell'utente."));
                                            this.Connected = false;
                                        }
                                        return;
                                    }
                                case "<PAUSE>":
                                case "<PLAY>":
                                    sharedScreen.AbleDisableScreenSharingMethod();
                                    break;
                                case "OK":
                                    break;
                                default:
                                    this.Invoke(new UpdateLogBox(this.UpdateLog), admin_message);
                                    break;
                            }
                        }
                        break;
                    case TYPE.CLIP_TEXT:
                        {
                            ClipboardText cliptext = (ClipboardText)message;
                            AdminTextMessage msg = new AdminTextMessage("<CLIPBOARD:" + cliptext.from + "> Testo: \"" + cliptext.text + "\"", "");
                            this.Invoke(new UpdateLogBox(this.UpdateLog), msg);
                        }
                        break;
                    case TYPE.CLIP_FILE:
                        {
                            ClipboardFile clipfile = (ClipboardFile) message;
                            AdminTextMessage msg = null;
                            if (Directory.Exists(VariabiliGlobali.Globals.ClipboardPath)) {
                                File.WriteAllBytes(VariabiliGlobali.Globals.ClipboardPath + clipfile.filename, clipfile.fileData);
                                msg = new AdminTextMessage("<CLIPBOARD:" + clipfile.from + "> File \"" + clipfile.filename + "\"", "");
                            } else {
                                msg = new AdminTextMessage("Impossibile salvare file. Percorso di destinazione inesistente.", "");
                            }
                            this.Invoke(new UpdateLogBox(this.UpdateLog), msg);
                        }
                        break;
                    case TYPE.CLIP_IMAGE:
                        {
                            ClipboardImage clipImage = (ClipboardImage) message;
                            Thread thread = new Thread(new ParameterizedThreadStart(this.showPictureFrame));
                            thread.SetApartmentState(ApartmentState.STA); //Necessario altrimenti dà eccezione
                            thread.Start((object)new Arg(clipImage.image, clipImage.from));
                        }
                        break;
                    case TYPE.SCREEN_IMAGE:
                        {
                            ScreenImage screen = (ScreenImage)message;
                            VariabiliGlobali.Globals.screen = (Image)screen.image.Clone();
                            VariabiliGlobali.Globals.Size_old = new Size(VariabiliGlobali.Globals.screen.Width / 3, VariabiliGlobali.Globals.screen.Height / 3);
                        }
                        break;
                    case TYPE.SHARED_SCREEN:
                        {
                            MySharedScreen screen = (MySharedScreen)message;
                            VariabiliGlobali.Globals.imageSize.Width = screen.size.Width*3;
                            VariabiliGlobali.Globals.imageSize.Height = screen.size.Height*3;
                            int x, y, w, h;

                            lock (VariabiliGlobali.Globals.screen_mutex)
                            {
                               if (VariabiliGlobali.Globals.screen != null && screen.size==VariabiliGlobali.Globals.Size_old)
                                {
                                    w = screen.size.Width;
                                    h = screen.size.Height;
                                    using (Graphics g_screen = Graphics.FromImage(VariabiliGlobali.Globals.screen))
                                    {
                                        for (int i = 0; i < 3; i++)
                                        {
                                            y = i * h;
                                            for (int j = 0; j < 3; j++)
                                            {
                                                if (screen.rect[i, j].Size == new Size(-1, -1)) continue;
                                                x = j * w;
                                                g_screen.DrawImage(screen.image[i, j], x, y, w, h);
                                            }
                                        }
                                    }
                                    VariabiliGlobali.Globals.Size_old = new Size(w, h);
                                }
                                else {
                                    w = screen.size.Width;
                                    h = screen.size.Height;
                
                                    Bitmap bmp = new Bitmap(w * 3, h * 3);
                                    using (Graphics g_screen = Graphics.FromImage(bmp))
                                    {

                                        for (int l = 0; l < 3; l++)
                                        {
                                            y = l * h;
                                            for (int k = 0; k < 3; k++)
                                            {
                                                x = k * w;
                                                try
                                                {
                                                    g_screen.DrawImage(screen.image[l, k], x, y, w, h);
                                                }
                                                catch (Exception) { }
                                            }
                                        }
                                    }
                                    VariabiliGlobali.Globals.screen = (Image)bmp.Clone();
                                    VariabiliGlobali.Globals.Size_old = new Size(w, h);
                                }
                            }
                        }
                        break;
                }
            }
        }

        private void showPictureFrame(object obj)
        {
            Arg arg = (Arg)obj;
            new PictureFrame(arg.image, arg.username).ShowDialog();
        }

        private void SendMessage()
        {   
            if (this.MyMessageBox.Text.Trim().Length == 0) return;

            ClientTextMessage message = new ClientTextMessage(this.MyMessageBox.Text.Trim(), VariabiliGlobali.Globals.Nickname);
            SendToServer(message);
            this.Invoke(new UpdateLogBox(this.UpdateLog), message);
            this.MyMessageBox.Text = "";
        }

        private void UpdateLog(MyMessage msg)
        {
            if (msg is ClientTextMessage)
            {
                ClientTextMessage message = (ClientTextMessage) msg;
                if (this.lastUsername != message.from)
                {
                    this.lastUsername = message.from;
                    this.LogBox.SelectionFont = new Font("Verdana", 8, FontStyle.Bold);
                    this.LogBox.SelectionColor = Color.Blue;
                    this.LogBox.AppendText(message.from + " scrive: (" + DateTime.Now.ToShortTimeString() + ")\n");
                }

                this.LogBox.SelectionFont = new Font("Verdana", 8, FontStyle.Regular);
                this.LogBox.SelectionColor = Color.Black;
                this.LogBox.AppendText(" - " + message.message + "\n");
                this.LogBox.ScrollToCaret();
            }
            else if(msg is AdminTextMessage)
            {
                AdminTextMessage message = (AdminTextMessage)msg;
                this.LogBox.SelectionFont = new Font("Verdana", 8, FontStyle.Bold);
                this.LogBox.SelectionColor = Color.Red;
                if (message.from != null && message.from != String.Empty)
                    this.LogBox.AppendText(message.from + ": ");
                this.LogBox.AppendText(message.message + "\n");
                this.LogBox.ScrollToCaret();
            }
        }

        private void MyMessageBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char) Keys.Enter)
                SendMessage();
        }

        private void btnInvia_Click(object sender, EventArgs e)
        {
            SendMessage();
        }

        #region :::: Gestione Clipboard ::::

        protected override void WndProc(ref Message m)
        {
            const int WM_DRAWCLIPBOARD = 0x308;
            const int WM_CHANGECBCHAIN = 0x030D;

            switch (m.Msg)
            {
                case WM_DRAWCLIPBOARD:
                    if (!this.keepSharingClipboard || !this.Connected || stream == null)
                    {
                        Win32.SendMessage(nextClipboardViewer, m.Msg, m.WParam, m.LParam);
                        return;
                    }
                    ShareClipboardData();
                    Win32.SendMessage(nextClipboardViewer, m.Msg, m.WParam, m.LParam);
                    break;
                case WM_CHANGECBCHAIN:
                    if (m.WParam == nextClipboardViewer)
                        nextClipboardViewer = m.LParam;
                    else
                        Win32.SendMessage(nextClipboardViewer, m.Msg, m.WParam, m.LParam);
                    break;
                default:
                    base.WndProc(ref m);
                    break;
            }
        }

        private void ShareClipboardData()
        {
            IDataObject iData = new DataObject();
            try
            {
                iData = Clipboard.GetDataObject();
            }
            catch (Exception)
            {
                return;
            }

            if (iData.GetDataPresent(DataFormats.Rtf))
            {
                RichTextBox rtb = new RichTextBox();
                rtb.Rtf = iData.GetData(DataFormats.Rtf).ToString();
                SendToServer(new ClipboardText(rtb.Text, VariabiliGlobali.Globals.Nickname));
            }
            else if (iData.GetDataPresent(DataFormats.Text))
            {
                SendToServer(new ClipboardText(iData.GetData(DataFormats.Text).ToString(), VariabiliGlobali.Globals.Nickname));
            }
            else if (iData.GetDataPresent(DataFormats.Bitmap))
            {                
                SendToServer(new ClipboardImage((Image)iData.GetData(DataFormats.Bitmap), VariabiliGlobali.Globals.Nickname));
            }
            else if (iData.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = (string[])iData.GetData(DataFormats.FileDrop);
                if (files.Length == 1 && (files[0].EndsWith(".bmp") || files[0].EndsWith(".jpg") || files[0].EndsWith(".jpeg")))
                {
                    byte[] bmpBytes = File.ReadAllBytes(files[0]);
                    MemoryStream ms = new MemoryStream(bmpBytes);
                    Image image = Image.FromStream(ms);
                    SendToServer(new ClipboardImage(image, VariabiliGlobali.Globals.Nickname));
                }
                else
                    new Thread(new ParameterizedThreadStart(this.doShare)).Start((string[])iData.GetData(DataFormats.FileDrop));
            }         
        }

        private void doShare(object dirs_or_files)
        {
            foreach (string file in (string[])dirs_or_files)
            {
                if (Directory.Exists(file))
                {
                    RecursiveShare(file);
                    continue;
                }                
                SendToServer(new ClipboardFile(File.ReadAllBytes(file), Path.GetFileName(file), VariabiliGlobali.Globals.Nickname));
            }
        }

        private void RecursiveShare(string path)
        {
            if (VariabiliGlobali.Globals.RecursiveClipboardShare)
            {
                DirectoryInfo root = new DirectoryInfo(path);
                DirectoryInfo[] dirs = root.GetDirectories();
                foreach (DirectoryInfo dir in dirs)
                    RecursiveShare(path + "\\" + dir.Name);
            }

            foreach (string fileName in Directory.GetFiles(path))
                SendToServer(new ClipboardFile(File.ReadAllBytes(fileName), Path.GetFileName(fileName), VariabiliGlobali.Globals.Nickname));
        }

        private void onDragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop, false) == true)
                e.Effect = DragDropEffects.All;
        }

        private void onDragDrop(object obj, DragEventArgs e)
        {
            if (!this.keepSharingClipboard || !this.Connected || stream == null) return;
            new Thread(new ParameterizedThreadStart(this.doShare)).Start((string[])e.Data.GetData(DataFormats.FileDrop));
        }

        private void onShareClipboardOn(object sender, EventArgs e)
        {
            if (this.keepSharingClipboard)
            {
                if (VariabiliGlobali.Globals.RecursiveClipboardShare)
                    this.Invoke(new UpdateLogBox(this.UpdateLog), new AdminTextMessage("---> Condivisione clipboard già attivata con ricorsione <---", ""));
                else
                    this.Invoke(new UpdateLogBox(this.UpdateLog), new AdminTextMessage("---> Condivisione clipboard già attivata senza ricorsione <---", ""));
                this.onToolStripMenuItem.Checked = true;
                this.offToolStripMenuItem.Checked = false;
                return;
            } 
            if(VariabiliGlobali.Globals.RecursiveClipboardShare)
                this.Invoke(new UpdateLogBox(this.UpdateLog), new AdminTextMessage("---> Condivisione clipboard attivata con ricorsione <---", ""));
            else
                this.Invoke(new UpdateLogBox(this.UpdateLog), new AdminTextMessage("---> Condivisione clipboard attivata senza ricorsione <---", ""));
            this.onToolStripMenuItem.Checked = true;
            this.offToolStripMenuItem.Checked = false;
            this.keepSharingClipboard = true;
        }

        private void onShareClipboardOff(object sender, EventArgs e)
        {
            if (!this.keepSharingClipboard)
            {
                this.Invoke(new UpdateLogBox(this.UpdateLog), new AdminTextMessage("---> Condivisione clipboard già disattivata <---", ""));
                this.onToolStripMenuItem.Checked = false;
                this.offToolStripMenuItem.Checked = true;
                this.keepSharingClipboard = false;
                return;
            }
            this.Invoke(new UpdateLogBox(this.UpdateLog), new AdminTextMessage("---> Condivisione clipboard disattivata <---", ""));
            this.onToolStripMenuItem.Checked = false;
            this.offToolStripMenuItem.Checked = true;
            this.keepSharingClipboard = false;
        }

        #endregion
    }
}
