﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using VariabiliGlobali;

namespace Client
{
    public partial class SettingsForm : Form
    {
        public SettingsForm(bool Connected)
        {
            InitializeComponent();
            this.TopMost = true;
            this.textBoxNickname.Text = VariabiliGlobali.Globals.Nickname;
            this.textBoxPassword.Text = VariabiliGlobali.Globals.Password;
            this.textBoxClipboardPath.Text = VariabiliGlobali.Globals.ClipboardPath;
            if (VariabiliGlobali.Globals.Porta != 0)
                this.textBoxPorta.Text = VariabiliGlobali.Globals.Porta.ToString();
            if (VariabiliGlobali.Globals.RecursiveClipboardShare)
                this.checkBoxRicorsione.Checked = true;
            if (VariabiliGlobali.Globals.ipAddress != null)
            {
                if (VariabiliGlobali.Globals.ipAddress.ToString() == "127.0.0.1")
                    this.textBoxIP.Text = "localhost";
                else
                    this.textBoxIP.Text = VariabiliGlobali.Globals.ipAddress.ToString();
            }

            ToolTip toolTip = new ToolTip();
            toolTip.AutoPopDelay = 3000;
            toolTip.InitialDelay = 1000;
            toolTip.ReshowDelay = 100;
            toolTip.ShowAlways = false;
            toolTip.SetToolTip(this.checkBoxRicorsione, "Attivando l'opzione verranno condivisi anche i file nelle sottocartelle");

            if (Connected)
            {
                this.textBoxIP.Enabled = false;
                this.textBoxPorta.Enabled = false;
                this.textBoxPassword.Enabled = false;
                this.textBoxNickname.Enabled= false;
            }
        }

        private void btnOkOnClick(object sender, EventArgs e)
        {
            if (!ValidateIP()) return;
            if (!ValidatePort()) return;
            if (!ValidatePassword()) return;
            if (!ValidateNickname()) return;
            if (!ValidateClipboardPath()) return;
            VariabiliGlobali.Globals.configurationOK = true;
            this.Close();
        }

        private bool ValidateIP()
        {
            IPAddress temp;
            string ip = this.textBoxIP.Text;

            if (ip == String.Empty)
            {
                MessageBox.Show("Inserire l'indirizzo IP.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }

            if (ip == "localhost")
            {
                VariabiliGlobali.Globals.ipAddress = IPAddress.Parse("127.0.0.1");
                return true;
            }

            if (ip.Split('.').Length != 4)
            {
                MessageBox.Show("Inserire un indirizzo IP valido.", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }

            try
            {
                temp = IPAddress.Parse(ip);
            }
            catch
            {
                MessageBox.Show("Inserire un indirizzo IP valido.", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }

            VariabiliGlobali.Globals.ipAddress = temp;
            return true;
        }

        private bool ValidateNickname()
        {
            if (this.textBoxNickname.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Inserire un nickname.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }
            if(this.textBoxNickname.Text.Contains('|'))
            {
                MessageBox.Show("Il nickname non può avere il carattere '|'.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }
            if (this.textBoxNickname.Text.ToUpper().Trim() == "SERVER")
            {
                MessageBox.Show("Il nickname '" + this.textBoxNickname.Text.Trim() + "' non è ammesso.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }
            VariabiliGlobali.Globals.Nickname = this.textBoxNickname.Text.Trim();
            VariabiliGlobali.Globals.main.Text = "Client - " + VariabiliGlobali.Globals.Nickname;
            return true;
        }

        private bool ValidatePort()
        {
            int val;
            if (this.textBoxPorta.Text == String.Empty)
            {
                MessageBox.Show("Inserire il numero di porta.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }
            try
            {
                val = int.Parse(this.textBoxPorta.Text);
            }
            catch
            {
                MessageBox.Show("Inserire un numero di porta valido.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }
            if (val <= 1024 || val > 65535)
            {
                MessageBox.Show("Il numero di porta deve essere compreso tra 1025 e 65535.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }
            VariabiliGlobali.Globals.Porta = (ushort)val;
            return true;
        }

        private bool ValidatePassword()
        {
            if (this.textBoxPassword.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Inserire una password.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }
            if(this.textBoxPassword.Text.Contains('|'))
            {
                MessageBox.Show("La password non può avere il carattere '|'.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }
            VariabiliGlobali.Globals.Password = this.textBoxPassword.Text;
            return true;
        }

        private bool ValidateClipboardPath()
        {
            if (this.textBoxClipboardPath.Text == String.Empty)
            {
                MessageBox.Show("Scegliere una cartella in cui salvare la clipboard.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }
            VariabiliGlobali.Globals.ClipboardPath = this.textBoxClipboardPath.Text;
            return true;
        }

        private void onKeyDown(object sender, KeyEventArgs e)
        {
            e.SuppressKeyPress = true;
        }

        private void btnSfogliaClick(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "Seleziona la cartella in cui salvare la clipboard:";
            dialog.RootFolder = Environment.SpecialFolder.Desktop;
            if (dialog.ShowDialog() == DialogResult.OK && dialog.SelectedPath != String.Empty)
                this.textBoxClipboardPath.Text = dialog.SelectedPath + "\\";
        }

        private void onCheckStateChanged(object sender, EventArgs e)
        {
            if (this.checkBoxRicorsione.CheckState == CheckState.Checked)
                VariabiliGlobali.Globals.RecursiveClipboardShare = true;
            else
                VariabiliGlobali.Globals.RecursiveClipboardShare = false;
        }
    }
}
