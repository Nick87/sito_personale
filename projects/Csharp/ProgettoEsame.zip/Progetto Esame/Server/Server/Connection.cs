﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Drawing;
using System.Windows.Forms;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using ClassLibrary;
using Win32Api;
using System.Security.Cryptography;

namespace Server
{
    class Connection
    {
        private TcpClient tcpClient;
        private Thread threadReceiver;
        private NetworkStream stream;
        IFormatter formatter;
        private AutoResetEvent wait;
        private ChatServer server;

        public Connection(ChatServer server, TcpClient client, AutoResetEvent waitEvent)
        {
            this.server = server;
            this.wait = waitEvent;
            this.formatter = new BinaryFormatter();
            tcpClient = client;
            stream = tcpClient.GetStream();
            threadReceiver = new Thread(new ThreadStart(ReceiveMessages));
            threadReceiver.Start();
        }

        public TcpClient client
        {
            get { return tcpClient; }
        }

        private void CloseConnection()
        {
            tcpClient.Close();
            stream.Close();
        }

        private string SHA512(string phrase)
        {
            UTF8Encoding encoder = new UTF8Encoding();
            SHA512Managed sha512hasher = new SHA512Managed();
            byte[] hashedDataBytes = sha512hasher.ComputeHash(encoder.GetBytes(phrase));
            StringBuilder output = new StringBuilder("");
            for (int i = 0; i < hashedDataBytes.Length; i++)
                output.Append(hashedDataBytes[i].ToString("x2"));
            return output.ToString();
        }

        private void ReceiveMessages()
        {
            MyMessage message = ReceiveFromClient();

            string[] credenziali =  ((AdminTextMessage) message).message.Split('|');
            string username = credenziali[0];
            string password = credenziali[1];

            lock (VariabiliGlobali.Globals.mutex)
            {
                if (VariabiliGlobali.Globals.ConnectedClients == VariabiliGlobali.Globals.MaxClients)
                {
                    SendToClient(new AdminTextMessage("1|Numero massimo di client connessi raggiunto (" + VariabiliGlobali.Globals.MaxClients + ").", "Server"));
                    CloseConnection();
                    return;
                }
                if (password != SHA512(VariabiliGlobali.Globals.Settings.Password))
                {
                    SendToClient(new AdminTextMessage("1|Password errata e/o nome utente già esistente.", "Server"));
                    CloseConnection();
                    return;
                }
                if (username != "" && server.Users.Contains(username))
                {
                    SendToClient(new AdminTextMessage("1|Password errata e/o nome utente già esistente.", "Server"));
                    CloseConnection();
                    return;
                }
                VariabiliGlobali.Globals.ConnectedClients++;
            }

            string reply = "0";
            if (!VariabiliGlobali.Globals.captureEnabled)
                reply += "0";
            else
            {
                if (VariabiliGlobali.Globals.isAreaSelected)
                    reply += "1";
                else
                {
                    if (Win32.IsIconic(VariabiliGlobali.Globals.hWnd))
                        reply += "0";
                    else
                        reply += "1";
                }
            }

            SendToClient(new AdminTextMessage(reply, "Server"));
            server.AddUser(tcpClient, username);
            server.UpdateRefreshRate();

            while (true)
            {
                if((message = ReceiveFromClient()) == null)
                {
                    server.RemoveUser(tcpClient); //rimuove utente da hashtables e lista
                    Interlocked.Decrement(ref VariabiliGlobali.Globals.ConnectedClients);
                    CloseConnection();
                    return;
                }

                switch (message.type)
                {
                    case TYPE.ADMIN_MESSAGE:
                        {
                            AdminTextMessage admin_message = (AdminTextMessage) message;
                            switch(admin_message.message)
                            {
                                case "<SERVER CLOSE OK>":
                                    {
                                        //Non rimuovo client da hashtables e lista, verrano svuotate completamente dopo
                                        CloseConnection();
                                        wait.Set();
                                        return;
                                    }
                                case "<CLIENT CLOSE>":
                                    {
                                        SendToClient(new AdminTextMessage("<CLIENT CLOSE OK>", "Server"));
                                        server.RemoveUser(tcpClient); //rimuove utente da hashtables
                                        Interlocked.Decrement(ref VariabiliGlobali.Globals.ConnectedClients);
                                        return;
                                    }
                            }
                        }
                        break;
                    default:
                        server.SendMessage(tcpClient, message);
                        break;
                }
            }
        }

        public bool StopConnection()
        {
            try
            {
                formatter.Serialize(stream, new AdminTextMessage("<SERVER CLOSE>", "Server"));
                stream.Flush();
				return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        private bool SendToClient(object obj)
        {
            try
            {
                lock (VariabiliGlobali.Globals.socket_mutex)
                {
                    formatter.Serialize(stream, obj);
                }
                stream.Flush();                
            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }

        private MyMessage ReceiveFromClient()
        {
            try
            {
                object obj = formatter.Deserialize(stream);
                stream.Flush();
                return (MyMessage)obj;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
