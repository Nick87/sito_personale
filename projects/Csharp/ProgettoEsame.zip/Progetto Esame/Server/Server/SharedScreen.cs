﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Win32Api;

namespace Server
{
    public delegate void StopSharedScreenHandler(object sender, EventArgs e);
    
    public partial class SharedScreen : Form
    {
        public class UpdateClientSizeArgs : EventArgs
        {
            private Size _clientSize;

            public UpdateClientSizeArgs(Size s)
            {
                _clientSize = s;
            }

            public Size ClientSize
            {
                get { return _clientSize; }
            }
        }

        private delegate void SendScreenToAllClients(object sender, EventArgs e);
        private delegate void CloseScreenSharing(object sender, EventArgs e);
        private delegate void UpdateClientSizeHandler(object sender, UpdateClientSizeArgs e);
        private delegate void UpdateClientSize(Size s);       
        private Thread thread;
        private bool keepCapturing;
        private const int CP_NOCLOSE_BUTTON = 0x200;
        public delegate void StopSharedScreen();
        private event UpdateClientSizeHandler UpdateSize;
        private event SendScreenToAllClients SendScreenToAllClientsEvent;
        private event CloseScreenSharing CloseScreenSharingEvent;
        private bool wasIconic;
        private Rectangle last_rect;
        private ChatServer parent;
        private AutoResetEvent wait;
        private IntPtr formHandle;
        private bool StopComesFromParent;
        private bool showSharedScreen;

        public SharedScreen(ChatServer parent, AutoResetEvent wait, bool showSharedScreen)
        {
            InitializeComponent();
            this.parent = parent;
            this.wait = wait;
            this.StopComesFromParent = false;
            this.last_rect = new Rectangle(-1, -1, -1, -1);
            this.MaximizeBox = false;
            this.keepCapturing = true;
            this.wasIconic = false;
            this.formHandle = this.Handle;
            this.showSharedScreen = showSharedScreen;

            if (this.showSharedScreen) {
                ToolTip toolTip = new ToolTip();
                toolTip.AutoPopDelay = 3000;
                toolTip.InitialDelay = 1000;
                toolTip.ReshowDelay = 100;
                toolTip.ShowAlways = false;
                toolTip.SetToolTip(this.pictureBox, "Doppio click per tornare alle dimensioni originali");
            }

            if (VariabiliGlobali.Globals.isAreaSelected) {
                VariabiliGlobali.Globals.screen = new Bitmap(VariabiliGlobali.Globals.rect.Width, VariabiliGlobali.Globals.rect.Height);
                this.ClientSize = new Size(VariabiliGlobali.Globals.rect.Width, VariabiliGlobali.Globals.rect.Height);
            }
            //else
                //this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;

            this.thread = new Thread(new ThreadStart(this.doShareScreen));
            this.UpdateSize += new UpdateClientSizeHandler(this.UpdateClientSizeFunction);
            if (this.showSharedScreen)
                this.Show();
            this.thread.Start();
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams myCp = base.CreateParams;
                myCp.ClassStyle = myCp.ClassStyle | CP_NOCLOSE_BUTTON;
                return myCp;
            }
        }

        private void doShareScreen()
        {
            SolidBrush brush = new SolidBrush(Color.Red);
            Rectangle rect;
            this.SendScreenToAllClientsEvent += new SendScreenToAllClients(this.parent.SendScreenToAllClients);
            this.CloseScreenSharingEvent += new CloseScreenSharing(this.parent.CloseScreenSharing);

            while (this.keepCapturing)
            {
                if (VariabiliGlobali.Globals.captureEnabled)
                {
                    if (this.wasIconic && !Win32.IsIconic(VariabiliGlobali.Globals.hWnd))
                    {
                        this.wasIconic = false;
                        this.parent.AbleDisableScreenSharing(true, true);
                    }

                    try
                    {
                        lock (VariabiliGlobali.Globals.screen_mutex)
                        {
                            if (VariabiliGlobali.Globals.isAreaSelected)
                            {
                                using (Graphics g = Graphics.FromImage(VariabiliGlobali.Globals.screen))
                                {
                                    g.CopyFromScreen(VariabiliGlobali.Globals.rect.X, VariabiliGlobali.Globals.rect.Y, 0, 0, new Size(VariabiliGlobali.Globals.rect.Width, VariabiliGlobali.Globals.rect.Height));
                                    if (VariabiliGlobali.Globals.sendMouse)
                                    {
                                        if (MousePosition.X >= VariabiliGlobali.Globals.rect.X && MousePosition.Y >= VariabiliGlobali.Globals.rect.Y)
                                        {
                                            if (VariabiliGlobali.Globals.mouseTypeToSend == VariabiliGlobali.Globals.MouseType.Icona)
                                            {
                                                int x = 0, y = 0, xCoord = 0, yCoord = 0;
                                                Image image = (Image)CaptureCursor(ref x, ref y);
                                                if (MousePosition.X != x || MousePosition.Y != y)
                                                {
                                                    xCoord = x - VariabiliGlobali.Globals.rect.X;
                                                    yCoord = y - VariabiliGlobali.Globals.rect.Y;
                                                }
                                                else
                                                {
                                                    xCoord = MousePosition.X - VariabiliGlobali.Globals.rect.X;
                                                    yCoord = MousePosition.Y - VariabiliGlobali.Globals.rect.Y;
                                                }

                                                g.DrawImage(image, xCoord, yCoord);
                                            }
                                            else
                                            {
                                                g.FillEllipse(brush, new Rectangle(MousePosition.X - VariabiliGlobali.Globals.rect.X - 4,
                                                                                   MousePosition.Y - VariabiliGlobali.Globals.rect.Y - 4,
                                                                                   8, 8));
                                            }
                                        }
                                    }
                                    if (this.showSharedScreen)
                                        this.pictureBox.Image = (Image)VariabiliGlobali.Globals.screen.Clone();
                                }
                            }
                            else
                            {
                                Graphics g = null;
                                Win32.RECT clientRect = new Win32.RECT();
                                if (!Win32.GetClientRect(VariabiliGlobali.Globals.hWnd, out clientRect)) break;
                                rect = new Rectangle(clientRect.Top, clientRect.Left, clientRect.Right, clientRect.Bottom);

                                StringBuilder Buff = new StringBuilder(256);
                                Win32.GetWindowText(VariabiliGlobali.Globals.hWnd, Buff, 256);
                                if (Buff.ToString() == "") break; //Nel caso la finestra viene chiusa

                                //Se la finestra è ridotta a icona
                                if (Win32.IsIconic(VariabiliGlobali.Globals.hWnd))
                                {
                                    if (this.showSharedScreen)
                                    {
                                        Pen pen = new Pen(Color.Red, 5);
                                        g = this.pictureBox.CreateGraphics();
                                        g.DrawRectangle(new Pen(Color.Red, 10), 0, 0, this.pictureBox.Size.Width, this.pictureBox.Size.Height);
                                        g.DrawLine(pen, 0, 0, this.pictureBox.Size.Width, this.pictureBox.Size.Height);
                                        g.DrawLine(pen, this.pictureBox.Size.Width, 0, 0, this.pictureBox.Size.Height);
                                    }
                                    if (!this.wasIconic)                                    
                                        this.parent.AbleDisableScreenSharing(true, false);
                                    this.wasIconic = true;
                                    
                                    continue;
                                }

                                //Per evitare di allocare troppe bitmap e riempire la memoria alloco bitmap solo quando la dimensione nella finestra cambia
                                if (this.last_rect.Top == -1 || rect.Width != last_rect.Width || rect.Height != last_rect.Height)
                                {
                                    VariabiliGlobali.Globals.screen = null;
                                    VariabiliGlobali.Globals.screen = new Bitmap(rect.Width, rect.Height);
                                    UpdateSize(this, new UpdateClientSizeArgs(new Size(rect.Width, rect.Height)));
                                }
                                last_rect = rect;
                                
                                Image window = CaptureWindow(VariabiliGlobali.Globals.hWnd);
                                if (window != null)
                                {
                                    g = Graphics.FromImage(window);
                                    if (VariabiliGlobali.Globals.sendMouse)
                                    {
                                        Rectangle windowRect = GetWindowRect();
                                        Win32.POINT mouseClient;
                                        mouseClient.X = MousePosition.X;
                                        mouseClient.Y = MousePosition.Y;
                                        Win32.ScreenToClient(VariabiliGlobali.Globals.hWnd, ref mouseClient);
                                        if (mouseClient.X >= 0 && mouseClient.Y >= 0 && mouseClient.X <= clientRect.Right && mouseClient.Y <= clientRect.Bottom)
                                        {
                                            if (VariabiliGlobali.Globals.mouseTypeToSend == VariabiliGlobali.Globals.MouseType.Icona)
                                            {
                                                int x = 0, y = 0, xCoord = 0, yCoord = 0;
                                                Image image = (Image)CaptureCursor(ref x, ref y);
                                                if (MousePosition.X != x || MousePosition.Y != y)
                                                {
                                                    xCoord = mouseClient.X - (MousePosition.X - x);
                                                    yCoord = mouseClient.Y - (MousePosition.Y - y);
                                                }
                                                else
                                                {
                                                    xCoord = mouseClient.X;
                                                    yCoord = mouseClient.Y;
                                                }
                                                g.DrawImage(image, xCoord, yCoord);
                                            }
                                            else
                                                g.FillEllipse(brush, new Rectangle(mouseClient.X - 4, mouseClient.Y - 4, 8, 8));
                                        }
                                    }
                                    g.Dispose();
                                    if (this.showSharedScreen)
                                        this.pictureBox.Image = (Image)window.Clone();
                                    VariabiliGlobali.Globals.screen = (Bitmap)window.Clone();
                                }
                            }
                        }
                    }
                    catch (Exception) { }
                    SendScreenToAllClientsEvent(this, null);
                }
                else
                {
                    if (this.showSharedScreen)
                    {
                        Pen pen = new Pen(Color.Red, 5);
                        using (Graphics g = this.pictureBox.CreateGraphics())
                        {
                            g.DrawRectangle(new Pen(Color.Red, 10), 0, 0, this.pictureBox.Size.Width, this.pictureBox.Size.Height);
                            g.DrawLine(pen, 0, 0, this.pictureBox.Size.Width, this.pictureBox.Size.Height);
                            g.DrawLine(pen, this.pictureBox.Size.Width, 0, 0, this.pictureBox.Size.Height);
                        }
                    }
                }
                Thread.Sleep(VariabiliGlobali.Globals.sendScreenDelay);
            }

            VariabiliGlobali.Globals.screen = null;
            if (!this.StopComesFromParent)
                CloseScreenSharingEvent(this, null);
            this.SendScreenToAllClientsEvent -= new SendScreenToAllClients(this.parent.SendScreenToAllClients);
            this.UpdateSize -= new UpdateClientSizeHandler(this.UpdateClientSizeFunction);
            this.wait.Set();
            Win32.SendMessage(this.formHandle, Win32.WM_CLOSE, (IntPtr)0, (IntPtr)0);
        }

        private Image CaptureWindow(IntPtr hWnd)
        {
             Win32.RECT clientRect = new Win32.RECT();
             if (!Win32.GetClientRect(hWnd, out clientRect)) return null;
             Bitmap bitmap = new Bitmap(clientRect.Right, clientRect.Bottom);
             Graphics gfxBitmap = Graphics.FromImage(bitmap);
             IntPtr hdcBitmap = gfxBitmap.GetHdc();
             IntPtr hdcWindow = Win32.GetDC(hWnd);
             Win32.BitBlt(hdcBitmap, 0, 0, clientRect.Right, clientRect.Bottom, hdcWindow, 0, 0, Win32.TernaryRasterOperations.SRCCOPY);
             gfxBitmap.ReleaseHdc(hdcBitmap);
             Win32.ReleaseDC(hWnd, hdcWindow);
             gfxBitmap.Dispose();
             return (Image)bitmap;
        }

        private Bitmap CaptureCursor(ref int x, ref int y)
        {
            Win32.CURSORINFO cursorInfo = new Win32.CURSORINFO();
            cursorInfo.cbSize = Marshal.SizeOf(cursorInfo);
            if (!Win32.GetCursorInfo(out cursorInfo))
                return null;

            if (cursorInfo.flags != Win32.CURSOR_SHOWING)
                return null;

            IntPtr hicon = Win32.CopyIcon(cursorInfo.hCursor);
            if (hicon == IntPtr.Zero)
                return null;

            Win32.ICONINFO iconInfo;
            if (!Win32.GetIconInfo(hicon, out iconInfo))
                return null;

            x = cursorInfo.ptScreenPos.X - ((int)iconInfo.xHotspot);
            y = cursorInfo.ptScreenPos.Y - ((int)iconInfo.yHotspot);

            using (Bitmap maskBitmap = Bitmap.FromHbitmap(iconInfo.hbmMask))
            {
                if (maskBitmap.Height == maskBitmap.Width * 2)
                {
                    Bitmap resultBitmap = new Bitmap(maskBitmap.Width, maskBitmap.Width);
                    using (Graphics desktopGraphics = Graphics.FromHwnd(Win32.GetDesktopWindow()))
                    {
                        IntPtr desktopHdc = desktopGraphics.GetHdc();
                        IntPtr maskHdc = Win32.CreateCompatibleDC(desktopHdc);
                        IntPtr oldPtr = Win32.SelectObject(maskHdc, maskBitmap.GetHbitmap());

                        using (Graphics resultGraphics = Graphics.FromImage(resultBitmap))
                        {
                            IntPtr resultHdc = resultGraphics.GetHdc();
                            Win32.BitBlt(resultHdc, 0, 0, 32, 32, maskHdc, 0, 32, Win32.TernaryRasterOperations.SRCCOPY);
                            Win32.BitBlt(resultHdc, 0, 0, 32, 32, maskHdc, 0, 0, Win32.TernaryRasterOperations.SRCINVERT);
                            resultGraphics.ReleaseHdc(resultHdc);
                        }

                        IntPtr newPtr = Win32.SelectObject(maskHdc, oldPtr);
                        //Win32.DeleteDC(newPtr);
                        Win32.DeleteObject(newPtr); //forum dice di sostituire con questa per evitare memory leak
                        Win32.DeleteDC(maskHdc);
                        desktopGraphics.ReleaseHdc(desktopHdc);
                        resultBitmap.MakeTransparent(Color.White);
                    }
                    return resultBitmap;
                }
            }
            Icon icon = Icon.FromHandle(hicon);
            return icon.ToBitmap();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData.ToString().CompareTo("F4, Alt") == 0)
                return true;
            if (VariabiliGlobali.Globals.Settings.Shortcut.Key != String.Empty)
            {
                bool Control = VariabiliGlobali.Globals.Settings.Shortcut.Control;
                bool Alt = VariabiliGlobali.Globals.Settings.Shortcut.Alt;
                bool Shift = VariabiliGlobali.Globals.Settings.Shortcut.Shift;
                string key = VariabiliGlobali.Globals.Settings.Shortcut.Key;
                bool isControl = keyData.ToString().Contains("Control");
                bool isAlt = keyData.ToString().Contains("Alt");
                bool isShift = keyData.ToString().Contains("Shift");
                string actualKey = keyData.ToString()[0].ToString();

                if (key == actualKey && Control == isControl && Alt == isAlt && Shift == isShift)
                {
                    if (!Win32.IsIconic(VariabiliGlobali.Globals.hWnd))
                        this.parent.AbleDisableScreenSharing(false, false);
                    return true;
                }
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private Rectangle GetWindowRect()
        {
            Win32.RECT r;
            Win32.GetWindowRect(VariabiliGlobali.Globals.hWnd, out r);
            return new Rectangle(r.Left, r.Top, r.Right - r.Left, r.Bottom - r.Top);
        }

        private void UpdateClientSizeFunction(object sender, UpdateClientSizeArgs arg)
        {
            this.Invoke(new UpdateClientSize(this.doUpdateClientSize), new object[] { arg.ClientSize });
        }

        private void doUpdateClientSize(Size newsize)
        {
            this.ClientSize = newsize;
        }

        public void StopSharingScreen(object sender, EventArgs e)
        {
            this.Invoke(new StopSharedScreen(this.doStopSharing), null);
        }

        private void doStopSharing()
        {
            this.keepCapturing = false;
            this.StopComesFromParent = true;
            this.Close();
        }

        private void pictureBox_DoubleClick(object sender, EventArgs e)
        {
            this.ClientSize = new Size(VariabiliGlobali.Globals.screen.Width, VariabiliGlobali.Globals.screen.Height);
        }
    } 
}
