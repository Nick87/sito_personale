﻿namespace Server
{
    partial class SettingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SettingsForm));
            this.textBoxPorta = new System.Windows.Forms.TextBox();
            this.labelPort = new System.Windows.Forms.Label();
            this.labelPassword = new System.Windows.Forms.Label();
            this.textBoxPassword = new System.Windows.Forms.TextBox();
            this.buttonOK = new System.Windows.Forms.Button();
            this.labelVideo = new System.Windows.Forms.Label();
            this.textBoxShortCut = new System.Windows.Forms.TextBox();
            this.btnArea = new System.Windows.Forms.Button();
            this.btnFinestra = new System.Windows.Forms.Button();
            this.lblWindow = new System.Windows.Forms.Label();
            this.labelIP = new System.Windows.Forms.Label();
            this.comboIP = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.sendMouseCheckBox = new System.Windows.Forms.CheckBox();
            this.mouseTypeCombo = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.UpDownDelay = new System.Windows.Forms.NumericUpDown();
            this.btnDesktop = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.UpDownDelay)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxPorta
            // 
            this.textBoxPorta.Location = new System.Drawing.Point(72, 35);
            this.textBoxPorta.Name = "textBoxPorta";
            this.textBoxPorta.Size = new System.Drawing.Size(119, 20);
            this.textBoxPorta.TabIndex = 1;
            // 
            // labelPort
            // 
            this.labelPort.AutoSize = true;
            this.labelPort.Location = new System.Drawing.Point(11, 39);
            this.labelPort.Name = "labelPort";
            this.labelPort.Size = new System.Drawing.Size(35, 13);
            this.labelPort.TabIndex = 1;
            this.labelPort.Text = "Porta:";
            // 
            // labelPassword
            // 
            this.labelPassword.AutoSize = true;
            this.labelPassword.Location = new System.Drawing.Point(11, 65);
            this.labelPassword.Name = "labelPassword";
            this.labelPassword.Size = new System.Drawing.Size(56, 13);
            this.labelPassword.TabIndex = 2;
            this.labelPassword.Text = "Password:";
            // 
            // textBoxPassword
            // 
            this.textBoxPassword.Location = new System.Drawing.Point(72, 62);
            this.textBoxPassword.Name = "textBoxPassword";
            this.textBoxPassword.Size = new System.Drawing.Size(119, 20);
            this.textBoxPassword.TabIndex = 2;
            // 
            // buttonOK
            // 
            this.buttonOK.Location = new System.Drawing.Point(14, 246);
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.Size = new System.Drawing.Size(177, 23);
            this.buttonOK.TabIndex = 9;
            this.buttonOK.Text = "OK";
            this.buttonOK.UseVisualStyleBackColor = true;
            this.buttonOK.Click += new System.EventHandler(this.btnOkOnClick);
            // 
            // labelVideo
            // 
            this.labelVideo.AutoSize = true;
            this.labelVideo.Location = new System.Drawing.Point(11, 117);
            this.labelVideo.Name = "labelVideo";
            this.labelVideo.Size = new System.Drawing.Size(154, 13);
            this.labelVideo.TabIndex = 5;
            this.labelVideo.Text = "Shortcut abilita/disabilita video:";
            // 
            // textBoxShortCut
            // 
            this.textBoxShortCut.Location = new System.Drawing.Point(13, 135);
            this.textBoxShortCut.Name = "textBoxShortCut";
            this.textBoxShortCut.Size = new System.Drawing.Size(178, 20);
            this.textBoxShortCut.TabIndex = 5;
            // 
            // btnArea
            // 
            this.btnArea.Location = new System.Drawing.Point(14, 185);
            this.btnArea.Name = "btnArea";
            this.btnArea.Size = new System.Drawing.Size(53, 36);
            this.btnArea.TabIndex = 7;
            this.btnArea.Text = "Area";
            this.btnArea.UseVisualStyleBackColor = true;
            this.btnArea.Click += new System.EventHandler(this.btnArea_Click);
            // 
            // btnFinestra
            // 
            this.btnFinestra.Location = new System.Drawing.Point(71, 185);
            this.btnFinestra.Name = "btnFinestra";
            this.btnFinestra.Size = new System.Drawing.Size(54, 36);
            this.btnFinestra.TabIndex = 8;
            this.btnFinestra.Text = "Finestra";
            this.btnFinestra.UseVisualStyleBackColor = true;
            this.btnFinestra.Click += new System.EventHandler(this.btnFinestra_Click);
            // 
            // lblWindow
            // 
            this.lblWindow.AutoEllipsis = true;
            this.lblWindow.AutoSize = true;
            this.lblWindow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWindow.Location = new System.Drawing.Point(19, 227);
            this.lblWindow.Name = "lblWindow";
            this.lblWindow.Size = new System.Drawing.Size(168, 13);
            this.lblWindow.TabIndex = 8;
            this.lblWindow.Text = "Nessuna finestra/area selezionata";
            this.lblWindow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelIP
            // 
            this.labelIP.AutoSize = true;
            this.labelIP.Location = new System.Drawing.Point(11, 12);
            this.labelIP.Name = "labelIP";
            this.labelIP.Size = new System.Drawing.Size(20, 13);
            this.labelIP.TabIndex = 9;
            this.labelIP.Text = "IP:";
            // 
            // comboIP
            // 
            this.comboIP.FormattingEnabled = true;
            this.comboIP.Location = new System.Drawing.Point(72, 8);
            this.comboIP.Name = "comboIP";
            this.comboIP.Size = new System.Drawing.Size(119, 21);
            this.comboIP.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Invia mouse";
            // 
            // sendMouseCheckBox
            // 
            this.sendMouseCheckBox.AutoSize = true;
            this.sendMouseCheckBox.Checked = true;
            this.sendMouseCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.sendMouseCheckBox.Location = new System.Drawing.Point(77, 93);
            this.sendMouseCheckBox.Name = "sendMouseCheckBox";
            this.sendMouseCheckBox.Size = new System.Drawing.Size(15, 14);
            this.sendMouseCheckBox.TabIndex = 3;
            this.sendMouseCheckBox.UseVisualStyleBackColor = true;
            this.sendMouseCheckBox.CheckedChanged += new System.EventHandler(this.sendMouseCheckBox_CheckedChanged);
            // 
            // mouseTypeCombo
            // 
            this.mouseTypeCombo.DisplayMember = "Icona";
            this.mouseTypeCombo.FormattingEnabled = true;
            this.mouseTypeCombo.Items.AddRange(new object[] {
            "Icona",
            "Punto"});
            this.mouseTypeCombo.Location = new System.Drawing.Point(98, 89);
            this.mouseTypeCombo.Name = "mouseTypeCombo";
            this.mouseTypeCombo.Size = new System.Drawing.Size(92, 21);
            this.mouseTypeCombo.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 162);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Refresh schermo (msec):";
            // 
            // UpDownDelay
            // 
            this.UpDownDelay.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.UpDownDelay.Location = new System.Drawing.Point(138, 159);
            this.UpDownDelay.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.UpDownDelay.Name = "UpDownDelay";
            this.UpDownDelay.Size = new System.Drawing.Size(53, 20);
            this.UpDownDelay.TabIndex = 6;
            this.UpDownDelay.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // btnDesktop
            // 
            this.btnDesktop.Location = new System.Drawing.Point(130, 185);
            this.btnDesktop.Name = "btnDesktop";
            this.btnDesktop.Size = new System.Drawing.Size(61, 36);
            this.btnDesktop.TabIndex = 12;
            this.btnDesktop.Text = "Desktop";
            this.btnDesktop.UseVisualStyleBackColor = true;
            this.btnDesktop.Click += new System.EventHandler(this.btn_Desktop_Click);
            // 
            // SettingsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(207, 277);
            this.Controls.Add(this.btnDesktop);
            this.Controls.Add(this.UpDownDelay);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.mouseTypeCombo);
            this.Controls.Add(this.sendMouseCheckBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboIP);
            this.Controls.Add(this.labelIP);
            this.Controls.Add(this.lblWindow);
            this.Controls.Add(this.btnFinestra);
            this.Controls.Add(this.btnArea);
            this.Controls.Add(this.textBoxShortCut);
            this.Controls.Add(this.labelVideo);
            this.Controls.Add(this.buttonOK);
            this.Controls.Add(this.textBoxPassword);
            this.Controls.Add(this.labelPassword);
            this.Controls.Add(this.labelPort);
            this.Controls.Add(this.textBoxPorta);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "SettingsForm";
            this.Text = "Impostazioni";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SettingsForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.UpDownDelay)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxPorta;
        private System.Windows.Forms.Label labelPort;
        private System.Windows.Forms.Label labelPassword;
        private System.Windows.Forms.TextBox textBoxPassword;
        private System.Windows.Forms.Button buttonOK;
        private System.Windows.Forms.Label labelVideo;
        private System.Windows.Forms.TextBox textBoxShortCut;
        private System.Windows.Forms.Button btnArea;
        private System.Windows.Forms.Button btnFinestra;
        private System.Windows.Forms.Label lblWindow;
        private System.Windows.Forms.Label labelIP;
        private System.Windows.Forms.ComboBox comboIP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox sendMouseCheckBox;
        private System.Windows.Forms.ComboBox mouseTypeCombo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown UpDownDelay;
        private System.Windows.Forms.Button btnDesktop;
    }
}