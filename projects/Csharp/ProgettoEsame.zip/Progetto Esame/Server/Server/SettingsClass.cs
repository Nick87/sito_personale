﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;

namespace Server
{
    public class Shortcut
    {
        private bool _Control;
        private bool _Alt;
        private bool _Shift;
        private string _Key;

        public Shortcut()
        {
            _Control = _Alt = _Shift = false;
            _Key = String.Empty;
        }

        public bool Control
        {
            get { return _Control; }
            set { _Control = value; }
        }

        public bool Alt
        {
            get { return _Alt; }
            set { _Alt = value; }
        }

        public bool Shift
        {
            get { return _Shift; }
            set { _Shift = value; }
        }

        public string Key
        {
            get { return _Key; }
            set { _Key = value; }
        }

        /// <summary>
        /// Ritorna la rappresentazione testuale dello shortcut
        /// </summary>
        /// <returns>La stringa dello shortcut</returns>
        public override string ToString()
        {
            if (_Control && _Alt && _Shift)
                return "CTRL + ALT + SHIFT" + " + " + _Key;
            else if (_Control && _Alt)
                return "CTRL + ALT" + " + " + _Key;
            else if (_Control && _Shift)
                return "CTRL + SHIFT" + " + " + _Key;
            else if (_Alt && _Shift)
                return "ALT + SHIFT" + " + " + _Key;
            else if (_Control)
                return "CTRL" + " + " + _Key;
            else if (_Alt)
                return "ALT" + " + " + _Key;
            else if (_Shift)
                return "SHIFT" + " + " + _Key;
            else
                return _Key;
        }
    }

    public class SettingsClass
    {
        private IPAddress _IP;
        private ushort _Porta;
        private string _Password;
        private Shortcut _Shortcut;

        public SettingsClass()
        {
            _Porta = 0;
            _Password = String.Empty;
            _Shortcut = new Shortcut();
        }

        public IPAddress IP
        {
            get { return _IP; }
            set { _IP = value; }
        }

        public ushort Porta
        {
            get { return _Porta; }
            set { _Porta = value; }
        }

        public string Password
        {
            get { return _Password; }
            set { _Password = value; }
        }

        public Shortcut Shortcut
        {
            get { return _Shortcut; }
        }
    }
}
