﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.IO;
using ClassLibrary;
using VariabiliGlobali;
using Win32Api;

namespace Server
{
    public partial class MainForm : Form
    {
        //Delegato che ci serve per aggiornare il Log Box da un altro thread
        private delegate void UpdateLogBox(MyMessage message);
        private bool isClosing;
        private bool Connected;
        private string lastUsername;
        private ChatServer server;
       
        public MainForm()
        {
            InitializeComponent();
            this.isClosing = false;
            this.Connected = false;
            this.MyMessageBox.Enabled = false;
            this.btnInvia.Enabled = false;
            this.lastUsername = String.Empty;
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData.ToString().CompareTo("F4, Alt") == 0) {
                this.Close();
                return true;
            }
            if (VariabiliGlobali.Globals.Settings.Shortcut.Key != String.Empty)
            {
                bool Control = VariabiliGlobali.Globals.Settings.Shortcut.Control;
                bool Alt = VariabiliGlobali.Globals.Settings.Shortcut.Alt;
                bool Shift = VariabiliGlobali.Globals.Settings.Shortcut.Shift;
                string key = VariabiliGlobali.Globals.Settings.Shortcut.Key;
                bool isControl = keyData.ToString().Contains("Control");
                bool isAlt = keyData.ToString().Contains("Alt");
                bool isShift = keyData.ToString().Contains("Shift");
                string actualKey = keyData.ToString()[0].ToString();

                if (Control == isControl && Alt == isAlt && Shift == isShift && key == actualKey)
                {
                    if (!Win32.IsIconic(VariabiliGlobali.Globals.hWnd))
                        this.server.AbleDisableScreenSharing(false, false);
                    return true;
                }
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!this.isClosing)
            {
                if (MessageBox.Show("Vuoi realmente uscire?", "Conferma", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    e.Cancel = true;
                    return;
                }
                else
                {
                    if(server != null)
                        server.CloseAllConnections();
                }
            }
            if (this.Connected)
                this.Connected = false;
        }

        private void onExit(object sender, EventArgs e)
        {
            if (MessageBox.Show("Vuoi realmente uscire?", "Conferma", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                return;
            if (server != null)
            {
                server.CloseAllConnections();
                server = null;
                if (this.Connected)
                    this.Connected = false;
                this.LogBox.SelectionFont = new Font("Verdana", 8, FontStyle.Bold);
                this.LogBox.SelectionColor = Color.Red;
                this.LogBox.AppendText("Server fermato\r\n");
            }
            
            this.isClosing = true;
            this.Close();
        }

        private void ShowSettingsDialog(object sender, EventArgs e)
        {
            new SettingsForm(this, this.Connected).ShowDialog();
            if (this.Connected)
                this.server.UpdateRefreshRate();
        }

        private void btnStartStopSession_Click(object sender, EventArgs e)
        {
            if (!VariabiliGlobali.Globals.configurationOK)
            {
                this.LogBox.SelectionFont = new Font("Verdana", 8, FontStyle.Bold);
                this.LogBox.SelectionColor = Color.Red;
                this.LogBox.AppendText("Impossibile avviare la sessione. Controllare le impostazioni.\r\n");
                return;
            }
            VariabiliGlobali.Globals.SessionStarted = !VariabiliGlobali.Globals.SessionStarted;
            if (VariabiliGlobali.Globals.SessionStarted)
            {
                server = new ChatServer(VariabiliGlobali.Globals.Settings.IP, VariabiliGlobali.Globals.Settings.Porta);
                //Agganciamo l'evento "UpdateEvent" al metodo server_UpdateLogBox
                this.server.UpdateEvent += new UpdateLogBoxEventHandler(this.server_UpdateLogBox);
                if (this.server.StartListening())
                {
                    this.btnStartStopSession.Image = System.Drawing.Image.FromFile("images/stop.png");
                    this.btnStartStopSession.Text = "Ferma sessione";
                    this.MyMessageBox.Enabled = true;
                    this.btnInvia.Enabled = true;
                    this.Connected = true;
                }
                else
                {
                    this.server.UpdateEvent -= new UpdateLogBoxEventHandler(this.server_UpdateLogBox);
                    this.server = null;
                    this.btnStartStopSession.Image = System.Drawing.Image.FromFile("images/play.png");
                    this.btnStartStopSession.Text = "Avvia sessione";
                    this.MyMessageBox.Enabled = false;
                    this.btnInvia.Enabled = false;
                    this.Connected = false;
                    this.LogBox.SelectionFont = new Font("Verdana", 8, FontStyle.Bold);
                    this.LogBox.SelectionColor = Color.Red;
                    this.LogBox.AppendText("Impossibile avviare la sessione. Riprovare più tardi e controllare le impostazioni.\r\n");
                }
            }
            else
            {
                this.btnStartStopSession.Image = System.Drawing.Image.FromFile("images/play.png");
                this.btnStartStopSession.Text = "Avvia sessione";
                this.Connected = false;
                this.MyMessageBox.Enabled = false;
                this.btnInvia.Enabled = false;
                if (server != null)
                {
                    server.CloseAllConnections();
                    this.server.UpdateEvent -= new UpdateLogBoxEventHandler(this.server_UpdateLogBox);
                    lock (VariabiliGlobali.Globals.mutex)
                    {
                        VariabiliGlobali.Globals.ConnectedClients = 0;
                    }
                    server = null;
                    this.LogBox.SelectionFont = new Font("Verdana", 8, FontStyle.Bold);
                    this.LogBox.SelectionColor = Color.Red;
                    this.LogBox.AppendText("Server fermato.\r\n");
                }
            }
        }

        //Usiamo Invoke ed il delegato che abbiamo creato perchè questa è una chiamata cross-thread
        public void server_UpdateLogBox(object sender, UpdateLogBoxArgs e)
        {
            this.Invoke(new UpdateLogBox(this.doUpdateLogBox), new object[] { e.Message });
        }

        private void doUpdateLogBox(MyMessage msg)
        {
            if (msg is ClientTextMessage)
            {
                ClientTextMessage message = (ClientTextMessage) msg;
                if (this.lastUsername != message.from)
                {
                    this.lastUsername = message.from;
                    this.LogBox.SelectionFont = new Font("Verdana", 8, FontStyle.Bold);
                    this.LogBox.SelectionColor = Color.Blue;
                    this.LogBox.AppendText(message.from + " scrive: (" + DateTime.Now.ToShortTimeString() + ")\n");
                }

                this.LogBox.SelectionFont = new Font("Verdana", 8, FontStyle.Regular);
                this.LogBox.SelectionColor = Color.Black;
                this.LogBox.AppendText(" - " + message.message + "\n");
            }
            else if(msg is AdminTextMessage)
            {
                AdminTextMessage message = (AdminTextMessage)msg;
                this.LogBox.SelectionFont = new Font("Verdana", 8, FontStyle.Bold);
                this.LogBox.SelectionColor = Color.Red;
                if (message.from != null && message.from != String.Empty)
                    this.LogBox.AppendText(message.from + ": ");
                this.LogBox.AppendText(message.message + "\n");
            }
            else if (msg is ClipboardText)
            {
                ClipboardText cliptext = (ClipboardText) msg;                
                this.LogBox.SelectionFont = new Font("Verdana", 8, FontStyle.Bold);
                this.LogBox.SelectionColor = Color.Red;
                this.LogBox.AppendText("<CLIPBOARD:" + cliptext.from + "> Testo: \"" + cliptext.text + "\"\n");
            }
            else if (msg is ClipboardFile)
            {
                ClipboardFile clipfile = (ClipboardFile)msg;
                this.LogBox.SelectionFont = new Font("Verdana", 8, FontStyle.Bold);
                this.LogBox.SelectionColor = Color.Red;
                this.LogBox.AppendText("<CLIPBOARD:" + clipfile.from + "> File: \"" + clipfile.filename + "\"\n");
            }
            else if (msg is ClipboardImage)
            {
                ClipboardImage clipimage = (ClipboardImage)msg;
                this.LogBox.SelectionFont = new Font("Verdana", 8, FontStyle.Bold);
                this.LogBox.SelectionColor = Color.Red;
                this.LogBox.AppendText("<CLIPBOARD:" + clipimage.from + "> Bitmap\n");
            }
            this.LogBox.ScrollToCaret();
        }

        private void btnInvia_Click(object sender, EventArgs e)
        {
            if (this.MyMessageBox.Text.Trim().Length == 0) return;

            server.SendMessage(null, new ClientTextMessage(this.MyMessageBox.Text.Trim(), "Server"));
            this.MyMessageBox.Text = "";
            this.LogBox.ScrollToCaret();
        }

        private void MyMessageBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter && this.MyMessageBox.Text.Trim().Length > 0)
            {
                server.SendMessage(null, new ClientTextMessage(this.MyMessageBox.Text.Trim(), "Server"));
                this.MyMessageBox.Text = "";
                this.LogBox.ScrollToCaret();
            }
        }
    }
}
