﻿namespace Server
{
    partial class MainForm
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.MenuBar = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.impostazioniToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.esciToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.btnStartStopSession = new System.Windows.Forms.ToolStripButton();
            this.LogBox = new System.Windows.Forms.RichTextBox();
            this.MyMessageBox = new System.Windows.Forms.TextBox();
            this.btnInvia = new System.Windows.Forms.Button();
            this.MenuBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // MenuBar
            // 
            this.MenuBar.AllowItemReorder = true;
            this.MenuBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton1,
            this.btnStartStopSession});
            this.MenuBar.Location = new System.Drawing.Point(0, 0);
            this.MenuBar.Name = "MenuBar";
            this.MenuBar.Size = new System.Drawing.Size(384, 25);
            this.MenuBar.TabIndex = 4;
            this.MenuBar.Text = "toolStrip1";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.impostazioniToolStripMenuItem1,
            this.esciToolStripMenuItem1});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(29, 22);
            this.toolStripDropDownButton1.Text = "Impostazioni";
            // 
            // impostazioniToolStripMenuItem1
            // 
            this.impostazioniToolStripMenuItem1.Name = "impostazioniToolStripMenuItem1";
            this.impostazioniToolStripMenuItem1.Size = new System.Drawing.Size(145, 22);
            this.impostazioniToolStripMenuItem1.Text = "Impostazioni";
            this.impostazioniToolStripMenuItem1.Click += new System.EventHandler(this.ShowSettingsDialog);
            // 
            // esciToolStripMenuItem1
            // 
            this.esciToolStripMenuItem1.Name = "esciToolStripMenuItem1";
            this.esciToolStripMenuItem1.Size = new System.Drawing.Size(145, 22);
            this.esciToolStripMenuItem1.Text = "Esci";
            this.esciToolStripMenuItem1.Click += new System.EventHandler(this.onExit);
            // 
            // btnStartStopSession
            // 
            this.btnStartStopSession.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnStartStopSession.Image = ((System.Drawing.Image)(resources.GetObject("btnStartStopSession.Image")));
            this.btnStartStopSession.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnStartStopSession.Name = "btnStartStopSession";
            this.btnStartStopSession.Size = new System.Drawing.Size(23, 22);
            this.btnStartStopSession.Text = "Avvia Sessione";
            this.btnStartStopSession.Click += new System.EventHandler(this.btnStartStopSession_Click);
            // 
            // LogBox
            // 
            this.LogBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.LogBox.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.LogBox.Location = new System.Drawing.Point(4, 23);
            this.LogBox.Name = "LogBox";
            this.LogBox.ReadOnly = true;
            this.LogBox.Size = new System.Drawing.Size(377, 193);
            this.LogBox.TabIndex = 5;
            this.LogBox.Text = "";
            this.LogBox.WordWrap = false;
            // 
            // MyMessageBox
            // 
            this.MyMessageBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.MyMessageBox.Location = new System.Drawing.Point(4, 219);
            this.MyMessageBox.Name = "MyMessageBox";
            this.MyMessageBox.Size = new System.Drawing.Size(320, 20);
            this.MyMessageBox.TabIndex = 6;
            this.MyMessageBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MyMessageBox_KeyPress);
            // 
            // btnInvia
            // 
            this.btnInvia.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnInvia.Location = new System.Drawing.Point(326, 217);
            this.btnInvia.Name = "btnInvia";
            this.btnInvia.Size = new System.Drawing.Size(55, 23);
            this.btnInvia.TabIndex = 7;
            this.btnInvia.Text = "Invia";
            this.btnInvia.UseVisualStyleBackColor = true;
            this.btnInvia.Click += new System.EventHandler(this.btnInvia_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 242);
            this.Controls.Add(this.btnInvia);
            this.Controls.Add(this.MyMessageBox);
            this.Controls.Add(this.LogBox);
            this.Controls.Add(this.MenuBar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(250, 200);
            this.Name = "MainForm";
            this.Text = "Server";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.MenuBar.ResumeLayout(false);
            this.MenuBar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip MenuBar;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem impostazioniToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem esciToolStripMenuItem1;
        private System.Windows.Forms.ToolStripButton btnStartStopSession;
        private System.Windows.Forms.RichTextBox LogBox;
        private System.Windows.Forms.TextBox MyMessageBox;
        private System.Windows.Forms.Button btnInvia;
    }
}

