﻿using System;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using System.ComponentModel;
using System.Runtime.InteropServices;
using Win32Api;

namespace Server
{
    public class UserActivityHook
    {
        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall, SetLastError = true)]
        private static extern int SetWindowsHookEx(int idHook, HookProc lpfn, IntPtr hMod, int dwThreadId);

        private delegate int HookProc(int nCode, int wParam, IntPtr lParam);
        private const int WH_MOUSE_LL = 14;
        private const int WM_LBUTTONDOWN = 0x201;
        public event MouseEventHandler OnMouseActivity;
        private int hMouseHook = 0;
        private static HookProc MouseHookProcedure;

        public UserActivityHook()
        {
            Start();
        }

        ~UserActivityHook()
        {
            Stop();
        }

        public void Start()
        {
            if (hMouseHook == 0)
            {
                MouseHookProcedure = new HookProc(MouseHookProc);
                hMouseHook = SetWindowsHookEx(WH_MOUSE_LL, MouseHookProcedure, Marshal.GetHINSTANCE(Assembly.GetExecutingAssembly().GetModules()[0]), 0);
                if (hMouseHook == 0)
                    Stop();
            }
        }

        public void Stop()
        {
            if (hMouseHook != 0)
            {
                Win32.UnhookWindowsHookEx(hMouseHook);
                hMouseHook = 0;
            }
        }

        private int MouseHookProc(int nCode, int wParam, IntPtr lParam)
        {
            if ((nCode >= 0) && (OnMouseActivity != null))
            {
                Win32.MouseLLHookStruct mouseHookStruct = (Win32.MouseLLHookStruct)Marshal.PtrToStructure(lParam, typeof(Win32.MouseLLHookStruct));
                MouseButtons button = MouseButtons.None;
                if(wParam == WM_LBUTTONDOWN)
                    button = MouseButtons.Left;
                int clickCount = (button == MouseButtons.None) ? 0 : 1;
                MouseEventArgs e = new MouseEventArgs(button, clickCount, mouseHookStruct.pt.X, mouseHookStruct.pt.Y, 0);
                OnMouseActivity(this, e);
            }
            return Win32.CallNextHookEx(hMouseHook, nCode, wParam, lParam);
        }
    }
}
