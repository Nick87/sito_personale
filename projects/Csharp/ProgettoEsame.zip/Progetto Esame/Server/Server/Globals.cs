﻿using System;
using Server;
using System.Drawing;
using System.Runtime.InteropServices;
using System.IO;

namespace VariabiliGlobali
{
    public class Globals
    {
        public static Object mutex = new Object();
        public static SettingsClass Settings = new SettingsClass();
        public static bool configurationOK = false;
        public static bool SessionStarted = false;
        public static int ConnectedClients = 0;
        public static int MaxClients = 4;
        public static bool isAreaSelected = false;
        public static bool isWindowSelected = false;
        public static string AreaString = "";
        public static string WindowString = "";
        public static Object screen_mutex = new Object();
        public static Bitmap screen = null;
        public static Bitmap screen_old = null;
        public static Size old_size = new Size(-1, -1);
        public static Rectangle rect = new Rectangle();
        public static IntPtr hWnd = IntPtr.Zero;
        public static Object socket_mutex = new Object();
        public static bool captureEnabled = true;
        public static int sendScreenDelay = 50;
        public static bool sendMouse = true;
        public static MouseType mouseTypeToSend = MouseType.Icona;
        public static bool showSharedScreen = false;
        public enum MouseType : uint { Icona = 0, Punto }
    }
}