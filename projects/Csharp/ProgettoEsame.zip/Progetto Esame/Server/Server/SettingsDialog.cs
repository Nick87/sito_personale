﻿using System;
using System.Management;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Net;
using System.Net.NetworkInformation;
using System.Security.Cryptography;
using Win32Api;
using VariabiliGlobali;

namespace Server
{
    public partial class SettingsForm : Form
    {
        private UserActivityHook actHook;
        private string IPs = String.Empty;
        private Form parent;

        public SettingsForm(Form p, bool Connected)
        {
            InitializeComponent();
            if (Connected)
            {
                this.comboIP.Enabled = false;
                this.textBoxPorta.Enabled = false;
                this.textBoxPassword.Enabled = false;
                this.textBoxShortCut.Enabled = false;
                this.btnArea.Enabled = false;
                this.btnFinestra.Enabled = false;
                this.btnDesktop.Enabled = false;
            }
            this.UpDownDelay.Value = (decimal)VariabiliGlobali.Globals.sendScreenDelay;

            this.parent = p;
            this.IPs = "localhost|";
            this.TopMost = true;
            this.textBoxShortCut.KeyDown += new KeyEventHandler(this.OnKeyDown);

            GetIPs(ref this.IPs);
            this.comboIP.Items.AddRange((object[])this.IPs.Split('|'));

            this.mouseTypeCombo.Enabled = VariabiliGlobali.Globals.sendMouse;
            this.sendMouseCheckBox.Checked = VariabiliGlobali.Globals.sendMouse;
            if (VariabiliGlobali.Globals.mouseTypeToSend == Globals.MouseType.Icona)
                this.mouseTypeCombo.SelectedIndex = 0;
            else
                this.mouseTypeCombo.SelectedIndex = 1;

            if (VariabiliGlobali.Globals.Settings.Porta != 0)
                this.textBoxPorta.Text = VariabiliGlobali.Globals.Settings.Porta.ToString();
            this.textBoxPassword.Text = VariabiliGlobali.Globals.Settings.Password;
            this.textBoxShortCut.Text = VariabiliGlobali.Globals.Settings.Shortcut.ToString();
            if (VariabiliGlobali.Globals.Settings.IP != null)
            {
                if (VariabiliGlobali.Globals.Settings.IP.ToString() == "127.0.0.1")
                    this.comboIP.Text = "localhost";
                else
                    this.comboIP.Text = VariabiliGlobali.Globals.Settings.IP.ToString();
            }
            if (VariabiliGlobali.Globals.isWindowSelected)
            {
                this.lblWindow.Text = VariabiliGlobali.Globals.WindowString;
                this.lblWindow.Font = new Font(this.lblWindow.Font, FontStyle.Bold);
            }
            if (VariabiliGlobali.Globals.isAreaSelected)
            {
                this.lblWindow.Text = VariabiliGlobali.Globals.AreaString;
                this.lblWindow.Font = new Font(this.lblWindow.Font, FontStyle.Bold);
            }
        }

        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            e.SuppressKeyPress = true;

            if (e.Control && e.Alt && e.Shift)
                this.textBoxShortCut.Text = "CTRL + ALT + SHIFT";
            else if (e.Control && e.Alt)
                this.textBoxShortCut.Text = "CTRL + ALT";
            else if (e.Control && e.Shift)
                this.textBoxShortCut.Text = "CTRL + SHIFT";
            else if (e.Alt && e.Shift)
                this.textBoxShortCut.Text = "ALT + SHIFT";
            else if (e.Control)
                this.textBoxShortCut.Text = "CTRL";
            else if (e.Alt)
                this.textBoxShortCut.Text = "ALT";
            else if (e.Shift)
                this.textBoxShortCut.Text = "SHIFT";

            VariabiliGlobali.Globals.Settings.Shortcut.Key = String.Empty;
            if ((e.KeyCode >= Keys.A && e.KeyCode <= Keys.Z)/* ||
                (e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9) ||
                (e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9) ||
                (e.KeyCode >= Keys.F1 && e.KeyCode <= Keys.F12)*/)
            {
                string shortcut = "";
                /*if (e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9)
                    shortcut = e.KeyCode.ToString().Substring(1);
                else if (e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9)
                    shortcut = e.KeyCode.ToString().Substring(6);
                else*/
                    shortcut = e.KeyCode.ToString();

                if (e.Control || e.Alt || e.Shift)
                    this.textBoxShortCut.Text += " + " + shortcut;
                else
                    this.textBoxShortCut.Text = shortcut;
            }
        }

        private void btnOkOnClick(object sender, EventArgs e)
        {
            if (!ValidateIP()) return;
            if (!ValidatePort()) return;
            if (!ValidatePassword()) return;
            if (!ValidateMouseTypeToSend()) return;
            if (!ValidateShortcut()) return;
            if (!ValidateScreenCapture()) return;
            VariabiliGlobali.Globals.configurationOK = true;
            VariabiliGlobali.Globals.sendScreenDelay = (int)this.UpDownDelay.Value;
            VariabiliGlobali.Globals.sendMouse = this.mouseTypeCombo.Enabled;
            if (this.mouseTypeCombo.SelectedIndex == 0)
                VariabiliGlobali.Globals.mouseTypeToSend = Globals.MouseType.Icona;
            else
                VariabiliGlobali.Globals.mouseTypeToSend = Globals.MouseType.Punto;
            this.Close();
            parent.Show();
        }

        private void SettingsForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            parent.Show();
        }

        private bool ValidateIP()
        {
            IPAddress temp;
            string ip = this.comboIP.Text;

            if (ip == String.Empty)
            {
                MessageBox.Show("Inserire l'indirizzo IP.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }

            if (ip == "localhost")
            {
                VariabiliGlobali.Globals.Settings.IP = IPAddress.Parse("127.0.0.1");
                return true;
            }

            if (ip.Split('.').Length != 4)
            {
                MessageBox.Show("Inserire un indirizzo IP valido.", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }

            if (ip == "255.255.255.255" || ip == "0.0.0.0")
            {
                MessageBox.Show("Indirizzo IP non permesso.", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }

            try
            {
                temp = IPAddress.Parse(ip);
            }
            catch
            {
                MessageBox.Show("Inserire un indirizzo IP valido.", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }

            bool found = false;
            string[] ips = this.IPs.Split('|');
            foreach (string Ip in ips)
                if (Ip == ip)
                    found = true;
            if (!found)
            {
                MessageBox.Show("Attenzione! Poichè l'indirizzo IP immesso non sembra essere attualmente associato a nessuna interfaccia, " +
                                "l'avvio della sessione potrebbe non andare a buon fine.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            VariabiliGlobali.Globals.Settings.IP = temp;
            return true;
        }

        private void GetIPs(ref string IPs)
        {
            foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (ni.OperationalStatus != OperationalStatus.Up) continue;
                foreach (UnicastIPAddressInformation uipai in ni.GetIPProperties().UnicastAddresses)
                {
                    if (uipai.Address.AddressFamily != System.Net.Sockets.AddressFamily.InterNetwork || uipai.Address.ToString() == "127.0.0.1") continue;
                    IPs += uipai.Address + "|";
                }
            }
            IPs = IPs.Substring(0, IPs.Length - 1);
        }

        private bool ValidatePort()
        {
            int val = 0;
            if (this.textBoxPorta.Text == String.Empty)
            {
                MessageBox.Show("Inserire il numero di porta.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }
            try
            {
                val = int.Parse(this.textBoxPorta.Text);
            }
            catch
            {
                MessageBox.Show("Inserire un numero di porta valido.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }
            if (val <= 1024 || val > 65535)
            {
                MessageBox.Show("Il numero di porta deve essere compreso tra 1025 e 65535.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }
            VariabiliGlobali.Globals.Settings.Porta = (ushort)val;
            return true;
        }

        private bool ValidatePassword()
        {
            if (this.textBoxPassword.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Inserire una password.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }
            VariabiliGlobali.Globals.Settings.Password = this.textBoxPassword.Text.Trim();
            return true;
        }

        private string SHA512(string phrase)
        {
            UTF8Encoding encoder = new UTF8Encoding();
            SHA512Managed sha512hasher = new SHA512Managed();
            byte[] hashedDataBytes = sha512hasher.ComputeHash(encoder.GetBytes(phrase));
            StringBuilder output = new StringBuilder("");
            for (int i = 0; i < hashedDataBytes.Length; i++)
                output.Append(hashedDataBytes[i].ToString("x2"));
            return output.ToString();
        }

        private bool ValidateMouseTypeToSend()
        {
            if (this.sendMouseCheckBox.Checked)
            {
                if (this.mouseTypeCombo.Text != "Icona" && this.mouseTypeCombo.Text != "Punto")
                {
                    MessageBox.Show("Valore non valido per il tipo di mouse da inviare.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    VariabiliGlobali.Globals.configurationOK = false;
                    return false;
                }
                else
                    return true;
            }
            return true;
        }

        private bool ValidateShortcut()
        {
            if (this.textBoxShortCut.Text == String.Empty)
            {
                MessageBox.Show("Inserire una combinazione shortcut.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.Settings.Shortcut.Control = false;
                VariabiliGlobali.Globals.Settings.Shortcut.Alt = false;
                VariabiliGlobali.Globals.Settings.Shortcut.Shift = false;
                VariabiliGlobali.Globals.Settings.Shortcut.Key = String.Empty;
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }

            //La combinazione non è valida se non è presente almeno un modificatore della tastiera (Ctrl, Alt, Shift)
            if (!(this.textBoxShortCut.Text.Contains("CTRL") || this.textBoxShortCut.Text.Contains("ALT") ||
                this.textBoxShortCut.Text.Contains("SHIFT")))
            {
                MessageBox.Show("Combinazione shortcut non valida.\nDeve essere presente uno tra questi: Ctrl, Alt, Shift.", "Errore",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.Settings.Shortcut.Control = false;
                VariabiliGlobali.Globals.Settings.Shortcut.Alt = false;
                VariabiliGlobali.Globals.Settings.Shortcut.Shift = false;
                VariabiliGlobali.Globals.Settings.Shortcut.Key = String.Empty;
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }

            //La combinazione non è valida se non c'è una lettera, un numero o un tasto funzione
            if (GetShortcutKey() == String.Empty)
            {
                MessageBox.Show("Combinazione shortcut non valida.\nE' necessaria una lettera, un numero o un tasto funzione.", "Errore",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.Settings.Shortcut.Control = false;
                VariabiliGlobali.Globals.Settings.Shortcut.Alt = false;
                VariabiliGlobali.Globals.Settings.Shortcut.Shift = false;
                VariabiliGlobali.Globals.Settings.Shortcut.Key = String.Empty;
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }

            //La combinazione Alt + F4 non è valida
            if (this.textBoxShortCut.Text.Contains("ALT") && !this.textBoxShortCut.Text.Contains("CTRL") &&
                !this.textBoxShortCut.Text.Contains("SHIFT") && GetShortcutKey() == "F4")
            {
                MessageBox.Show("Combinazione shortcut non valida in quanto collide con la chiusura della finestra.", "Errore",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.Settings.Shortcut.Control = false;
                VariabiliGlobali.Globals.Settings.Shortcut.Alt = false;
                VariabiliGlobali.Globals.Settings.Shortcut.Shift = false;
                VariabiliGlobali.Globals.Settings.Shortcut.Key = String.Empty;
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }
            VariabiliGlobali.Globals.Settings.Shortcut.Control = this.textBoxShortCut.Text.Contains("CTRL");
            VariabiliGlobali.Globals.Settings.Shortcut.Alt = this.textBoxShortCut.Text.Contains("ALT");
            VariabiliGlobali.Globals.Settings.Shortcut.Shift = this.textBoxShortCut.Text.Contains("SHIFT");
            VariabiliGlobali.Globals.Settings.Shortcut.Key = GetShortcutKey();
            return true;
        }

        private string GetShortcutKey()
        {
            string text = this.textBoxShortCut.Text;
            text = text.Replace("CTRL", "");
            text = text.Replace("ALT", "");
            text = text.Replace("SHIFT", "");
            text = text.Replace("+", "");
            text = text.Replace(" ", "");
            return text;
        }

        private bool ValidateScreenCapture()
        {
            if (VariabiliGlobali.Globals.isAreaSelected == false &&
                VariabiliGlobali.Globals.isWindowSelected == false)
            {
                MessageBox.Show("Selezionare una finestra o un'area dello schermo.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                VariabiliGlobali.Globals.configurationOK = false;
                return false;
            }
            return true;
        }

        private void btnFinestra_Click(object sender, EventArgs e)
        {
            actHook = new UserActivityHook();
            actHook.OnMouseActivity += new MouseEventHandler(this.MouseHandler);
            this.Hide();
            parent.Hide();
        }

        private void btn_Desktop_Click(object sender, EventArgs e)
        {
            VariabiliGlobali.Globals.rect = Screen.PrimaryScreen.Bounds;
            this.lblWindow.Text = VariabiliGlobali.Globals.AreaString = "Desktop: " + Screen.PrimaryScreen.Bounds.Width + "x" + Screen.PrimaryScreen.Bounds.Height;
            this.lblWindow.Font = new Font(this.lblWindow.Font, FontStyle.Bold);
            this.lblWindow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            VariabiliGlobali.Globals.isAreaSelected = true;
            VariabiliGlobali.Globals.isWindowSelected = false;
        }

        //Per prendere HANDLE finestra al click del mouse
        private void MouseHandler(object sender, MouseEventArgs e)
        {
            if (e.Clicks > 0)
            {
                StringBuilder Buff = new StringBuilder(256);
                string str;
                Win32.POINT pos;
                pos.X = e.X;
                pos.Y = e.Y;
                VariabiliGlobali.Globals.hWnd = Win32.WindowFromPoint(pos);
                Win32.GetWindowText(VariabiliGlobali.Globals.hWnd, Buff, 256);
                str = Buff.ToString();

                using (System.Drawing.Graphics graphics = System.Drawing.Graphics.FromImage(new Bitmap(1, 1)))
                {
                    SizeF size = graphics.MeasureString(Buff.ToString(), this.lblWindow.Font);
                    if (size.Width > 175)
                        str = str.Substring(0, 25) + "...";
                }

                actHook.OnMouseActivity -= new MouseEventHandler(MouseHandler);
                actHook.Stop();
                this.Show();
                this.TopMost = true;
                parent.Show();
                this.lblWindow.Text = str;
                VariabiliGlobali.Globals.WindowString = str;
                this.lblWindow.Font = new Font(this.lblWindow.Font, FontStyle.Bold);
                VariabiliGlobali.Globals.isWindowSelected = true;
                VariabiliGlobali.Globals.isAreaSelected = false;
            }
        }

        private void btnArea_Click(object sender, EventArgs e)
        {
            string str;
            SelectArea sa = new SelectArea(this, parent);
            sa.InstanceRef = this;
            this.Hide();
            parent.Hide();
            sa.ShowDialog();
            sa.TopLevel = true;

            if (VariabiliGlobali.Globals.isAreaSelected)
            {
                str = "(" + VariabiliGlobali.Globals.rect.X + ", " + VariabiliGlobali.Globals.rect.Y +
                      ") - " + VariabiliGlobali.Globals.rect.Width + "x" + VariabiliGlobali.Globals.rect.Height;
                VariabiliGlobali.Globals.AreaString = str;
                this.lblWindow.Text = str;
                this.lblWindow.Font = new Font(this.lblWindow.Font, FontStyle.Bold);
                this.lblWindow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            }
        }

        private void sendMouseCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (this.sendMouseCheckBox.Checked)
                this.mouseTypeCombo.Enabled = true;
            else
                this.mouseTypeCombo.Enabled = false;
        }
    }
}
