﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Windows.Forms;
using System.Drawing;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using ClassLibrary;
using Win32Api;

namespace Server
{
    public class UpdateLogBoxArgs : EventArgs
    {
        private MyMessage _message;

        public UpdateLogBoxArgs(MyMessage msg)
        {
            _message = msg;
        }

        public MyMessage Message
        {
            get { return _message; }
        }
    }
    
    public delegate void UpdateLogBoxEventHandler(object sender, UpdateLogBoxArgs e);
    
    public class ChatServer
    {
        public Hashtable Users = new Hashtable(VariabiliGlobali.Globals.MaxClients);
        public Hashtable Connections = new Hashtable(VariabiliGlobali.Globals.MaxClients);
        private List<Connection> Conn = new List<Connection>();
        private IPAddress ipAddress;
        private ushort porta;
        private TcpClient tcpClient;
        public event UpdateLogBoxEventHandler UpdateEvent;
        private Thread threadListener;
        private SharedScreen sharedScreen;
        private TcpListener tcpListener;
        private event StopSharedScreenHandler StopSharingScreen;
        private bool ScreenSharingWindowOpen;

        AutoResetEvent wait = new AutoResetEvent(false);
        private volatile bool keepRunning = true;

        public ChatServer(IPAddress ip, ushort port)
        {
            this.ipAddress = ip;
            this.porta = port;
            this.ScreenSharingWindowOpen = true;
        }

        public void AddUser(TcpClient tcpUser, string username)
        {
            Users.Add(username, tcpUser);
            Connections.Add(tcpUser, username);
            AdminTextMessage message = new AdminTextMessage(username + " entra in chat alle " + DateTime.Now.ToShortTimeString() + ".", "");
            SendMessage(tcpUser, message);
            SendScreenToClient(tcpUser);
        }

        public void RemoveUser(TcpClient user)
        {
            if (Connections[user] != null)
            {
                AdminTextMessage message = new AdminTextMessage(Connections[user] + " esce dalla chat alle " + DateTime.Now.ToShortTimeString() + ".", "");
                UpdateEvent(this, new UpdateLogBoxArgs(message));
                Users.Remove(Connections[user]);
                Connections.Remove(user);
                
                foreach (Connection c in Conn)
                {
                    if (c.client == null) continue;
                    if (c.client == user) {
                        Conn.Remove(c);
                        break;
                    }
                }

                foreach (Connection c in Conn)
                {
                    if (c.client == null || c.client == user) continue;
                    try {
                        SendToClient(message, c.client);
                    } catch {
                        RemoveUser(c.client);
                    }
                }
            }
        }

        private bool SendToClient(object obj, TcpClient to)
        {
            try
            {
                IFormatter formatter = new BinaryFormatter();
                NetworkStream strm = to.GetStream();
                lock(VariabiliGlobali.Globals.socket_mutex)
                {
                    formatter.Serialize(strm, obj);
                }
                strm.Flush();
            }
            catch(Exception)
            {
                return false;
            }
            return true;
        }

        public void UpdateRefreshRate()
        {
            AdminTextMessage message = new AdminTextMessage("RefreshRate: " + VariabiliGlobali.Globals.sendScreenDelay.ToString(), "Server");
            TcpClient[] clients = new TcpClient[Users.Count];
            Users.Values.CopyTo(clients, 0);
            for (int i = 0; i < clients.Length; i++)
            {
                try
                {
                    if (clients[i] == null) continue;
                    SendToClient(message, clients[i]);
                }
                catch
                {
                    RemoveUser(clients[i]);
                }
            }
        }

        public void SendMessage(TcpClient from, MyMessage message)
        {
            TcpClient[] clients = new TcpClient[Users.Count];
            Users.Values.CopyTo(clients, 0);
            for (int i = 0; i < clients.Length; i++)
            {
                try {
                    if (clients[i] == null || clients[i] == from) continue;
                    SendToClient(message, clients[i]);
                } catch {
                    RemoveUser(clients[i]);
                }
            }
            UpdateEvent(this, new UpdateLogBoxArgs(message));
        }

        public void SendScreenToClient(TcpClient from)
        {
            if (VariabiliGlobali.Globals.screen == null) return;
            ScreenImage message = new ScreenImage(VariabiliGlobali.Globals.screen, "Server");
            try {
                SendToClient(message, from);
            } catch {
                RemoveUser(from);
            }
        }

        public void SendScreenToAllClients(object sender, EventArgs e)
        {
            int width = 0, height = 0;
            int x, y;
            ManualResetEvent[] doneEvents = new ManualResetEvent[3*3];
            ThreadPoolScreenWorker[] workerArray = new ThreadPoolScreenWorker[3*3];
            MySharedScreen message = new MySharedScreen("Server");

            if (VariabiliGlobali.Globals.screen == null) return;
            try
            {
                width = VariabiliGlobali.Globals.screen.Width / 3;
                height = VariabiliGlobali.Globals.screen.Height / 3;
            }
            catch (Exception) { }

            for (int i = 0; i < 3; i++)
            {
                y = i * height;
                for(int j = 0; j < 3; j++)
                {
                    x = j * width;
                    doneEvents[i * 3 + j] = new ManualResetEvent(false);
                    workerArray[i * 3 + j] = new ThreadPoolScreenWorker(doneEvents[i * 3 + j], new Rectangle(x, y, width, height));
                    ThreadPool.QueueUserWorkItem(workerArray[i * 3 + j].ThreadPoolCallback, new Rectangle(x, y, width, height));
                }
            }

            WaitHandle.WaitAll(doneEvents);
            MergeRectangles(message, workerArray);

            VariabiliGlobali.Globals.old_size = new Size(width, height);
            message.size = new Size(width, height);

            TcpClient[] clients = new TcpClient[Users.Count];
            Users.Values.CopyTo(clients, 0);

            for (int i = 0; i < clients.Length; i++)
            {
                try {
                    if (clients[i] == null) continue;
                    SendToClient(message, clients[i]);
                } catch {
                    RemoveUser(clients[i]);
                }
            }
            lock (VariabiliGlobali.Globals.screen_mutex)
            {
                VariabiliGlobali.Globals.screen_old = (Bitmap)VariabiliGlobali.Globals.screen.Clone();
            }
        }

        private void MergeRectangles(MySharedScreen message, ThreadPoolScreenWorker[] workers)
        {
            lock (VariabiliGlobali.Globals.screen_mutex)
            {
                for (int i = 0; i < workers.Length; i++)
                {
                    if (!workers[i].isChanged)
                    {
                        //message.image[i / 3, i % 3] = (Bitmap)workers[i].bitmapChanged.Clone();
                        message.rect[i / 3, i % 3].Size = new Size(-1, -1);
                    }
                    else
                    {
                        message.image[i / 3, i % 3] = (Bitmap)workers[i].bitmapChanged.Clone();
                        message.rect[i / 3, i % 3].Size = message.image[i / 3, i % 3].Size;
                    }
                }
                
            }
        }

        public bool StartListening()
        {
            try
            {
                tcpListener = new TcpListener(this.ipAddress, this.porta);
                tcpListener.Start();
                keepRunning = true;
                threadListener = new Thread(new ThreadStart(KeepListening));
                AdminTextMessage message = new AdminTextMessage("Server in ascolto su " + this.ipAddress + ":" + this.porta + ".", "");
                UpdateEvent(this, new UpdateLogBoxArgs(message));
                threadListener.Start();
            }
            catch (Exception)
            {
                tcpListener = null;
                keepRunning = false;
                threadListener = null;                
                return false;
            }

            if (VariabiliGlobali.Globals.isWindowSelected)
            {
                StringBuilder Buff = new StringBuilder(256);
                Win32.GetWindowText(VariabiliGlobali.Globals.hWnd, Buff, 256);
                if (Buff.ToString() == "") {
                    AdminTextMessage message = new AdminTextMessage("Handle di finestra non valida. Impossibile avviare la condivisione del video.", "");
                    VariabiliGlobali.Globals.captureEnabled = false;
                    this.ScreenSharingWindowOpen = false;
                    UpdateEvent(this, new UpdateLogBoxArgs(message));
                } else {
                    VariabiliGlobali.Globals.captureEnabled = true;
                    sharedScreen = new SharedScreen(this, wait, VariabiliGlobali.Globals.showSharedScreen);
                    this.StopSharingScreen += new StopSharedScreenHandler(sharedScreen.StopSharingScreen);
                }
            } else {
                VariabiliGlobali.Globals.captureEnabled = true;
                sharedScreen = new SharedScreen(this, wait, VariabiliGlobali.Globals.showSharedScreen);
                this.StopSharingScreen += new StopSharedScreenHandler(sharedScreen.StopSharingScreen);
            }
            return true;
        }

        private void KeepListening()
        {
            while (keepRunning)
            {
                if (!tcpListener.Pending())
                {
                    Thread.Sleep(50);
                    SendOK();
                    continue;
                }
                else
                {
                    tcpClient = tcpListener.AcceptTcpClient();
                    Conn.Add(new Connection(this, tcpClient, wait));                    
                }
            }
            tcpListener.Stop();
            wait.Set();
        }

        private void SendOK()
        {
            TcpClient[] clients = new TcpClient[Users.Count];
            Users.Values.CopyTo(clients, 0);
            AdminTextMessage message = new AdminTextMessage("OK", "Server");
            for (int i = 0; i < clients.Length; i++)
            {
                try {
                    SendToClient(message, clients[i]);
                } catch (Exception) { }
            }
        }

        public void AbleDisableScreenSharing(bool AbleDisableForIconicWindow, bool play)
        {
            AdminTextMessage message = null;

            if (AbleDisableForIconicWindow)
            {
                if (play) {
                    message = new AdminTextMessage("<PLAY>", "Server");
                    UpdateEvent(this, new UpdateLogBoxArgs(new AdminTextMessage("--> Condivisione dello schermo abilitata: finestra riaperta -->", "")));
                } else {
                    message = new AdminTextMessage("<PAUSE>", "Server");
                    UpdateEvent(this, new UpdateLogBoxArgs(new AdminTextMessage("--> Condivisione dello schermo disabilita: finestra ridotta ad icona -->", "")));
                }
            }
            else
            {
                if (!VariabiliGlobali.Globals.captureEnabled) {
                    message = new AdminTextMessage("<PLAY>", "Server");
                    UpdateEvent(this, new UpdateLogBoxArgs(new AdminTextMessage("--> Condivisione dello schermo abilitata -->", "")));
                    VariabiliGlobali.Globals.captureEnabled = true;
                } else {
                    message = new AdminTextMessage("<PAUSE>", "Server");
                    UpdateEvent(this, new UpdateLogBoxArgs(new AdminTextMessage("--> Condivisione dello schermo disabilitata -->", "")));
                    VariabiliGlobali.Globals.captureEnabled = false;
                }
            }

            TcpClient[] clients = new TcpClient[Users.Count];
            Users.Values.CopyTo(clients, 0);
            for (int i = 0; i < clients.Length; i++)
            {
                try {
                    if (clients[i] == null) continue;
                    SendToClient(message, clients[i]);
                } catch {
                    RemoveUser(clients[i]);
                }
            }
        }

        public void CloseAllConnections()
        {
            if (this.ScreenSharingWindowOpen)
            {
                StopSharingScreen(this, null);
                wait.WaitOne();
            }
            foreach (Connection c in Conn)
                if (c.StopConnection())
                    wait.WaitOne();

            Conn.Clear();
            Users.Clear();
            Connections.Clear();
            this.keepRunning = false;
            wait.WaitOne();
        }

        public void CloseScreenSharing(object sender, EventArgs e)
        {
            this.ScreenSharingWindowOpen = false;
            AdminTextMessage message = new AdminTextMessage("--> Condivisione dello schermo fermata -->", "");
            UpdateEvent(this, new UpdateLogBoxArgs(message));
            VariabiliGlobali.Globals.captureEnabled = false;

            message = new AdminTextMessage("<PAUSE>", "Server");
            TcpClient[] clients = new TcpClient[Users.Count];
            Users.Values.CopyTo(clients, 0);

            for (int i = 0; i < clients.Length; i++)
            {
                try {
                    if (clients[i] == null) continue;
                    SendToClient(message, clients[i]);
                } catch {
                    RemoveUser(clients[i]);
                }
            }
        }
    }
}
