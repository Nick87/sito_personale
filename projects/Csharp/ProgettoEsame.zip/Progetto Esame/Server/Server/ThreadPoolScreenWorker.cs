﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Threading;
using System.IO;
using System.Drawing.Imaging;

namespace Server
{
    public class ThreadPoolScreenWorker
    {
        public bool isChanged;
        public Bitmap bitmapChanged;
        private ManualResetEvent doneEvent;

        public ThreadPoolScreenWorker(ManualResetEvent _event, Object arg)
        {
            Rectangle sourceRect = (Rectangle)arg;
            this.doneEvent = _event;
            this.isChanged = false;
            try
            {
                this.bitmapChanged = new Bitmap(sourceRect.Width, sourceRect.Height);
            }
            catch (Exception) { }
        }

        public void ThreadPoolCallback(Object arg)
        {
            Rectangle sourceRect = (Rectangle)arg;

            lock (VariabiliGlobali.Globals.screen_mutex)
            {
                if (VariabiliGlobali.Globals.screen_old != null)
                {
                    Bitmap bmp = new Bitmap(sourceRect.Width, sourceRect.Height);
                    Bitmap bmp_old = new Bitmap(sourceRect.Width, sourceRect.Height);

                    try
                    {
                        bmp = (Bitmap)VariabiliGlobali.Globals.screen.Clone(sourceRect, VariabiliGlobali.Globals.screen.PixelFormat);
                        this.bitmapChanged = (Bitmap)bmp.Clone();
                    }
                    catch (Exception) { }
                    if (VariabiliGlobali.Globals.old_size == sourceRect.Size)
                    {
                        bmp_old = (Bitmap)VariabiliGlobali.Globals.screen_old.Clone(sourceRect, VariabiliGlobali.Globals.screen_old.PixelFormat);

                        MemoryStream ms = new MemoryStream();
                        bmp.Save(ms, ImageFormat.Bmp);
                        byte[] ScreenBytes = ms.GetBuffer();
                        bmp.Dispose();
                        ms.Close();

                        MemoryStream ms_old = new MemoryStream();
                        bmp_old.Save(ms_old, ImageFormat.Bmp);
                        byte[] ScreenOldBytes = ms_old.GetBuffer();
                        bmp_old.Dispose();
                        ms_old.Close();

                        for (int i = 0; i < ScreenBytes.Length; i++)
                        {
                            if (ScreenBytes[i] != ScreenOldBytes[i])
                            {
                                this.isChanged = true;
                                break;
                            }
                        }
                    }
                    else this.isChanged = true;
                    
                    
                }
            }
            this.doneEvent.Set();
        }
    }
}
