#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <signal.h>
#include <netdb.h>
#include <unistd.h>
#include <pthread.h>

#define BUFF_SIZE      500

typedef void SigFunc (int);
void set_handler (int, SigFunc);
void error(char *) __attribute__ ((noreturn));
void my_getline (char *, int);
void * receive (void *);

int main(int argc, char *argv[])
{
	pthread_t thread_id;
	int sockfd, portno;
	struct sockaddr_in serv_addr;
	struct hostent *server;
	char buffer[BUFF_SIZE] = {0};
	if (argc < 3){
		fprintf(stderr,"usage %s hostname port\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	portno = atoi(argv[2]);
	if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		error("ERROR opening socket");
	if((server = gethostbyname(argv[1])) == NULL){
		herror("ERROR on gethostbyname");
		exit(EXIT_FAILURE);
	}

	bzero((char *) &serv_addr, sizeof(serv_addr));
	bcopy((char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(portno);
	
	//signal(SIGINT, SIG_IGN); signal handler non resettato(?)
	set_handler(SIGINT, SIG_IGN); /* Ignora Ctrl-C */
	set_handler(SIGTSTP, SIG_IGN);/* Ignora Ctrl-Z */
	//SIGABRT non viene mascherato

	if (connect(sockfd,(struct sockaddr*)&serv_addr,sizeof(serv_addr)) < 0) 
		error("ERROR on connecting");
	pthread_create(&thread_id, NULL, receive, (void *)&sockfd);

	while(1)
	{
		my_getline (buffer, BUFF_SIZE);
		if(send(sockfd, buffer, strlen(buffer)+1, 0) < 0)
			error("ERROR writing to socket");
		bzero(buffer, BUFF_SIZE);
	}
	return EXIT_SUCCESS;
}

void error(char *msg)
{
	perror(msg);
	exit(EXIT_FAILURE);
}

void my_getline (char * s, int lim)
{
	int i;
	char c;
	for (i = 0; i < lim - 1 && (c = getchar()) != '\n'; i++)
		s[i] = c;
	s[i++] = '\0';
}

void set_handler (int signo, SigFunc handler)
{
	/* Utilizziamo sa_handler, non sa_sigaction, pertanto
	   non utilizziamo il flag SA_SIGINFO.
	   Il segnale passato come argomento viene mascherato
	   di default, a meno che non si utilizzi il flag
	   SA_NODEFER o SA_NOMASK in sa_flags */

	struct sigaction act;
	memset(&act, 0, sizeof(act));
	act.sa_handler = handler;
	//act.sa_flags = SA_NODEFER; non ha effetto
	if(sigaction(signo, &act, NULL) == -1)
		error("ERROR on sigaction");
}

void * receive (void * sock)
{
	int ret, socket = *((int*)sock);
	char buffer[BUFF_SIZE] = {0};
	while(1)
	{
		if((ret = recv(socket, buffer, BUFF_SIZE, 0)) <= 0)
		{
			if(ret == 0)
			{
				if (close(socket) < 0)
					error("ERROR on closing connection");
				else
					printf("Connessione chiusa correttamente\n");
				exit(EXIT_SUCCESS);
			}
			else
				error("ERROR on recv");
		}
		printf("%s\n", buffer);
		bzero(buffer, BUFF_SIZE);
	}
	return NULL;
}
