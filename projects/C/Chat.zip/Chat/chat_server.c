#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define BUFF_SIZE      500
#define LIST_SEQUENCE  "::list"
#define EXIT_SEQUENCE  "::esci"
#define INFO_SEQUENCE  "::info"
#define MAX_CLIENTS    5
#define TRUE           1
#define FALSE          0
#define ENTER          1
#define EXIT           0

typedef struct __client
{
	int fd;
	char nickname[BUFF_SIZE];
}client;

void make_info (char *, int flag);
void make_list (char *, client **, int);
void init_timer (struct timeval *, long, long);
void client_enter_exit (int, int, int, fd_set *, client **, int);
void remove_client (int, client **, int);
void insert_client (int, char *, client **);
void concat (char *, char *, int, client **, int);
void init_clients (client **);
void error (char *) __attribute__ ((noreturn));
int  is_private (char *, int *, client **, int);
int  is_used (char *, client **);
int  is_fake (char *, client **, int *, int);
int  check_colon (char *);

int main(int argc, char * argv[])
{
	fd_set master, read_fds;
	struct timeval timeout;
	struct sockaddr_in serv_addr, cli_addr;
	int listener, newfd, portno, clilen, fdmax, i, j, nbytes, ret, nclients = 0;
	int sec_timeout = 60, reuseaddr = TRUE;
	char buffer[BUFF_SIZE];
	bzero(buffer, BUFF_SIZE);
	client * clients[MAX_CLIENTS];

	if (argc != 2 && argc != 3){
		fprintf(stderr, "Wrong number of input parameters\n");
		fprintf(stderr, "Usage: <command> port [sec_timeout (default %d)]\n", sec_timeout);
		exit(EXIT_FAILURE);
	}
	if(argc == 3)
		sec_timeout = atoi(argv[2]);

	if((listener = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		error("ERROR opening socket");
	if(setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, &reuseaddr, sizeof(int)) == -1)
		error("ERROR setting socket");

	bzero((char *) &serv_addr, sizeof(serv_addr));
	portno = atoi(argv[1]);
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons(portno);

	if(bind(listener,(struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) 
		error("ERROR on binding");
	if(listen(listener, 5) < 0)
		error("ERROR on listening. ");
	printf("Server in ascolto\n");
	
	init_clients(clients);
	init_timer(&timeout, sec_timeout, 0);
	FD_ZERO(&master);
	FD_ZERO(&read_fds);
	FD_SET(listener, &master);
	fdmax = listener;

	while(1)
	{
		read_fds = master;
		ret = select(fdmax + 1, &read_fds, NULL, NULL, &timeout);
		/* Ad ogni nuovo evento (arrivo nuovo client, ricezione dati da un client),
		   resetto il timer */
		init_timer(&timeout, sec_timeout, 0);
		if(ret <= 0)
		{
			if(ret == -1)
				error("ERROR on select");
			//Timeout (ret = 0)
			else
			{
				//Chiudiamo la connessione di tutti i client
				if(nclients > 0)
				{
					printf("<Timeout. Chiusura di %d connession%c!>\n", nclients, nclients == 1 ? 'e' : 'i');
					for(i = 0; i <= fdmax; i++)
					{
						if(FD_ISSET(i, &master) && i != listener)
						{
							char msg[] = "<Timeout!>";
							if(send(i, msg, strlen(msg)+1, 0) == -1)
								error("ERROR on send");
							if(close(i) < 0)
								error("ERROR on closing connection");
							else
								printf("Connessione sulla socket %d chiusa correttamente\n", i);
							FD_CLR(i, &master);
							nclients--;
							remove_client(i, clients, TRUE);
						}
					}
				}
				/* La connessione con i client e' stata chiusa,
				   quindi non faccio il ciclo for di dopo*/
				continue;//while(1)
			}
		}

		for(i = 0; i <= fdmax; i++)
		{
			if(FD_ISSET(i, &read_fds))
			{
				//Un nuovo client
				if(i == listener)
				{
					if(nclients >= MAX_CLIENTS)
					{
						char quit[] = "Numero massimo client raggiunto. Connessione rifiutata!";
						if((newfd = accept(listener, (struct sockaddr *)&cli_addr, (socklen_t *)&clilen)) == -1)
							error("ERROR on accept");
						if(send(newfd, quit, strlen(quit)+1, 0) == -1)
							error("ERROR on send");
						if(close(newfd) < 0)
							error("ERROR on closing connection");
						else
							printf("Connessione sulla socket %d chiusa correttamente\n", i);
						break;
					}
					clilen = sizeof(struct sockaddr_in);
					if((newfd = accept(listener, (struct sockaddr *)&cli_addr, (socklen_t *)&clilen)) == -1)
						error("ERROR on accept");
					else
					{
						char login[BUFF_SIZE];
						char nick[BUFF_SIZE];
						bzero(login, BUFF_SIZE);
						bzero(nick, BUFF_SIZE);

						make_info(login, TRUE);

						if(newfd > fdmax)
							fdmax = newfd;
						printf("Server: nuova connessione da %s sulla socket %d\n", inet_ntoa(cli_addr.sin_addr), newfd);

						while(1)
						{
							//Chiediamo il nickname al client appena arrivato
							if(send(newfd, login, strlen(login)+1, 0) == -1)
								error("ERROR on send");
							if((nbytes = recv(newfd, nick, BUFF_SIZE, 0)) <= 0)//Errore di ricezione
							{
								if(nbytes == 0)
									printf("Server: socket %d chiusa\n", newfd);
								else
									error("ERROR on recv");
								if(close(newfd) < 0)
									error("ERROR on closing connection");
								else
									printf("Connessione sulla socket %d chiusa correttamente\n", newfd);
								break;
							}
							//Nel caso il nickname e' la sequenza di uscita, il client esce subito
							if(strcmp(nick, EXIT_SEQUENCE) == 0)
							{
								printf("Chiusura connessione sulla socket %d\n", newfd);
								if(close(newfd) < 0)
									error("ERROR on closing connection");
								else
									printf("Connessione chiusa correttamente\n");
								continue;
							}
							//Il client vuole la lista completa dei client
							if(strcmp(nick, LIST_SEQUENCE) == 0)
							{
								char list[BUFF_SIZE];
								bzero(list, BUFF_SIZE);
								make_list(list, clients, nclients);
								if(send(newfd, list, strlen(list)+1, 0) == -1)
									error("ERROR on send");
								continue;
							}
							/* Se il client vuole le informazioni non facciamo niente,
							   le informazioni alla prossima iterazione del while(1)
							   vengono visualizzare lo stesso.
							   Cosi' facendo evitiamo di far comparire il messaggio:
							   <Nickname non valido!> */
							if(strcmp(nick, INFO_SEQUENCE) == 0)
							{
								if(send(newfd, "\n", 2, 0) == -1)
									error("ERROR on send");
								continue;
							}
							//Controlliamo che non ci siamo ':' nel nickname
							if(check_colon(nick))
							{
								if(send(newfd, "<Nickname non valido!>\n", 24, 0) == -1)
									error("ERROR on send");
								continue;
							}
							//Controlliamo che il nick non sia utilizzato
							if(is_used(nick, clients))
							{
								if(send(newfd, "<Nickname esistente!>\n", 23, 0) == -1)
									error("ERROR on send");
								continue;
							}
							//Adesso possiamo aggiungere il client con il suo nickname
							FD_SET(newfd, &master);
							nclients++;
							insert_client(newfd, nick, clients);
							client_enter_exit(newfd, fdmax, listener, &master, clients, ENTER);
							break;//while(1) interno
						}
					}
				}
				//Dati da un client
				else
				{
					//Errore di ricezione
					if((nbytes = recv(i, buffer, BUFF_SIZE, 0)) <= 0)
					{
						if(nbytes == 0)
							printf("Server: socket %d chiusa\n", i);
						else
							error("ERROR on recv");
						if(close(i) < 0)
							error("ERROR on closing connection");
						else
							printf("Connessione sulla socket %d chiusa correttamente\n", i);
						client_enter_exit(i, fdmax, listener, &master, clients, EXIT);
						FD_CLR(i, &master);
						nclients--;
						remove_client(i, clients, FALSE);
					}
					//Il client vuole chiudere
					else if(strcmp(buffer, EXIT_SEQUENCE) == 0)
					{
						printf("Chiusura connessione sulla socket %d\n", i);
						if(close(i) < 0)
							error("ERROR on closing connection");
						else
							printf("Connessione chiusa correttamente\n");
      					
						client_enter_exit(i, fdmax, listener, &master, clients, EXIT);
						FD_CLR(i, &master);
						nclients--;
						remove_client(i, clients, FALSE);
					}
					//Il client vuole la lista completa dei client
					else if(strcmp(buffer, LIST_SEQUENCE) == 0)
					{
						char list[BUFF_SIZE];
						bzero(list, BUFF_SIZE);
						make_list(list, clients, nclients);
						if(send(i, list, strlen(list)+1, 0) == -1)
							error("ERROR on send");
					}
					//Il client vuole le informazioni
					else if(strcmp(buffer, INFO_SEQUENCE) == 0)
					{
						char info[BUFF_SIZE];
						bzero(info, BUFF_SIZE);
						make_info(info, FALSE);
						if(send(i, info, strlen(info)+1, 0) == -1)
							error("ERROR on send");
					}
					//Messaggio dal client
					else
					{
						int fd;
						/* Controlliamo se e' un client che si vuole
						   fingere un altro client */
						if(is_fake(buffer, clients, &fd, i))
						{
							for(j = 0; j <= fdmax; j++)
							{
								if(FD_ISSET(j, &master) && j != listener && j != i)
								{
									char header[BUFF_SIZE];
									bzero(header, BUFF_SIZE);
									/* Concateno il nickname corrispondente alla socket
									   fd (no i il vero mittente), cioe' del client
									   il cui nickname e' stato rubato */
									concat(header, buffer, fd, clients, FALSE);
									if(send(j, header, strlen(header)+1, 0) == -1)
										error("ERROR on send");
								}
							}
						}
						/* Non e' un messaggio falso, ma puo' essere privato o
						   semplice */
						else
						{
							/* e' un messaggio privato a tutti gli effetti,
							   mando soltanto a fd */
							int ret = is_private(buffer, &fd, clients, i);
							if(ret > 0)
							{
								char header[BUFF_SIZE];
								bzero(header, BUFF_SIZE);
								concat(header, buffer, i, clients, TRUE);
								if(send(fd, header, strlen(header)+1, 0) == -1)
									error("ERROR on send");
							}
							//non e' un messaggio privato, mando a tutti
							else if(ret < 0)
							{
								for(j = 0; j <= fdmax; j++)
								{
									if(FD_ISSET(j, &master) && j != listener && j != i)
									{
										char header[BUFF_SIZE];
										bzero(header, BUFF_SIZE);
										concat(header, buffer, i, clients, FALSE);
										if(send(j, header, strlen(header)+1, 0) == -1)
											error("ERROR on send");
									}
								}
							}
						}
					}
				}
			}
		}
	}
	return EXIT_SUCCESS; 
}

void error (char *msg)
{
	perror(msg);
	exit(EXIT_FAILURE);
}

void init_timer (struct timeval * timer, long sec, long usec)
{
	timer->tv_sec  = sec;
	timer->tv_usec = usec;
}

void init_clients (client ** c)
{
	int i;
	for(i = 0; i < MAX_CLIENTS; i++)
		c[i] = NULL;
}

void insert_client (int file_des, char * name, client ** clients)
{
	int i;
	for(i = 0; i < MAX_CLIENTS; i++)
	{
		if(clients[i] == NULL)
		{
			clients[i] = (client *) malloc(sizeof(client));
			clients[i]->fd = file_des;
			strcpy(clients[i]->nickname, name);
			printf("Aggiunto client \"%s\" sulla socket %d\n", clients[i]->nickname, clients[i]->fd);
			break;
		}
	}
}

/* se flag == TRUE il client e' rimosso per avvenuto timeout */
void remove_client (int file_des, client ** c, int flag)
{
	int i, file_d;
	char name[BUFF_SIZE];
	bzero(name, BUFF_SIZE);
	for(i = 0; i < MAX_CLIENTS; i++)
	{
		if(c[i] != NULL && c[i]->fd == file_des)
		{
			strcpy(name, c[i]->nickname);
			file_d = c[i]->fd;
			free(c[i]);
			c[i] = NULL;
			if(flag)
				printf("Rimosso client \"%s\" sulla socket %d per timeout\n", name, file_d);
			else
				printf("Rimosso client \"%s\" sulla socket %d\n", name, file_d);
			break;
		}
	}
}

/* se flag == TRUE e' un'entrata */
void client_enter_exit (int file_des, int max_filedes, int server, fd_set * set, client ** c, int flag)
{
	int i, j, check = FALSE;
	char msg[BUFF_SIZE] = "<";

	for(i = 0; i < MAX_CLIENTS; i++)
	{
		if(c[i] != NULL && c[i]->fd == file_des)
		{
			strcat(msg, c[i]->nickname);
			if(flag == ENTER)
				strcat(msg, " entra nella chat!>");
			else
				strcat(msg, " esce dalla chat!>");
			for(j = 0; j <= max_filedes; j++)
			{
				if(FD_ISSET(j, set) && j != server && j != file_des)
				{
					if(send(j, msg, strlen(msg)+1, 0) == -1)
						error("ERROR on send");
					check = TRUE;
				}
			}
			if(check)
				break;
		}
	}
}

/* Se flag == TRUE, il messaggio e' privato */
void concat (char * str, char * buf, int file_des, client ** c, int flag)
{
	int i;

	strcpy(str, "<");
	for(i = 0; i < MAX_CLIENTS; i++)
		if(c[i] != NULL)
			if(c[i]->fd == file_des){
				strcat(str, c[i]->nickname);
				break;
			}

	if(flag)
		strcat(str, " dice:P> ");
	else
		strcat(str, " dice> ");
	strcat(str, buf);
}

int is_used (char * nick, client ** c)
{
	int i;
	for(i = 0; i < MAX_CLIENTS; i++)
		if(c[i] != NULL)
			if(strcmp(nick, c[i]->nickname) == 0)
				return TRUE;
	return FALSE;
}

int check_colon (char * nick)
{
	int i;
	for(i = 0; nick[i] != '\n' && nick[i] != '\0'; i++)
		if(nick[i] == ':')
			return TRUE;
	return FALSE;
}

/* caller:   socket descriptor del client chiamante, per evitare
		 che un client mandi un messaggio privato a se stesso*/
/* @return:  0 se il nick corrisponde a quello del chiamante
             1 se il nick esiste ed e' diverso da quello del chiamante
            -1 in tutti gli altri casi */ 
int is_private (char * str, int * file_des, client ** c, int caller)
{
	int i, length, index, check = FALSE, count = 0;
	char nick[BUFF_SIZE];
	bzero(nick, BUFF_SIZE);

	/* Controlliamo che sia presente "almeno" due volte il carattere ':',
	   di cui la prima occorrenza e' il primo carattere.
	   Poi verifichiamo se la stringa al suo interno, cioe' il nickname,
	   corrisponde ad un client connesso */
	if(str[0] != ':')
		return -1;
	/* Ricontiamo anche il primo ':' e conserviamo, per comodita', l'indice
	   in cui si trova, se c'e', il secondo ':'*/
	for(i = 0; str[i] != '\n' && str[i] != '\0'; i++)
		if(str[i] == ':')
			if(++count == 2)
				index = i;
	if(count < 2)
		return -1;
	length = i-1;
	
	//Adesso isoliamo il nickname	
	memcpy(nick, str+1, index-1);
	nick[index] = '\0';

	//Vediamo se esiste
	for(i = 0; i < MAX_CLIENTS; i++)
	{
		if(c[i] != NULL && strcmp(nick, c[i]->nickname) == 0)
		{
			if(c[i]->fd == caller){
				printf("Client \"%s\" manda un messaggio privato a se stesso. Messaggio non inoltrato.\n", c[i]->nickname);	
				check = TRUE;
			}
			/* Togliamo ":[nickname]:" dalla stringa
			   "accartocciandola" su se stessa*/
			memcpy(str, str+index+1, length-index);
			str[length-index] = '\0';
			*file_des = c[i]->fd;
			return ((check) ? 0 : 1);
		}
	}
	return -1;
}

/* Un messaggio falso e' del tipo:
   ::[nickname]:[messaggio].
   fake_nick: se il messaggio e' falso, fake_nick contiene il nickname
   		  "rubato"
   caller:    socket descriptor del client chiamante.
		  se il chiamante finge di essere se stesso il messaggio
		  viene mandato normalmente */
int is_fake (char * str, client ** c, int * fake_nick, int caller)
{
	int i, length, index, count = 0;
	char nick[BUFF_SIZE];
	bzero(nick, BUFF_SIZE);

	/* Controlliamo che sia presente "almeno" tre volte il carattere ':',
	   di cui la prime due occorrenza siamo il primo ed il secondo carattere.
	   Poi verifichiamo se la stringa al suo interno, cioe' il nickname,
	   corrisponde ad un client connesso */
	if(str[0] != ':' && str[1] != ':')
		return FALSE;
	/* Ricontiamo anche i primi due ':' e conserviamo, per comodita', l'indice
	   in cui si trova, se c'e', il terzo ':'*/
	for(i = 0; str[i] != '\n' && str[i] != '\0'; i++)
		if(str[i] == ':')
			if(++count == 3)
				index = i;
	if(count < 3)
		return FALSE;
	length = i-1;	

	//Adesso isoliamo il nickname	
	memcpy(nick, str+2, index-2);
	nick[index-2] = '\0';

	//Vediamo se esiste
	for(i = 0; i < MAX_CLIENTS; i++)
	{
		if(c[i] != NULL && strcmp(nick, c[i]->nickname) == 0)
		{
			if(c[i]->fd == caller)
				printf("Client \"%s\" si finge se stesso. Messaggio inoltrato normalmente.\n", c[i]->nickname);
			/* Togliamo "::[nickname]:" dalla stringa
			   "accartocciandola" su se stessa*/
			memcpy(str, str+index+1, length-index);
			str[length-index] = '\0';
			*fake_nick = c[i]->fd;
			return TRUE;
		}
	}
	return FALSE;
}

void make_list (char * str, client ** c, int n_clients)
{
	int i;
	
	strcpy(str, "\n");
	if(n_clients == 0)
		strcat(str, "- Lista client vuota\n");
	else
	{
		for(i = 0; i < MAX_CLIENTS; i++)
		{
			if(c[i] != NULL)
			{
				strcat(str, "- ");
				strcat(str, c[i]->nickname);
				strcat(str, "\n");
			}
		}
	}
}

/* se flag == TRUE, le info sono mostrare al login */
void make_info (char * info, int flag)
{
	strcpy(info, "\nISTRUZIONI CHAT:\n");
	strcat(info, "- ");
	strcat(info, EXIT_SEQUENCE);
	strcat(info, " per uscire in qualunque momento\n");
	strcat(info, "- ");
	strcat(info, LIST_SEQUENCE);
	strcat(info, " avere la lista dei client connessi\n");
	strcat(info, "- ");
	strcat(info, INFO_SEQUENCE);
	strcat(info, " per visualizzare questo help\n");
	strcat(info, "- :[nickname]: \"MESSAGGIO\" per un messaggio privato all'utente [nickname]\n");
	strcat(info, "- ::[nickname]:\"MESSAGGIO\" per fingersi l'utente [nickname]\n");
	if(flag)
		strcat(info, "Inserire nickname (il carattere \":\" non e' ammesso):");	
}
