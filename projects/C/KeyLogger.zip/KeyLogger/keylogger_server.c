#ifndef WIN32_LEAN_AND_MEAN
    #define WIN32_LEAN_AND_MEAN
#endif

#include <stdio.h>
#include <stdlib.h>
#include <winsock.h>
#include <windows.h>

#define DEFAULT_PORT      "12345"
//Path relativo %HOMEDRIVE%\%HOMEPATH%%
#define DIR_NAME          "\\Desktop\\LOG FILES"

SOCKET newsock = INVALID_SOCKET;
char date[11];
char time[6];
char base_path[200];//HOMEDRIVE+HOMEPATH+DIR_NAME

void get_date(void);
void get_time(void);
void fix_strings(char *, char *);
int  receive_all(char *, long);

int main(int argc, char ** argv)
{
    FILE * file, * log;
    struct sockaddr_in serv_addr, cli_addr;
    SOCKET listener;
    WSADATA wsaData;
    int i, err, size = sizeof(struct sockaddr_in);
    long file_size;
    char * buffer;
    char temp[200], buf[20];
    
    GetEnvironmentVariable("HOMEDRIVE", base_path, 200);
    GetEnvironmentVariable("HOMEPATH", temp, 200);
     
    strcat(base_path, temp);
    strcat(base_path, DIR_NAME);
    //Creo la directory
    CreateDirectory(base_path, NULL);
    
    sprintf(temp, "%s\\log.txt", base_path);
    if((log = fopen(temp, "w")) == NULL)
       exit(EXIT_FAILURE);
    ZeroMemory(temp, 200);
    
    if ((err = WSAStartup(MAKEWORD(2,2), &wsaData)) != 0){
        printf("Error %d at WSAStartup()\n", err);
        fprintf(log, "Error %d at WSAStartup()\n", err);
        fflush(log);
        return EXIT_FAILURE;
    }
    
    if((listener = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET){
        printf("Error %d at socket()\n", WSAGetLastError());
        fprintf(log, "Error %d at socket()\n", WSAGetLastError());
        fflush(log);
        return EXIT_FAILURE;
    }
    
    ZeroMemory(&serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons(atoi(DEFAULT_PORT));
	
	if(bind(listener, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) == SOCKET_ERROR){
        printf("Error %d at bind()\n", WSAGetLastError());
        fprintf(log, "Error %d at bind()\n", WSAGetLastError());
        fflush(log);
        closesocket(listener);
        WSACleanup();
        return EXIT_FAILURE;
    }
	
	if (listen(listener, SOMAXCONN) == SOCKET_ERROR){
        printf("Error %d at listen()\n", WSAGetLastError());
        fprintf(log, "Error %d at listen()\n", WSAGetLastError());
        fflush(log);
        closesocket(listener);
        WSACleanup();
        return EXIT_FAILURE;
    }
    printf("Server in ascolto\n");
    fprintf(log, "Server in ascolto\n");
    fflush(log);

    if((newsock = accept(listener, (struct sockaddr *)&cli_addr, &size)) == INVALID_SOCKET){
        printf("Error %d at accept()\n", WSAGetLastError());
        fprintf(log, "Error %d at accept()\n", WSAGetLastError());
        fflush(log);
        closesocket(listener);
        WSACleanup();
        return EXIT_FAILURE;
    }
    closesocket(listener);
    
	while(1)
	{  
       get_date();
       get_time();
       //Riceviamo il tipo di file, se html o txt, e la dimensione
       if(recv(newsock, buf, 20, 0) == SOCKET_ERROR)
       {
           err = WSAGetLastError();
           if(err = WSAECONNRESET){
               printf("Error %d at recv(): Connection reset by peer\n", err);
               fprintf(log, "Error %d at recv(): Connection reset by peer\n", err);
               fflush(log);
               fclose(log);
               WSACleanup();
               exit(EXIT_FAILURE);
           }else{
               printf("Error %d at recv()\n", err);
               fprintf(log, "Error %d at recv()\n", err);
               fflush(log);
               continue;
           }
           
       }       
       printf("Incoming log from %s on socket %d at %s - %s\n", inet_ntoa(cli_addr.sin_addr), newsock, date, time);	
       fprintf(log, "Incoming log from %s on socket %d at %s - %s\n", inet_ntoa(cli_addr.sin_addr), newsock, date, time);
       fflush(log);
       
       //Invio ack
       send(newsock, "1", 2, 0);
       
       //I nomi dei file non possono contenere tra i caratteri '/' e ':'
       fix_strings(date, time);
       
       if(buf[0] == '1')
           sprintf(temp, "%s\\%s - %s.html", base_path, date, time);
       else if(buf[0] == '0')
           sprintf(temp, "%s\\%s - %s.txt", base_path, date, time);
       else 
           continue;
       
       if((file = fopen(temp, "w")) == NULL)
       {
           printf("Error at opening %s\n", temp);
           fprintf(log, "Error at opening %s\n", temp);
           fflush(log);
           continue;
       }
       
       for(i = 1; i < 20; i++)
          buf[i-1] = buf[i];
       
       file_size = atoi(buf);
	   buffer = malloc(file_size);
	   ZeroMemory(temp, 200);
	   
	   if(receive_all(buffer, file_size) < 0){
           printf("Error at receive_all()\n");
           fprintf(log, "Error at receive_all()\n");
           fflush(log);
           continue;
       }
	   fwrite(buffer, 1, file_size, file);
	   fclose(file);
	   free(buffer);
	   ZeroMemory(buf, 20);
    }
	WSACleanup();
	fclose(log);
	return EXIT_SUCCESS;
}

void get_date(void)
{
     SYSTEMTIME st;
     GetLocalTime(&st);
     sprintf(date, "%02d/%02d/%04d", st.wDay, st.wMonth, st.wYear);
}

void get_time(void)
{
     SYSTEMTIME st;
     GetLocalTime(&st);
     sprintf(time, "%02d:%02d", st.wHour, st.wMinute);
}

void fix_strings (char * date, char * time)
{
     int i;
     for(i = 0; i < 11; i++)
        if(date[i] == '/')
           date[i] = '.';
    for(i = 0; i < 6; i++)
        if(time[i] == ':')
           time[i] = '.';
}

int receive_all(char * buf, long size)
{
    int n, received = 0, left_to_receive = size;
    while(received < left_to_receive)
    {
        if((n = recv(newsock, buf+received, left_to_receive, 0)) == SOCKET_ERROR)
            return -1;
        received += n;
        left_to_receive -= n;     
        //Invio ack
        send(newsock, "1", 2, 0);
    }
    return 1;
}
