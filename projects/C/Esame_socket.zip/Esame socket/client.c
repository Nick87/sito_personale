#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <netinet/in.h>
#include <string.h>
#include <time.h>
#include <fcntl.h>
#include <errno.h>

#define TIMEOUT_LIMIT        3
#define MAXLEN               1024
#define MAX_PENDING_COMMANDS 5
#define UNKNOWN       	     0
#define UP                   1
#define DOWN                 2
#define STOP	             3
#define QUIT	             4
#define LS	             5
#define CD	             6
#define PWD                  7
#define RM		     8
#define OVERWRITE	     9
#define RENAME		     10
#define DONOTHING	     11
#define CMD_UP               "UP"
#define CMD_DOWN             "DOWN"
#define CMD_STOP             "STOP"
#define CMD_QUIT             "QUIT"
#define CMD_LS	             "LS"
#define CMD_CD	             "CD"
#define CMD_PWD	             "PWD"
#define CMD_RM	             "RM"
#define CMD_OVERWRITE	     "+OVERWRITE"
#define CMD_RENAME	     "+RENAME"
#define CMD_DONOTHING	     "+DONOTHING"
#define HEADER_SEQ           "SEQ:"
#define HEADER_LENGTH        (1+strlen(HEADER_SEQ)+10+1)
#define BLOCK_SIZE           (MAXLEN-HEADER_LENGTH)
#define TIMEOUT              3
#define OK	             "+OK\n"
#define ERR	             "-ERR"
#define ERRBUSY	             "-ERRBUSY"
#define ERREXISTS            "-ERREXISTS"

extern int errno;
char * prog_name;
char * log_file = "client_log_file";
char pending_commands[MAX_PENDING_COMMANDS][MAXLEN];
int put_next_command_index = 0;
int get_next_command_index = 0;
int n_pending_commands = 0;

void record_download(const char *);
void delete_download();
void recover_from_log_file();
void execute(int, struct sockaddr_in, int);
void menu();
void make_packet(int, int, char *);
void get_filename_from_absolute_path(char *);
int execute_pending_commands(int, int *, int *, struct sockaddr_in, int);
int queue_command(const char *);
int parse_command(char *);
int upload_file(int, int *, int *, const char *, struct sockaddr_in, int);
int download_file(int, int *, int *, const char *, int, struct sockaddr_in, int);
int do_ls(int, int *, int *, struct sockaddr_in, int);
int do_pwd(int, int *, int *, struct sockaddr_in, int);
int do_cd(int, int *, int *, const char *, struct sockaddr_in, int);
int do_rm(int, int *, int *, const char *, struct sockaddr_in, int);
int get_seq_number(const char *);
int get_ack_number(const char *);
int ReliableSendto (int, int *, const char *, int, int, const struct sockaddr *, socklen_t);
int ReliableSend (int, int *, const char *, int, int);
int ReliableRecvfrom(int, int *, char *, int, int, struct sockaddr *, socklen_t *);
int ReliableRecv(int, int *, char *, int, int);
int Recv(int, char *, int, int);
int Recvfrom(int, char *, int, int, struct sockaddr *, socklen_t *);
int Recvtimeout(int, char *, int, int);
int Recvfromtimeout(int, char *, int, int, struct sockaddr *, socklen_t *);
int Send(int, const char *, int, int);
int Sendto(int, const char *, int, int, const struct sockaddr *, socklen_t);

int main(int argc, char *argv[])
{
    int i, sock, port_int;
    unsigned short port;
    struct sockaddr_in servaddr;
    struct hostent * server;
    srand(time(0));
    
    prog_name = argv[0];
    
    if (argc != 3){
	printf("usage: %s <address> <port>\n", prog_name);
	exit(EXIT_FAILURE);
    }

    port_int = atoi(argv[2]);
    if(port_int <= 1024 || port_int > 65535){
	printf("Invalid port number. Valid range is [1025 - 65535]\n");
	exit(EXIT_FAILURE);
    }
    port = (unsigned short) (port_int&0xffff);
    
    recover_from_log_file();
    
    sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if(socket < 0){
	printf("(%s) error on creating socket: %s\n", prog_name, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    server = gethostbyname(argv[1]);
    if(server == NULL){
	printf("(%s) error on gethostbyname() for '%s': %s", prog_name, argv[1], hstrerror(h_errno));
	exit(EXIT_FAILURE);
    }
    
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(port);
    memcpy((char *)&servaddr.sin_addr.s_addr, (char *)server->h_addr, server->h_length);
    
    for(i = 0; i < MAX_PENDING_COMMANDS; i++)
	memset(pending_commands[i], 0, MAXLEN);
    execute(sock, servaddr, sizeof(servaddr));
    
    if(close(sock) != 0){
	printf("(%s) error on closing socket: %s\n", prog_name, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    return 0;
}

void execute(int sock, struct sockaddr_in servaddr, int servaddr_size)
{
    int ret, nRead, nseq = 0, nseq_expected = 0;
    fd_set fds;
    socklen_t servaddrlen = servaddr_size;
    struct sockaddr_in server;
    struct timeval tv;
    char buffer[MAXLEN];
    
    FD_ZERO(&fds);
    FD_SET(sock, &fds);
    tv.tv_sec = TIMEOUT;
    tv.tv_usec = 0;
    
    //Say hello to server
    Sendto(sock, "HELLO", 6, 0, (struct sockaddr *)&servaddr, servaddr_size);
    
    if(select(sock+1, &fds, NULL, NULL, &tv) == 0){
	printf("(%s) error: server unreachable\n", prog_name);
	return;
    }
    
    Recvfrom(sock, buffer, MAXLEN, 0, (struct sockaddr *)&servaddr, &servaddrlen);
    memset(buffer, 0, MAXLEN);
    printf("(%s) new port received from server: %d\n", prog_name, ntohs(servaddr.sin_port));
    
    memcpy(&server, &servaddr, sizeof(server));

    if(connect(sock, (struct sockaddr *) &server, sizeof(server)) != 0){
	printf("(%s) error on connect: %s\n", prog_name, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    while(1)
    {
	if(n_pending_commands > 0){
	    if (execute_pending_commands(sock, &nseq, &nseq_expected, server, servaddr_size) == -1)
		break;
	    else
		continue;
	}
	menu();
	
	//Let's start sending commands
	write(STDOUT_FILENO, "> ", 2);
	nRead = read (STDIN_FILENO, buffer, MAXLEN);
	buffer[nRead] = '\0';
	ret = parse_command(buffer);
	if(ret == QUIT){
	    sprintf(buffer, "%s", CMD_QUIT);
	    make_packet(nseq, strlen(buffer), buffer);
	    ReliableSend(sock, &nseq, buffer, strlen(buffer), 0);
	    return;
	}else if(ret == PWD){
	    if(do_pwd(sock, &nseq, &nseq_expected, server, servaddr_size) == -1)
		break;
	}else if(ret == LS){
	    if(do_ls(sock, &nseq, &nseq_expected, server, servaddr_size) == -1)
		break;
	}else if(ret == CD){
	    if(do_cd(sock, &nseq, &nseq_expected, buffer, server, servaddr_size) == -1)
		break;
	}else if(ret == RM){
	    if(do_rm(sock, &nseq, &nseq_expected, buffer, server, servaddr_size) == -1)
		break;
	}else if(ret == UP){
	    if(upload_file(sock, &nseq, &nseq_expected, buffer, server, servaddr_size) == -1)
		break;
	}else if(ret == DOWN){
	    if(download_file(sock, &nseq, &nseq_expected, buffer, BLOCK_SIZE, server, servaddr_size) == -1)
		break;
	}else if(ret == STOP)
	    printf("STOP command only allowed to abort a download. Type QUIT to exit\n");
	else
	    printf("Unknown or invalid command\n");
    }
}

void get_filename_from_absolute_path(char * path)
{
    int i, index = 0;
    
    for(i = strlen(path)-1; path[i] != '/' && i >= 0; i--);
    if(i < 0) return;
    i++;
    for(; path[i] != '\n' && path[i] != '\0'; i++)
	path[index++] = path[i];
    path[index] = '\0';
}

int parse_command(char * buffer)
{
    char temp[MAXLEN];
    int i, index = 0;
    strncpy(temp, buffer, MAXLEN);
    
    //Let's remove all trailing spaces and '\n'
    for(i = strlen(temp)-1; temp[i] == ' ' || temp[i] == '\n'; i--)
	temp[i] = '\0';
    
    //Let's skip leading spaces
    for(i = 0; temp[i] == ' '; i++);
    //Let's change the command to upper case (even if it is already so)
    for(; temp[i] != ' ' && temp[i] != '\0'; i++)
	if(temp[i] >= 'a' && temp[i] <= 'z')
	    temp[i] -= ('a'-'A');	
	
    if(!strcmp(temp, CMD_STOP))
	return STOP;
    else if(!strcmp(temp, CMD_QUIT))
	return QUIT;
    else if(!strcmp(temp, CMD_LS))
	return LS;
    else if(!strcmp(temp, CMD_PWD))
	return PWD;
    else if(!strcmp(temp, CMD_OVERWRITE) || !strcmp(temp, "O"))
	return OVERWRITE;
    else if(!strcmp(temp, CMD_RENAME) || !strcmp(temp, "R"))
	return RENAME;
    else if(!strcmp(temp, CMD_DONOTHING) || !strcmp(temp, "N"))
	return DONOTHING;
    else if(strstr(temp, CMD_CD))
    {
	if(!strcmp(temp, CMD_CD)){
	    strcpy(buffer, temp);
	    return UNKNOWN;
	}
	
	//Let's skip leading spaces
	for(i = 0; temp[i] == ' '; i++);
	    
	for(; temp[i] != ' '; i++);
	for(; temp[i] == ' '; i++);
	if(temp[i] == '\0'){
	    strcpy(buffer, temp);
	    return UNKNOWN;
	}
	while(temp[i] != '\0')
	    buffer[index++] = temp[i++];
	buffer[index] = '\0';
	return CD;
    }
    else if(strstr(temp, CMD_RM))
    {
	if(!strcmp(temp, CMD_RM)){
	    strcpy(buffer, temp);
	    return UNKNOWN;
	}
	
	//Let's skip leading spaces
	for(i = 0; temp[i] == ' '; i++);
	
	for(; temp[i] != ' '; i++);
	for(; temp[i] == ' '; i++);
	if(temp[i] == '\0'){
	    strcpy(buffer, temp);
	    return UNKNOWN;
	}
	while(temp[i] != '\0')
	    buffer[index++] = temp[i++];
	buffer[index] = '\0';
	return RM;
    }
    else if(strstr(temp, CMD_UP))
    {
	if(!strcmp(temp, CMD_UP)){
	    strcpy(buffer, temp);
	    return UNKNOWN;
	} 
	else
	{
	    //Let's skip leading spaces
	    for(i = 0; temp[i] == ' '; i++);
	    
	    for(; temp[i] != ' '; i++);
	    for(; temp[i] == ' '; i++);
	    if(temp[i] == '\0'){
		strcpy(buffer, temp);
		return UNKNOWN;
	    }
	    while(temp[i] != '\0')
		buffer[index++] = temp[i++];
	    buffer[index] = '\0';
	    return UP;
	}
    }
    else if(strstr(temp, CMD_DOWN))
    {
	if(!strcmp(temp, CMD_DOWN)){
	    strcpy(buffer, temp);
	    return UNKNOWN;
	}
	else
	{
	    //Let's skip leading spaces
	    for(i = 0; temp[i] == ' '; i++);
	    
	    for(; temp[i] != ' '; i++);
	    for(; temp[i] == ' '; i++);
	    if(temp[i] == '\0'){
		strcpy(buffer, temp);
		return UNKNOWN;
	    }
	    while(temp[i] != '\0')
		buffer[index++] = temp[i++];
	    buffer[index] = '\0';
	    return DOWN;
	}
    }
    strcpy(buffer, temp);
    return UNKNOWN;
}

void make_packet(int seq, int len, char * to)
{
    int from_index = 0, to_index = HEADER_LENGTH;
    char temp[MAXLEN];
    memcpy(temp, to, MAXLEN);    
    sprintf(to, "[%s%010d]", HEADER_SEQ, seq);
    while(len-- > 0)
	to[to_index++] = temp[from_index++];
}

int execute_pending_commands(int sock, int * nseq, int * nseq_expected, struct sockaddr_in server, int servaddrlen)
{
    int ret;
    char buffer[MAXLEN];
    
    memset(buffer, 0, MAXLEN);
    strcpy(buffer, pending_commands[get_next_command_index]);
    get_next_command_index = (get_next_command_index+1)%MAX_PENDING_COMMANDS;
    n_pending_commands--;
    
    printf("\n(%s) executing: %s (%d commands left in queue)\n", prog_name, buffer, n_pending_commands);
    
    ret = parse_command(buffer);
    if(ret == QUIT){
	make_packet(*nseq, strlen(CMD_QUIT), buffer);
	ReliableSend(sock, nseq, buffer, strlen(buffer), 0);
	return -1;
    }else if(ret == PWD){
	return do_pwd(sock, nseq, nseq_expected, server, servaddrlen);
    }else if(ret == LS){
	return do_ls(sock, nseq, nseq_expected, server, servaddrlen);
    }else if(ret == CD){
	return do_cd(sock, nseq, nseq_expected, buffer, server, servaddrlen);
    }else if(ret == RM){
	return do_rm(sock, nseq, nseq_expected, buffer, server, servaddrlen);
    }else if(ret == UP){
	return upload_file(sock, nseq, nseq_expected, buffer, server, servaddrlen);
    }else if(ret == DOWN){
	return download_file(sock, nseq, nseq_expected, buffer, BLOCK_SIZE, server, servaddrlen);
    }
    else
	printf("(%s) unknown or invalid command\n", buffer);
    
    return 1;
}

int queue_command(const char * command)
{
    if(n_pending_commands == MAX_PENDING_COMMANDS)
	return 0;
    
    strcpy(pending_commands[put_next_command_index], command);
    put_next_command_index = (put_next_command_index+1)%MAX_PENDING_COMMANDS;
    n_pending_commands++;
    return 1;
}

int upload_file(int sock, int * nseq, int * nseq_expected, const char * file, struct sockaddr_in server, int servaddrlen)
{
    char buffer[MAXLEN], temp[MAXLEN];
    int i, index, fdR, nRead, file_size, ret, cmd, bytes_sent = 0, file_renamed = 0;
    struct stat info;
    struct timeval tv;
    fd_set fds, master;
    
    //Let's check if file exists
    if((fdR = open(file, O_RDONLY)) == -1){
	printf("(%s) error on opening \"%s\": %s\n", prog_name, file, strerror(errno));
	return -2;
    }
    memset(buffer, 0, MAXLEN);
    if(connect(sock, (struct sockaddr *) &server, servaddrlen) != 0){
	printf("(%s) error on connect: %s\n", prog_name, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    strcpy(temp, file);
    get_filename_from_absolute_path(temp);

    //Let's  send the upload command
    sprintf(buffer, "%s %s", CMD_UP, temp);
    make_packet(*nseq, strlen(buffer), buffer);
    if(ReliableSend(sock, nseq, buffer, strlen(buffer), 0) < 0){
	close(fdR);
	return -1;
    }
    memset(buffer, 0, MAXLEN);
    
    //Let's see if we're allowed to upload
    if(ReliableRecv(sock, nseq_expected, buffer, MAXLEN, 0) < 0) return -1;
    
    if(!strcmp(buffer+HEADER_LENGTH, ERR))
    {
	printf("(%s) upload of file \"%s\" denied: an error occurred. Try again\n", prog_name, file);
	close(fdR);
	return -2;
    }
    else if(!strcmp(buffer+HEADER_LENGTH, ERREXISTS))
    {
	printf("(%s) file already exists on server. (O)verwrite, (R)ename or do (N)othing? (Overwrite default)\n", prog_name);
	write (STDOUT_FILENO, "> ", 2);
	while(1)
	{
	    nRead = read (STDIN_FILENO, buffer, MAXLEN);
	    buffer[nRead] = '\0';
	    ret = (!strcmp(buffer, "\n")) ? OVERWRITE : parse_command(buffer);
	    
	    if(ret == OVERWRITE)
	    {
		memset(buffer, 0, MAXLEN);
		sprintf(buffer, "%s", CMD_OVERWRITE);
		make_packet(*nseq, strlen(buffer), buffer);
		if(ReliableSend(sock, nseq, buffer, strlen(buffer), 0) < 0){
		    close(fdR);
		    return -1;
		}
		memset(buffer, 0, MAXLEN);
		if(ReliableRecv(sock, nseq_expected, buffer, MAXLEN, 0) < 0){
		    close(fdR);
		    return -1;
		}
		if(!strcmp(buffer+HEADER_LENGTH, ERR)){
		    printf("(%s) unable to overwrite. File is busy\n", prog_name);
		    close(fdR);
		    return -2;
		}
		break;
	    }
	    else if(ret == RENAME)
	    {
		memset(buffer, 0, MAXLEN);
		sprintf(buffer, "%s", CMD_RENAME);
		make_packet(*nseq, strlen(buffer), buffer);
		if(ReliableSend(sock, nseq, buffer, strlen(buffer), 0) < 0){
		    close(fdR);
		    return -1;
		}
		
		printf("(%s) type a new name for the file\n", prog_name);
		while(1)
		{
		    memset(buffer, 0, MAXLEN);
		    write (STDOUT_FILENO, "> ", 2);
		    nRead = read (STDIN_FILENO, buffer, MAXLEN);
		    buffer[nRead] = '\0';
		    
		    //Let's remove all trailing spaces and '\n'
		    for(i = strlen(buffer)-1; buffer[i] == ' ' || buffer[i] == '\n'; i--)
			buffer[i] = '\0';
		    //Let's skip leading spaces
		    for(i = 0; buffer[i] == ' '; i++);
		    for(index = 0; buffer[i] != '\0'; i++, index++)
			buffer[index] = buffer[i];
		    buffer[index] = '\0';
		    make_packet(*nseq, strlen(buffer), buffer);
		    if(ReliableSend(sock, nseq, buffer, strlen(buffer), 0) < 0){
			close(fdR);
			return -1;
		    }
		    memset(temp, 0, MAXLEN);
		    strcpy(temp, buffer+HEADER_LENGTH);
		    memset(buffer, 0, MAXLEN);
		    if(ReliableRecv(sock, nseq_expected, buffer, MAXLEN, 0) < 0) return -1;
		    if(!strcmp(buffer+HEADER_LENGTH, ERREXISTS))
			printf("(%s) file already exists on server. Type a new name\n", prog_name);
		    else{
			file_renamed = 1;
			goto begin_upload;
		    }
		}
	    }
	    else if(ret == DONOTHING)
	    {
		close(fdR);
		memset(buffer, 0, MAXLEN);
		sprintf(buffer, "%s", CMD_DONOTHING);
		make_packet(*nseq, strlen(buffer), buffer);
		if(ReliableSend(sock, nseq, buffer, strlen(buffer), 0) < 0){
		    return -1;
		}else{
		    return -2;
		}
	    }
	    else
	    {
		printf("(%s) %s: unknown command. Type again\n", prog_name, buffer);
		write (STDOUT_FILENO, "> ", 2);
	    }
	}
    }
    
    begin_upload:
    fstat(fdR, &info);
    file_size = (unsigned int) info.st_size;
    bytes_sent = 0;
    FD_ZERO(&master);
    FD_SET(STDIN_FILENO, &master);
    tv.tv_sec = 0;
    tv.tv_usec = 0;
    
    //Let's send the server the file size
    memset(buffer, 0, MAXLEN);
    sprintf(buffer, "%010d", file_size);
    make_packet(*nseq, strlen(buffer), buffer);
    if(ReliableSend(sock, nseq, buffer, HEADER_LENGTH+10, 0) < 0){
	close(fdR);
	return -1;
    }
    memset(buffer, 0, MAXLEN);
    
    //Let's start uploading
    if(!file_renamed)
	printf("(%s) upload of file \"%s\" in progress\n", prog_name, file);
    else
	printf("(%s) upload of file \"%s\" as \"%s\" in progress\n", prog_name, file, temp);
    memset(temp, 0, MAXLEN);
    
    while((nRead = read(fdR, buffer, MAXLEN-HEADER_LENGTH)) > 0)
    {
	fds = master;
	make_packet(*nseq, nRead, buffer);
	if(ReliableSend(sock, nseq, buffer, nRead+HEADER_LENGTH, 0) < 0){
	    close(fdR);
	    return -1;
	}
	bytes_sent += nRead;
	memset(buffer, 0, MAXLEN);

	if((nRead = ReliableRecv(sock, nseq_expected, buffer, MAXLEN, 0)) < 0){
		close(fdR);
		return -1;
	}
	if(!strcmp(buffer+HEADER_LENGTH, ERR)){
	    printf("(%s) upload aborted. An error occured on server\n", prog_name);
	    close(fdR);
	    return -2;
	}

	printf("bytes uploaded: %u/%u (%3.3f %%)\n", bytes_sent, file_size, (bytes_sent/(file_size * 1.0)*100));
	memset(buffer, 0, MAXLEN);
	memset(temp, 0, MAXLEN);
	ret = select(STDIN_FILENO+1, &fds, NULL, NULL, &tv);
	if(ret > 0)
	{
	    read(STDIN_FILENO, buffer, MAXLEN);
	    cmd = parse_command(buffer);
	    if(cmd == STOP){
		close(fdR);
		memset(buffer, 0, MAXLEN);
		sprintf(buffer, "%s", CMD_STOP);
		make_packet(*nseq, strlen(buffer), buffer);
		if(ReliableSend(sock, nseq, buffer, strlen(buffer), 0) < 0)
		    return -1;
		
		printf("(%s) upload aborted by user\n", prog_name);
		return -2;
	    }else if(cmd == QUIT){
		sprintf(temp, "%s", CMD_QUIT);
		if(queue_command(temp))
		    printf("(%s) QUIT command queued (%d commands left)\n", prog_name, MAX_PENDING_COMMANDS-n_pending_commands);
		else
		    printf("(%s) command queue full. Unable to queue this command\n", prog_name);
	    }else if(cmd == UP){
		sprintf(temp, "%s %s", CMD_UP, buffer);
		if(queue_command(temp))
		    printf("(%s) UPLOAD command queued (%d commands left)\n", prog_name, MAX_PENDING_COMMANDS-n_pending_commands);
		else
		    printf("(%s) command queue full. Unable to queue this command\n", prog_name);
	    }else if(cmd == DOWN){
		sprintf(temp, "%s %s", CMD_DOWN, buffer);
		if(queue_command(temp))
		    printf("(%s) DOWNLOAD command queued (%d commands left)\n", prog_name, MAX_PENDING_COMMANDS-n_pending_commands);
		else
		    printf("(%s) command queue full. Unable to queue this command\n", prog_name);
	    }else if(cmd == LS){
		sprintf(temp, "%s", CMD_LS);
		if(queue_command(temp))
		    printf("(%s) LS command queued (%d commands left)\n", prog_name, MAX_PENDING_COMMANDS-n_pending_commands);
		else
		    printf("(%s) command queue full. Unable to queue this command\n", prog_name);
	    }else if(cmd == CD){
		sprintf(temp, "%s %s", CMD_CD, buffer);
		if(queue_command(temp))
		    printf("(%s) CD command queued (%d commands left)\n", prog_name, MAX_PENDING_COMMANDS-n_pending_commands);
		else
		    printf("(%s) command queue full. Unable to queue this command\n", prog_name);
	    }else if(cmd == PWD){
		sprintf(temp, "%s", CMD_PWD);
		if(queue_command(temp))
		    printf("(%s) PWD command queued (%d commands left)\n", prog_name, MAX_PENDING_COMMANDS-n_pending_commands);
		else
		    printf("(%s) command queue full. Unable to queue this command\n", prog_name);
	    }else{
		printf("(%s) %s: unknown command\n", prog_name, buffer);
	    }
	    memset(buffer, 0, MAXLEN);
	}
	memset(buffer, 0, MAXLEN);
    }
    
    //EOF, let's send an empty message
    make_packet(*nseq, 0, buffer);
    if(ReliableSend(sock, nseq, buffer, HEADER_LENGTH, 0) < 0) return -1;
    
    close(fdR);
    printf("(%s) upload file \"%s\" completed successfully\n", prog_name, file);
    return 1;
}

int download_file(int sock, int * nseq, int * nseq_expected, const char * file, int block_size, struct sockaddr_in server, int servaddrlen)
{
    char buffer[MAXLEN], temp[MAXLEN];
    int fdW, nRead, nWrite, ret, cmd, file_size, nReceived = 0;
    fd_set fds, master;
    struct timeval tv;
    
    //Let's send the download command
    memset(buffer, 0, MAXLEN);
    sprintf(buffer, "%s %s %d", CMD_DOWN, file, block_size);
    make_packet(*nseq, strlen(buffer), buffer);
    if(ReliableSend(sock, nseq, buffer, strlen(buffer), 0) < 0)
	return -1;
    
    //Let's if we can download this file
    memset(buffer, 0, MAXLEN);
    if(ReliableRecv(sock, nseq_expected, buffer, MAXLEN, 0) < 0) return -1;
    if(!strcmp(buffer+HEADER_LENGTH, ERRBUSY)){
	printf("(%s) error in downloading \"%s\": file is busy\n", prog_name, file);
	return -2;
    }else if(!strcmp(buffer+HEADER_LENGTH, ERREXISTS)){
	printf("(%s) error in downloading \"%s\": file does not exist on server\n", prog_name, file);
	return -2;
    }
    
    if((fdW = open(file, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR)) == -1){
	printf("(%s) error on creating \"%s\": %s\n", prog_name, file, strerror(errno));
	return -1;
    }
    memset(buffer, 0, MAXLEN);
    if(connect(sock, (struct sockaddr *) &server, servaddrlen) != 0){
	printf("(%s) error on connect: %s\n", prog_name, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    FD_ZERO(&master);
    FD_SET(STDIN_FILENO, &master);
    
    //Let's receive the file size
    if((nRead = ReliableRecv(sock, nseq_expected, buffer, MAXLEN, 0)) < 0){
	printf("(%s) error on receiving file size\n", prog_name);
	close(fdW);
	unlink(file);
	return -1;
    }
    file_size = atoi(buffer+HEADER_LENGTH);
    memset(buffer, 0, MAXLEN);
    
    //Let's start downloading
    record_download(file);
    printf("(%s) download of file \"%s\" in progress\n", prog_name, file);
    while(1)
    {
	fds = master;
	tv.tv_sec = 0;
	tv.tv_usec = 0;
	
	//Let's request the fragment
	sprintf(buffer, "NEXT %d BYTES", block_size);
	make_packet(*nseq, strlen(buffer), buffer);
	if(ReliableSend(sock, nseq, buffer, strlen(buffer), 0) < 0){
	    delete_download();
	    unlink(file);
	    delete_download();
	    return -1;
	}
	nRead = ReliableRecv(sock, nseq_expected, buffer, MAXLEN, 0);
	if(nRead == -1){
	    unlink(file);
	    delete_download();
	    return -1;
	}
	nWrite = write(fdW, buffer+HEADER_LENGTH, nRead);
	if(nWrite != nRead){
	    printf("(%s) an error on write occurred. %d bytes written instead of %d. Aborting\n", prog_name, nWrite, nRead);
	    unlink(file);
	    delete_download();
	    memset(buffer, 0, MAXLEN);
	    sprintf(buffer, "%s", ERR);
	    make_packet(*nseq, strlen(buffer), buffer);
	    if(ReliableSend(sock, nseq, buffer, strlen(buffer), 0) < 0)
		return -1;
	    else
		return -2;
	}
	nReceived += nWrite;
	printf("(%s) bytes received: %u/%u (%3.3f %%)\n", prog_name, nReceived, file_size, (nReceived/(file_size * 1.0)*100));
	if(nRead == 0 || (nRead > 0 && nRead < block_size)){
	    break;
	}else if(nRead < 0){
	    close(fdW);
	    unlink(file);
	    delete_download();
	    return -1;
	}
	memset(buffer, 0, MAXLEN);
	memset(temp, 0, MAXLEN);
	ret = select(STDIN_FILENO+1, &fds, NULL, NULL, &tv);
	if(ret > 0)
	{
	    read(STDIN_FILENO, buffer, MAXLEN);
	    cmd = parse_command(buffer);
	    if(cmd == STOP){
		close(fdW);
		unlink(file);
		delete_download();
		sprintf(buffer, "%s", CMD_STOP);
		make_packet(*nseq, strlen(buffer), buffer);
		if(ReliableSend(sock, nseq, buffer, strlen(buffer), 0) < 0){
		    return -1;
		}
		printf("(%s) download aborted by user\n", prog_name);
		return -2;
	    }else if(cmd == QUIT){
		sprintf(temp, "%s", CMD_QUIT);
		if(queue_command(temp))
		    printf("(%s) QUIT command queued (%d commands left)\n", prog_name, MAX_PENDING_COMMANDS-n_pending_commands);
		else
		    printf("(%s) command queue full. Unable to queue this command\n", prog_name);
	    }else if(cmd == UP){
		sprintf(temp, "%s %s", CMD_UP, buffer);
		if(queue_command(temp))
		    printf("(%s) UPLOAD command queued (%d commands left)\n", prog_name, MAX_PENDING_COMMANDS-n_pending_commands);
		else
		    printf("(%s) command queue full. Unable to queue this command\n", prog_name);
	    }else if(cmd == DOWN){
		sprintf(temp, "%s %s", CMD_DOWN, buffer);
		if(queue_command(temp))
		    printf("(%s) DOWNLOAD command queued (%d commands left)\n", prog_name, MAX_PENDING_COMMANDS-n_pending_commands);
		else
		    printf("(%s) command queue full. Unable to queue this command\n", prog_name);
	    }else if(cmd == LS){
		sprintf(temp, "%s", CMD_LS);
		if(queue_command(temp))
		    printf("(%s) LS command queued (%d commands left)\n", prog_name, MAX_PENDING_COMMANDS-n_pending_commands);
		else
		    printf("(%s) command queue full. Unable to queue this command\n", prog_name);
	    }else if(cmd == CD){
		sprintf(temp, "%s %s", CMD_CD, buffer);
		if(queue_command(temp))
		    printf("(%s) CD command queued (%d commands left)\n", prog_name, MAX_PENDING_COMMANDS-n_pending_commands);
		else
		    printf("(%s) command queue full. Unable to queue this command\n", prog_name);
	    }else if(cmd == PWD){
		sprintf(temp, "%s", CMD_PWD);
		if(queue_command(temp))
		    printf("(%s) PWD command queued (%d commands left)\n", prog_name, MAX_PENDING_COMMANDS-n_pending_commands);
		else
		    printf("(%s) command queue full. Unable to queue this command\n", prog_name);
	    }else{
		printf("(%s) %s: unknown command\n", prog_name, buffer);
	    }
	    memset(buffer, 0, MAXLEN);
	}
	memset(buffer, 0, MAXLEN);
    }
    close(fdW);
    printf("(%s) download file \"%s\" completato\n", prog_name, file);
    delete_download();
    return 1;
}

int do_ls(int sock, int * nseq, int * nseq_expected, struct sockaddr_in server, int servaddrlen)
{
    char buffer[MAXLEN];
    char * ls_buffer = NULL;
    int nRead, nReceived = 0, ls_buffer_size;
    
	
    //Let's send the "ls" command
    memset(buffer, 0, MAXLEN);
    sprintf(buffer, "%s", CMD_LS);
    make_packet(*nseq, strlen(buffer), buffer);
    if(ReliableSend(sock, nseq, buffer, strlen(buffer), 0) < 0)
	return -1;
    
    //Let's see if we can proceed
	memset(buffer, 0, MAXLEN);
    if(ReliableRecv(sock, nseq_expected, buffer, MAXLEN, 0) < 0) return -1;
    if(!strcmp(buffer+HEADER_LENGTH, ERR)){
	printf("(%s) error in executing LS command on server\n", prog_name);
	return -2;
    }

    //Let's receive the buffer size
	memset(buffer, 0, MAXLEN);
    if((nRead = ReliableRecv(sock, nseq_expected, buffer, MAXLEN, 0)) < 0){
	printf("(%s) error on receiving ls_buffer_size\n", prog_name);
	return -1;
    }
    ls_buffer_size = atoi(buffer+HEADER_LENGTH);
    ls_buffer = (char *)malloc(ls_buffer_size);
	
    //Let's receive the "ls" command result
    while(1)
    {
	nRead = ReliableRecv(sock, nseq_expected, buffer, MAXLEN, 0);
	if(nRead == 0){
	    break;
	}else if(nRead < 0){
	    free(ls_buffer);
	    return -1;
	}
	memcpy(ls_buffer+nReceived, buffer+HEADER_LENGTH, nRead);
	nReceived += nRead;
	memset(buffer, 0, MAXLEN);
    }
    printf("%s", ls_buffer);
    free(ls_buffer);
    return 1;
}

int do_cd(int sock, int * nseq, int * nseq_expected, const char * dir, struct sockaddr_in server, int servaddrlen)
{
    char buffer[MAXLEN];
    
    //Let's send the "cd" command
    memset(buffer, 0, MAXLEN);
    sprintf(buffer, "%s %s", CMD_CD, dir);
    make_packet(*nseq, strlen(buffer), buffer);
    if(ReliableSend(sock, nseq, buffer, strlen(buffer), 0) < 0)
	return -1;
    
    //Let's see if it's ok
    memset(buffer, 0, MAXLEN);
    if(ReliableRecv(sock, nseq_expected, buffer, MAXLEN, 0) < 0) return -1;
    if(!strcmp(buffer+HEADER_LENGTH, ERR)){
	printf("(%s) error in executing CD command on server\n", prog_name);
	return -2;
    }
    printf("%s\n", buffer+HEADER_LENGTH);
    return 1;
}

int do_rm(int sock, int * nseq, int * nseq_expected, const char * file, struct sockaddr_in server, int servaddrlen)
{
    char buffer[MAXLEN];
    
    //Let's send the "cd" command
    memset(buffer, 0, MAXLEN);
    sprintf(buffer, "%s %s", CMD_RM, file);
    make_packet(*nseq, strlen(buffer), buffer);
    if(ReliableSend(sock, nseq, buffer, strlen(buffer), 0) < 0)
	return -1;
    
    //Let's see if it's ok
    memset(buffer, 0, MAXLEN);
    if(ReliableRecv(sock, nseq_expected, buffer, MAXLEN, 0) < 0) return -1;
    if(!strcmp(buffer+HEADER_LENGTH, ERR)){
	printf("(%s) error in executing RM command on server\n", prog_name);
	return -2;
    }
    printf("(%s) file \"%s\" successfully deleted\n", prog_name, file);
    return 1;
}

int do_pwd(int sock, int * nseq, int * nseq_expected, struct sockaddr_in server, int servaddrlen)
{
    char buffer[MAXLEN];
    
    //Let's send the "pwd" command
    memset(buffer, 0, MAXLEN);
    sprintf(buffer, "%s", CMD_PWD);
    make_packet(*nseq, strlen(buffer), buffer);
    if(ReliableSend(sock, nseq, buffer, strlen(buffer), 0) < 0)
	return -1;
    
    //Let's see if it's ok
    memset(buffer, 0, MAXLEN);
    if(ReliableRecv(sock, nseq_expected, buffer, MAXLEN, 0) < 0) return -1;
    if(!strcmp(buffer+HEADER_LENGTH, ERR)){
	printf("(%s) error in executing PWD command on server\n", prog_name);
	return -2;
    }
    
    printf("%s\n", buffer+HEADER_LENGTH);
    
    return 1;
}

void record_download(const char * file)
{
    int fd; 
    if((fd = open(log_file, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR)) == -1){    
	printf("(%s) error on opening log_file: %s\n", prog_name, strerror(errno));
	exit(EXIT_FAILURE);
    }
    write(fd, file, strlen(file));
    close(fd);
}

void delete_download()
{
    int fd;
    char buffer[MAXLEN];
    
    if((fd = open(log_file, O_RDWR)) == -1) return;
    memset(buffer, 0, MAXLEN);
    write(fd, buffer, MAXLEN);
    close(fd);
}

void recover_from_log_file()
{
    int fd;
    char file[MAXLEN];
        
    if((fd = open(log_file, O_RDONLY)) == -1) return;
    
    read(fd, file, MAXLEN);
    if(strlen(file) > 0)
    {
	printf("(%s) incomplete downloaded file \"%s\" has been deleted\n", prog_name, file);
	unlink(file);
	unlink(log_file);
    }
    close(fd);
}

int get_seq_number(const char * packet)
{
    int i = 1 + strlen(HEADER_SEQ), index = 0;
    char sequence_number[10];
    for(; index < 10; i++, index++)
	sequence_number[index] = packet[i];
    sequence_number[index] = '\0';
    return atoi(sequence_number);
}

int get_ack_number(const char * packet)
{
    int i, index = 0;
    char ack_number[10];
    for(i = 5; i < HEADER_LENGTH-1; i++, index++)
	ack_number[index] = packet[i];
    ack_number[index] = '\0';
    return atoi(ack_number);
}

int ReliableSend (int sock, int * nseq, const char * buffer, int nbytes, int flags)
{
    int timeout_count = 0, ret;
    char ack[HEADER_LENGTH];
    
    while(1)
    {	
	Send(sock, buffer, nbytes, flags);
	ret = Recvtimeout(sock, ack, HEADER_LENGTH, TIMEOUT);
	if(ret == -2){
	    if(++timeout_count == TIMEOUT_LIMIT){
		printf("(%s) timeout_limit reached. Connection with server lost\n", prog_name);
		return -1;
	    }
	}else if(ret == -1){
	    printf("(%s) error on receive: %s\n", prog_name, strerror(errno));
	    return -1;
	}else if(ret == 0){
	    printf("(%s) server crashed\n", prog_name);
	    return -1;
	}else{
	    if(!strcmp(ack, CMD_STOP)){
		(void)(*nseq)++; //in order to suppress warning
		return -2;
	    }
	    else if(*nseq == get_ack_number(ack)){
		(void)(*nseq)++; //in order to suppress warning
		return 1;
	    }
	    else
		continue;
	}
    }
    return 1; //Never reached
}

int ReliableSendto (int sock, int * nseq, const char * buffer, int nbytes, int flags, const struct sockaddr * endpoint, socklen_t endpointlen)
{
    int timeout_count = 0, ret;
    char ack[HEADER_LENGTH];
    
    while(1)
    {
	Sendto(sock, buffer, nbytes, flags, endpoint, endpointlen);
	ret = Recvtimeout(sock, ack, HEADER_LENGTH, TIMEOUT);
	if(ret == -2){
	    if(++timeout_count == TIMEOUT_LIMIT){
		printf("(%s) timeout_limit reached. Connection with server lost\n", prog_name);
		return -1;
	    }
	}else if(ret == -1){
	    printf("(%s) error on receive: %s\n", prog_name, strerror(errno));
	    return -1;
	}else if(ret == 0){
	    printf("(%s) server crashed\n", prog_name);
	    return -1;
	}else{
	    if(*nseq == get_ack_number(ack)){
		(void)(*nseq)++; //in order to suppress warning
		return 1;
	    }
	    else
		continue;
	}
    }
    return 1; //Never reached
}

int ReliableRecv(int sock, int * nseq_expected, char * buffer, int nbytes, int flags)
{
    int timeout_count = 0, ret, seq_number_received;
    char temp[100];
    
    while(1)
    {	
	ret = Recvtimeout(sock, buffer, nbytes, TIMEOUT);
	if(ret == -2){
	    if(++timeout_count == TIMEOUT_LIMIT){
		printf("(%s) timeout_limit reached. Connection with server lost\n", prog_name);
		return -1;
	    }
	}else if(ret == -1){
	    printf("(%s) error on receive: %s\n", prog_name, strerror(errno));
	    return -1;
	}else if(ret == 0){
	    printf("(%s) server crashed\n", prog_name);
	    return -1;
	}else{
	    seq_number_received = get_seq_number(buffer);
	    if(seq_number_received == *nseq_expected){
		//Send ack for correct received sequence number
		sprintf(temp, "[ACK:%010d]", seq_number_received);
		Send(sock, temp, HEADER_LENGTH, flags);
		(void)(*nseq_expected)++; //in order to suppress warning
		return ret-HEADER_LENGTH;
	    }
	    else if(seq_number_received == *nseq_expected-1){
		//Send ack for previous sequence number received
		printf("Expected sequence number (%d) but (%d) received. Packet discarded\n", *nseq_expected, seq_number_received);
		sprintf(temp, "[ACK:%010d]", seq_number_received);
		Send(sock, temp, HEADER_LENGTH, flags);
	    }
	    else{
		printf("Expected sequence number (%d) but (%d) received. Packet discarded\n", *nseq_expected, seq_number_received);
	    }  
	}
    }
    return 1; //Never reached
}

int ReliableRecvfrom(int sock, int * nseq_expected, char * buffer, int nbytes, int flags, struct sockaddr * endpoint, socklen_t * endpointlen)
{
    int timeout_count = 0, ret, seq_number_received;
    char temp[100];
    
    while(1)
    {
	ret = Recvfromtimeout(sock, buffer, nbytes, TIMEOUT, endpoint, endpointlen);
	if(ret == -2){
	    if(++timeout_count == TIMEOUT_LIMIT){
		printf("(%s) timeout_limit reached. Connection with server lost\n", prog_name);
		return -1;
	    }
	}else if(ret == -1){
	    printf("(%s) error on receive: %s\n", prog_name, strerror(errno));
	    return -1;
	}else if(ret == 0){
	    printf("(%s) server crashed\n", prog_name);
	    return -1;
	}else{
	    seq_number_received = get_seq_number(buffer);
	    if(seq_number_received == *nseq_expected){	    
		//Send ack for correct received sequence number
		sprintf(temp, "[ACK:%010d]", seq_number_received);
		Sendto(sock, temp, HEADER_LENGTH, flags, endpoint, *endpointlen);
		(void)(*nseq_expected)++; //in order to suppress warning
		return ret;
	    }
	    else if(seq_number_received == *nseq_expected-1){
		//Send ack for previous sequence number received
		printf("Expected sequence number '%d' but '%d' was received. Packet discarded\n", *nseq_expected, seq_number_received);
		sprintf(temp, "[ACK:%010d]", seq_number_received);
		Sendto(sock, temp, HEADER_LENGTH, flags, endpoint, *endpointlen);
	    }
	    else{
		printf("Expected sequence number '%d' but '%d' was received. Packet discarded\n", *nseq_expected, seq_number_received);
	    } 
	}
    }
    return 1; //Never reached
}

int Recv(int fd, char * bufptr, int nbytes, int flags)
{
    int n;
    if ((n = recv(fd, bufptr, nbytes, flags)) < 0)
	printf("(%s) error on recv(): %s\n", prog_name, strerror(errno));
    return n;
}

int Recvfrom (int fd, char * bufptr, int nbytes, int flags, struct sockaddr * sa, socklen_t * salenptr)
{
    int n;
    if ((n = recvfrom(fd, bufptr, nbytes, flags, sa, salenptr)) < 0)
	printf("(%s) error on recvfrom(): %s\n", prog_name, strerror(errno));
    return n;
}

int Recvtimeout(int s, char * buf, int len, int timeout)
{
    fd_set fds;
    int n;
    struct timeval tv;
    
    FD_ZERO(&fds);
    FD_SET(s, &fds);
    
    tv.tv_sec = timeout;
    tv.tv_usec = 0;

    n = select(s+1, &fds, NULL, NULL, &tv);
    if (n == 0) return -2;
	if (n == -1) return -1;
	    return recv(s, buf, len, 0);
}

int Recvfromtimeout(int s, char * buf, int len, int timeout, struct sockaddr * endpoint, socklen_t * endpointlen)
{
    fd_set fds;
    int n;
    struct timeval tv;
    
    FD_ZERO(&fds);
    FD_SET(s, &fds);
    
    tv.tv_sec = timeout;
    tv.tv_usec = 0;
    
    n = select(s+1, &fds, NULL, NULL, &tv);
    if (n == 0) return -2;
	if (n == -1) return -1;
	    return recvfrom(s, buf, len, 0, endpoint, endpointlen);
}

int Sendto (int fd, const char * bufptr, int nbytes, int flags, const struct sockaddr * sa, socklen_t salen)
{
    int n;
    if ((n = sendto(fd, bufptr, nbytes, flags, sa, salen)) != nbytes)
	printf("(%s) error on sendto(): %s\n", prog_name, strerror(errno));
    return n;
}

int Send (int fd, const char * bufptr, int nbytes, int flags)
{
    int n;
    if ((n = send(fd, bufptr, nbytes, flags)) != nbytes)
	printf("(%s) error on send(): %s\n", prog_name, strerror(errno));
    return n;
}

void menu()
{
    printf("\n");
    printf("+---------------------------------------------------------------+\n");
    printf("|                             MENU'                             |\n");
    printf("+---------------------------------------------------------------+\n");
    printf("|-> UP <file_name>                                              |\n");
    printf("|-> DOWN <file_name>                                            |\n");
    printf("|-> RM <file_name>: remove a file from server working directory |\n");
    printf("|-> STOP: stop a download                                       |\n");
    printf("|-> QUIT: quit the client                                       |\n");
    printf("|-> PWD: show server current working directory                  |\n");
    printf("|-> LS: show the content of server working directory            |\n");
    printf("|-> CD: change server working directory                         |\n");
    printf("+---------------------------------------------------------------+\n");
    printf("\n");
}
