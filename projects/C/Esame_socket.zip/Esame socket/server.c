#include <sys/mman.h> 
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <dirent.h>

#define TIMEOUT_LIMIT 3
#define MAXLEN        1024
#define NCHILDREN     4
#define TIMEOUT       3
#define UNKNOWN       0
#define UP            1
#define DOWN          2
#define STOP	      3
#define QUIT	      4
#define LS	      5
#define CD	      6
#define PWD           7
#define RM	      8
#define OVERWRITE     9
#define RENAME	      10
#define DONOTHING     11
#define CMD_UP        "UP"
#define CMD_DOWN      "DOWN"
#define CMD_STOP      "STOP"
#define CMD_QUIT      "QUIT"
#define CMD_LS	      "LS"
#define CMD_CD	      "CD"
#define CMD_PWD	      "PWD"
#define CMD_RM	      "RM"
#define CMD_OVERWRITE "+OVERWRITE"
#define CMD_RENAME    "+RENAME"
#define CMD_DONOTHING "+DONOTHING"
#define HEADER_SEQ    "SEQ:"
#define HEADER_LENGTH (1+strlen(HEADER_SEQ)+10+1)
#define OK	      "+OK\n"
#define ERR	      "-ERR"
#define ERRBUSY	      "-ERRBUSY"
#define ERREXISTS     "-ERREXISTS"

#ifdef SIMULATE
#define simulate(x) x
#else
#define simulate(x)
#endif

typedef void SigFunc (int);
char * prog_name;
char * log_file = "server_log_file";
int semaphore[2];
pid_t children[NCHILDREN];
extern int errno;

SigFunc ctrl_c_z_handler;
SigFunc sigusr1_handler;
void sem_wait(int *, int);
void sem_post(int *, int);
void set_handler (int, SigFunc);
void child(int, int);
void make_packet(int, int, char *);
void recover_from_log_file();
void record_upload(int, const char *);
void remove_upload(int, const char *);
void record_download(int, const char *);
void remove_download(int, const char *);
int find_in_log(int, int, const char *);
int client_upload(int, int, int *, int *, char *, struct sockaddr_in, int);
int client_ls(int, int, int *, int *, struct sockaddr_in, int);
int client_cd(int, int, int *, int *, const char *, struct sockaddr_in, int);
int client_rm(int, int, int *, int *, const char *, struct sockaddr_in, int);
int client_pwd(int, int, int *, int *, struct sockaddr_in, int);
int client_download(int, int, int *, int *, const char *, int, struct sockaddr_in, int);
int parse_command(char *, int *);
int get_seq_number(const char *);
int get_ack_number(const char *);
int ReliableSendto (int, int, int *, const char *, int, int, const struct sockaddr *, socklen_t);
int ReliableSend (int, int, int *, const char *, int, int);
int ReliableRecvfrom(int, int, int *, char *, int, int, struct sockaddr *, socklen_t *);
int ReliableRecv(int, int, int *, char *, int, int);
int Recv(int, int, char *, int, int);
int Recvfrom(int, int, char *, int, int, struct sockaddr *, socklen_t *);
int Recvtimeout(int, char *, int, int);
int Recvfromtimeout(int, char *, int, int, struct sockaddr *, socklen_t *);
int Send(int, int, const char *, int, int);
int Sendto(int, int, const char *, int, int, const struct sockaddr *, socklen_t);

int main(int argc, char *argv[])
{
    int port_int, fd, i, j, status, sock, ret;
    char temp[MAXLEN+2];
    unsigned short port;
    struct sockaddr_in servaddr;    
    
    prog_name = argv[0];
    
    if (argc != 2){
	printf("usage: %s <port>\n", prog_name);
	exit(EXIT_FAILURE);
    }

    port_int = atoi(argv[1]);
    if(port_int <= 1024 || port_int > 65535){
	printf("Invalid port number. Valid range is [1025 - 65535]\n");
	exit(EXIT_FAILURE);
    }

    port = (unsigned short) (port_int&0xffff);

    sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if(socket < 0){
	printf("(%s) error on creating socket: %s\n", prog_name, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    //Let's remove any possible incomplete uploaded files
    recover_from_log_file();
    if((fd = open(log_file, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR)) == -1){
	printf("(%s) error on creating the log file: %s\n", prog_name, strerror(errno));
	exit(EXIT_FAILURE);
    }
    //Let's clear the content of log_file
    memset(temp, 0, MAXLEN+2);
    for(i = 0; i < 2*NCHILDREN; i++)
	write(fd, temp, MAXLEN+2);
    close(fd);
    
    if(pipe(semaphore)){
	printf("(%s) error on creating semaphore\n", prog_name);
	exit(EXIT_FAILURE);
    }
    sem_post(semaphore, 0);

    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(port);
    servaddr.sin_addr.s_addr = INADDR_ANY;

    if(bind(sock, (struct sockaddr *) &servaddr, sizeof(servaddr)) != 0){
	printf("(%s) error on bind(): %s\n", prog_name, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    set_handler(SIGINT, ctrl_c_z_handler);
    set_handler(SIGTSTP, ctrl_c_z_handler);
    
    for(i = 0; i < NCHILDREN; i++)
    {
	if((children[i] = fork()) == 0){
	    child(sock, i+1);
	    return EXIT_SUCCESS;
	}
    }
    for(i = 0; i < NCHILDREN; i++)
    {
	ret = waitpid(-1, &status, 0);
	if(ret == -1) i--;
	for(j = 0; j < NCHILDREN; j++){
	    if(children[j] == ret){
		printf("(%s) child %d exited with status %d\n", prog_name, j+1, status);
		children[j] = 0;
		break;
	    }
	}
    }
    
    if(close(sock) != 0){
	printf("(%s) error on closing socket: %s\n", prog_name, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    return EXIT_SUCCESS;
}

void set_handler (int signo, SigFunc handler)
{
    struct sigaction act;
    memset(&act, 0, sizeof(act));
    act.sa_handler = handler;
    if(sigaction(signo, &act, NULL) == -1){
	printf("(%s) error on sigaction\n", prog_name);
	exit(EXIT_FAILURE);
    }
}

void ctrl_c_z_handler(int signo)
{
    int i;
    for(i = 0; i < NCHILDREN; i++)
	kill(children[i], SIGUSR1);
}

void sigusr1_handler(int signo)
{
    exit(EXIT_SUCCESS);
}

void sem_wait(int * pipe, int id)
{
    char buffer[2];
    if (read(pipe[0], &buffer, 1) != 1) {
	printf ("(%s %d) error on sem_wait\n", prog_name, id);
	exit (EXIT_FAILURE);
    }
}

void sem_post(int * pipe, int id)
{    
    if (write(pipe[1], "X", 1) != 1) {
	printf ("(%s %d) error on sem_post\n", prog_name, id);
	exit (EXIT_FAILURE);
    }
}

void record_upload(int id, const char * file)
{
    struct flock fl = {F_WRLCK, SEEK_SET, 0, 0, 0};
    int fd;
    char buffer[MAXLEN];
    
    fl.l_pid = getpid();
    if((fd = open(log_file, O_RDWR)) == -1){    
	printf("(%s %d) error on opening log_file: %s\n", prog_name, id, strerror(errno));
	exit(EXIT_FAILURE);
    }
    if(fcntl(fd, F_SETLKW, &fl) == -1){
	printf("(%s %d) error on fcntl: %s\n", prog_name, id, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    lseek(fd, (id-1)*(MAXLEN+2), SEEK_SET);
    sprintf(buffer, "%d=", id);
    write(fd, buffer, 2);
    memset(buffer, 0, MAXLEN);
    if(getcwd(buffer, MAXLEN-strlen(file)) != NULL)
    {
	if(buffer[strlen(buffer)-1] != '/')
	    strcat(buffer, "/");
	strcat(buffer, file);
	write(fd, buffer, MAXLEN);
    }
    
    fl.l_type = F_UNLCK;
    if(fcntl(fd, F_SETLK, &fl) == -1){
	printf("(%s %d) error on fcntl: %s\n", prog_name, id, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    close(fd);
}

void remove_upload(int id, const char * file)
{
    struct flock fl = {F_WRLCK, SEEK_SET, 0, 0, 0};
    int fd;
    char buffer[MAXLEN], temp[MAXLEN];
    
    fl.l_pid = getpid();
    if((fd = open(log_file, O_RDWR)) == -1){    
	printf("(%s %d) error on opening log_file: %s\n", prog_name, id, strerror(errno));
	exit(EXIT_FAILURE);
    }
    if(fcntl(fd, F_SETLKW, &fl) == -1){
	printf("(%s %d) error on fcntl: %s\n", prog_name, id, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    getcwd(temp, MAXLEN);
    if(temp[strlen(temp)-1] != '/')
	strcat(temp, "/");
    strcat(temp, file);
    
    lseek(fd, (id-1)*(MAXLEN+2)+2, SEEK_SET);
    read(fd, buffer, MAXLEN);
    if(strcmp(buffer, temp) != 0){
	printf("(%s %d) file \"%s\" not found in log file\n", prog_name, id, temp);
	close(fd);
	return;
    }
    
    memset(buffer, 0, MAXLEN);
    lseek(fd, (id-1)*(MAXLEN+2)+2, SEEK_SET);
    write(fd, buffer, MAXLEN);
    
    fl.l_type = F_UNLCK;
    if(fcntl(fd, F_SETLK, &fl) == -1){
	printf("(%s %d) error on fcntl: %s\n", prog_name, id, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    close(fd);
}

void record_download(int id, const char * file)
{
    struct flock fl = {F_WRLCK, SEEK_SET, 0, 0, 0};
    int fd;
    char buffer[MAXLEN];
    
    fl.l_pid = getpid();
    if((fd = open(log_file, O_RDWR)) == -1){    
	printf("(%s %d) error on opening log_file: %s\n", prog_name, id, strerror(errno));
	exit(EXIT_FAILURE);
    }
    if(fcntl(fd, F_SETLKW, &fl) == -1){
	printf("(%s %d) error on fcntl: %s\n", prog_name, id, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    lseek(fd, (NCHILDREN*(MAXLEN+2))+((id-1)*(MAXLEN+2)), SEEK_SET);
    sprintf(buffer, "%d=", id);
    write(fd, buffer, 2);
    memset(buffer, 0, MAXLEN);
    if(getcwd(buffer, MAXLEN-strlen(file)) != NULL)
    {
	if(buffer[strlen(buffer)-1] != '/')
	    strcat(buffer, "/");
	strcat(buffer, file);
	write(fd, buffer, MAXLEN);
    }
    
    fl.l_type = F_UNLCK;
    if(fcntl(fd, F_SETLK, &fl) == -1){
	printf("(%s %d) error on fcntl: %s\n", prog_name, id, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    close(fd);
}

void remove_download(int id, const char * file)
{
    struct flock fl = {F_WRLCK, SEEK_SET, 0, 0, 0};
    int fd;
    char buffer[MAXLEN], temp[MAXLEN];
    
    fl.l_pid = getpid();
    if((fd = open(log_file, O_RDWR)) == -1){    
	printf("(%s %d) error on opening log_file: %s\n", prog_name, id, strerror(errno));
	exit(EXIT_FAILURE);
    }
    if(fcntl(fd, F_SETLKW, &fl) == -1){
	printf("(%s %d) error on fcntl: %s\n", prog_name, id, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    getcwd(temp, MAXLEN);
    if(temp[strlen(temp)-1] != '/')
	strcat(temp, "/");
    strcat(temp, file);
    
    lseek(fd, (NCHILDREN*(MAXLEN+2))+((id-1)*(MAXLEN+2)+2), SEEK_SET);
    read(fd, buffer, MAXLEN);
    if(strcmp(buffer, temp) != 0){
	printf("(%s %d) file \"%s\" not found in log file\n", prog_name, id, temp);
	close(fd);
	return;
    }
    
    memset(buffer, 0, MAXLEN);
    lseek(fd, (NCHILDREN*(MAXLEN+2))+((id-1)*(MAXLEN+2)+2), SEEK_SET);
    write(fd, buffer, MAXLEN);
    
    fl.l_type = F_UNLCK;
    if(fcntl(fd, F_SETLK, &fl) == -1){
	printf("(%s %d) error on fcntl: %s\n", prog_name, id, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    close(fd);
}

int find_in_log(int id, int up_or_down, const char * file)
{
    struct flock fl = {F_WRLCK, SEEK_SET, 0, 0, 0};
    int i, fd, offset, found = 0;
    char buffer[MAXLEN], temp[MAXLEN];;
    
    fl.l_pid = getpid();
    if((fd = open(log_file, O_RDWR)) == -1){    
	printf("(%s %d) error on opening log_file: %s\n", prog_name, id, strerror(errno));
	exit(EXIT_FAILURE);
    }
    if(fcntl(fd, F_SETLKW, &fl) == -1){
	printf("(%s %d) error on fcntl: %s\n", prog_name, id, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    getcwd(temp, MAXLEN);
    if(temp[strlen(temp)-1] != '/')
	strcat(temp, "/");
    strcat(temp, file);
    
    offset = (up_or_down == UP) ? 0 : NCHILDREN*(MAXLEN+2);
    
    for(i = 0; i < NCHILDREN; i++)
    {
	lseek(fd, offset+(i*(MAXLEN+2)+2), SEEK_SET);
	read(fd, buffer, MAXLEN);
	if(!strcmp(buffer, temp)){
	    found = 1;
	    break;
	}
	memset(buffer, 0, MAXLEN);
    }
    
    fl.l_type = F_UNLCK;
    if(fcntl(fd, F_SETLK, &fl) == -1){
	printf("(%s %d) error on fcntl: %s\n", prog_name, id, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    close(fd);
    
    return found;
}

void recover_from_log_file()
{
    int i, fd;
    char buffer[MAXLEN];
    
    if((fd = open(log_file, O_RDWR)) == -1) return;
    
    for(i = 0; i < NCHILDREN; i++)
    {
	lseek(fd, i*(MAXLEN+2)+2, SEEK_SET);
	read(fd, buffer, MAXLEN);
	if(strlen(buffer) == 0) continue;
	unlink(buffer);
	printf("(%s) incomplete uploaded file \"%s\" has been deleted\n", prog_name, buffer);
	memset(buffer, 0, MAXLEN);
    }
    
    close(fd);
    unlink(log_file);
}

void child(int old_sock, int id)
{
    int ret, sock, block_size, nseq = 0, nseq_expected = 0;
    char buffer[MAXLEN];
    struct sockaddr_in cliaddr;
    socklen_t cliaddrlen = sizeof(struct sockaddr_in);
    
    //Let's attach our new signal handlers
    set_handler(SIGINT, SIG_IGN);
    set_handler(SIGTSTP, SIG_IGN);
    set_handler(SIGUSR1, sigusr1_handler);
    
    while(1)
    {
	//Let's wait for a new client
	sem_wait(semaphore, id);
	nseq = nseq_expected = 0;
	printf("(%s %d) waiting for a new client\n", prog_name, id);
	Recvfrom (old_sock, id, buffer, MAXLEN, 0, (struct sockaddr *) &cliaddr, &cliaddrlen);
	printf("(%s %d) new connection from %s:%u\n", prog_name, id, inet_ntoa(cliaddr.sin_addr), ntohs(cliaddr.sin_port));
	sem_post(semaphore, id);
	
	//Let's create a new socket
	sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if(socket < 0){
	    printf("(%s %d) error on creating socket: %s\n", prog_name, id, strerror(errno));
	    exit(EXIT_FAILURE);
	}
	
	Sendto(sock, id, "HELLO", 6, 0, (struct sockaddr *) &cliaddr, cliaddrlen);
	memset(buffer, 0, MAXLEN);
	
	while(1)
	{
	    //Let's receive commands from client
	    if(ReliableRecvfrom (sock, id, &nseq_expected, buffer, MAXLEN, 0, (struct sockaddr *) &cliaddr, &cliaddrlen) == -1)
		break;
	    ret = parse_command(buffer, &block_size);
	    if(ret == QUIT){
		printf("(%s %d) client from %s:%u quitted\n", prog_name, id, inet_ntoa(cliaddr.sin_addr), ntohs(cliaddr.sin_port));
		close(sock);
		break;
	    }else if(ret == LS){
		if(client_ls(sock, id, &nseq, &nseq_expected, cliaddr, cliaddrlen) == -1)
		    break;
	    }else if(ret == PWD){
		if(client_pwd(sock, id, &nseq, &nseq_expected, cliaddr, cliaddrlen) == -1)
		    break;
	    }else if(ret == CD){
		if(client_cd(sock, id, &nseq, &nseq_expected, buffer, cliaddr, cliaddrlen) == -1)
		    break;
	    }else if(ret == RM){
		if(client_rm(sock, id, &nseq, &nseq_expected, buffer, cliaddr, cliaddrlen) == -1)
		    break;
	    }else if(ret == UP){
		if(client_upload(sock, id, &nseq, &nseq_expected, buffer, cliaddr, cliaddrlen) == -1)
		    break;
	    }else if(ret == DOWN){
		if(client_download(sock, id, &nseq, &nseq_expected, buffer, block_size, cliaddr, cliaddrlen) == -1)
		    break;
	    }else{
		printf("(%s %d) %s - unknown command from %s:%u\n", prog_name, id, buffer+HEADER_LENGTH, inet_ntoa(cliaddr.sin_addr), ntohs(cliaddr.sin_port));
	    }
	    memset(buffer, 0, MAXLEN);
	}
    }
}

int client_pwd(int sock, int id, int * nseq, int * nseq_expected, struct sockaddr_in client, int cliaddrlen)
{
    char buffer[MAXLEN];
    
    memset(buffer, 0, MAXLEN);
    if(connect(sock, (struct sockaddr *) &client, cliaddrlen) != 0){
	printf("(%s %d) error on connect: %s\n", prog_name, id, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    if(getcwd(buffer, MAXLEN-HEADER_LENGTH) == NULL){
	memset(buffer, 0, MAXLEN);
	printf("(%s %d) error on opening current working directory: %s\n", prog_name, id, strerror(errno));
	sprintf(buffer, "%s", ERR);
	make_packet(*nseq, strlen(buffer), buffer);
	if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0)
	    return -1;
	else
	    return -2;
    }
    make_packet(*nseq, strlen(buffer), buffer);
    if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0)
	return -1;
    else
	return 1;
}

int client_cd(int sock, int id, int * nseq, int * nseq_expected, const char * newdir, struct sockaddr_in client, int cliaddrlen)
{
    char buffer[MAXLEN], temp[MAXLEN];
    
    if(connect(sock, (struct sockaddr *) &client, cliaddrlen) != 0){
	printf("(%s %d) error on connect: %s\n", prog_name, id, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    if(chdir(newdir) < 0){
	memset(buffer, 0, MAXLEN);
	printf("(%s %d) error on changing current working directory: %s - %s\n", prog_name, id, newdir, strerror(errno));
	sprintf(buffer, "%s", ERR);
	make_packet(*nseq, strlen(buffer), buffer);
	if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0)
	    return -1;
	else
	    return -2;
    }
    getcwd(temp, MAXLEN-HEADER_LENGTH);
    sprintf(buffer, "%s", temp);
    make_packet(*nseq, strlen(buffer), buffer);
    if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0)
	return -1;
    else
	return 1;
}

int client_rm(int sock, int id, int * nseq, int * nseq_expected, const char * file, struct sockaddr_in client, int cliaddrlen)
{
    char buffer[MAXLEN];
    
    if(connect(sock, (struct sockaddr *) &client, cliaddrlen) != 0){
	printf("(%s %d) error on connect: %s\n", prog_name, id, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    if(unlink(file) < 0){
	memset(buffer, 0, MAXLEN);
	printf("(%s %d) error on deleting %s: %s\n", prog_name, id, file, strerror(errno));
	sprintf(buffer, "%s", ERR);
	make_packet(*nseq, strlen(buffer), buffer);
	if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0)
	    return -1;
	else
	    return -2;
    }
    
    memset(buffer, 0, MAXLEN);
    sprintf(buffer, "%s", OK);
    make_packet(*nseq, strlen(buffer), buffer);
    if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0)
	return -1;
    return 1;
}

int client_ls(int sock, int id, int * nseq, int * nseq_expected, struct sockaddr_in client, int cliaddrlen)
{
    DIR * dir;
    char buffer[MAXLEN];
    char * ls_buffer = NULL;
    struct dirent * dir_struct;
    struct stat info;
    int fd, toSend, left_to_send, len = 0, index = 0;
    memset(buffer, 0, MAXLEN);
    
    if(connect(sock, (struct sockaddr *) &client, cliaddrlen) != 0){
	printf("(%s %d) error on connect: %s\n", prog_name, id, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    if((dir = opendir(".")) == NULL)
    {
	memset(buffer, 0, MAXLEN);
	printf("(%s %d) error on opening current working directory\n", prog_name, id);
	sprintf(buffer, "%s", ERR);
	make_packet(*nseq, strlen(buffer), buffer);
	if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0)
	    return -1;
	else
	    return -2;
    }
    
    sprintf(buffer, "%s", OK);
    make_packet(*nseq, strlen(buffer), buffer);
    if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0) return -1;
    
    while((dir_struct = readdir(dir)) != NULL)
    {	
	if(dir_struct->d_type == DT_REG)
	{
	    len += strlen(dir_struct->d_name) + 2;
	    if((fd = open(dir_struct->d_name, O_RDONLY)) == -1){
		memset(buffer, 0, MAXLEN);
		printf("(%s %d) error on opening \"%s\": %s\n", prog_name, id, dir_struct->d_name, strerror(errno));
		sprintf(buffer, "%s", ERR);
		make_packet(*nseq, strlen(buffer), buffer);
		if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0)
		    return -1;
		else
		    return -2;
	    }
	    
	    fstat(fd, &info);
	    sprintf(buffer, "%u", (unsigned int)info.st_size);
	    len += (strlen(buffer)+7);
	    close(fd);
	}
	else if(dir_struct->d_type == DT_DIR)
	{
	    len += strlen(dir_struct->d_name) + 1;
	}
    }
    rewinddir(dir);
    
    //Let's make room for '\0'
    len++;
    ls_buffer = (char *)malloc(len);
    memset(ls_buffer, 0, len);
    
    while((dir_struct = readdir(dir)) != NULL)
    {	
	if(dir_struct->d_type == DT_DIR && strcmp(dir_struct->d_name, ".") && strcmp(dir_struct->d_name, ".."))
	{
	    strcat(ls_buffer+index, dir_struct->d_name);
	    index += strlen(dir_struct->d_name);
	    strcat(ls_buffer, "\n");
	    index += 1;
	}
    }
    rewinddir(dir);
    while((dir_struct = readdir(dir)) != NULL)
    {
	if(dir_struct->d_type == DT_REG)
	{
	    
	    strcpy(ls_buffer+index, dir_struct->d_name);
	    index += strlen(dir_struct->d_name);
	    strcat(ls_buffer+index, ": ");
	    index += 2;
	    
	    if((fd = open(dir_struct->d_name, O_RDONLY)) == -1){
		memset(buffer, 0, MAXLEN);
		printf("(%s %d) error on opening \"%s\": %s\n", prog_name, id, dir_struct->d_name, strerror(errno));
		sprintf(buffer, "%s", ERR);
		make_packet(*nseq, strlen(buffer), buffer);
		if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0){
		    free(ls_buffer);
		    return -1;
		}else{
		    free(ls_buffer);
		    return -2;
		}
	    }
	    
	    fstat(fd, &info);
	    sprintf(buffer, "%u", (unsigned int)info.st_size);
	    strcat(ls_buffer+index, buffer);
	    index += strlen(buffer);
	    strcat(ls_buffer+index, " bytes\n");
	    index += 7;
	    close(fd);
	}
    }
    
    //Let's send the client the ls_buffer size
    memset(buffer, 0, MAXLEN);
    sprintf(buffer, "%010d", len);
    make_packet(*nseq, strlen(buffer), buffer);
    if(ReliableSend(sock, id, nseq, buffer, HEADER_LENGTH+10, 0) < 0){
	free(ls_buffer);
	return -1;
    }
    memset(buffer, 0, MAXLEN);
    
    left_to_send = len;
    index = 0;
    
    //Let's send the "ls" command result
    while(left_to_send > 0)
    {
	toSend = (left_to_send > MAXLEN-HEADER_LENGTH) ? MAXLEN-HEADER_LENGTH : left_to_send;
	memcpy(buffer, ls_buffer+(len-left_to_send), toSend);
	make_packet(*nseq, toSend, buffer);
	if(ReliableSend(sock, id, nseq, buffer, toSend+HEADER_LENGTH, 0) == -1){
	    free(ls_buffer);
	    return -1;
	}
	memset(buffer, 0, MAXLEN);
	left_to_send -= toSend;
    }
    
    //EOF, let's send an empty message
    make_packet(*nseq, 0, buffer);
    if(ReliableSend(sock, id, nseq, buffer, HEADER_LENGTH, 0) < 0){
	free(ls_buffer);
	return -1;
    }
    
    free(ls_buffer);
    return 1;
}

int client_upload(int sock, int id, int * nseq, int * nseq_expected, char * file, struct sockaddr_in client, int cliaddrlen)
{
    char buffer[MAXLEN];
    int nRead, nWrite, fdW, file_size, nReceived = 0;
    
    if(connect(sock, (struct sockaddr *) &client, cliaddrlen) != 0){
	printf("(%s %d) error on connect: %s\n", prog_name, id, strerror(errno));
	exit(EXIT_FAILURE);
    }

    memset(buffer, 0, MAXLEN);
    //Let's see if the file already exists
    if((fdW = open(file, O_RDONLY)) > 0)
    {
	memset(buffer, 0, MAXLEN);
	printf("(%s %d) client is trying to upload an already existing file (%s)\n", prog_name, id, file);
	close(fdW);
	sprintf(buffer, "%s", ERREXISTS);
	make_packet(*nseq, strlen(buffer), buffer);
	if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0)
	    return -1;
	
	memset(buffer, 0, MAXLEN);
	if(ReliableRecv(sock, id, nseq_expected, buffer, MAXLEN, 0) < 0) return -1;
	if(!strcmp(buffer+HEADER_LENGTH, CMD_DONOTHING))
	{
	    printf("(%s %d) upload aborted\n", prog_name, id);
	    return -2;
	}
	else if(!strcmp(buffer+HEADER_LENGTH, CMD_OVERWRITE))
	{
	    //We can overwrite only if no one is downloading or uploading this file
	    if(find_in_log(id, DOWN, file) || find_in_log(id, UP, file))
	    {
		printf("(%s %d) unable to overwrite \"%s\", file is busy\n", prog_name, id, file);
		memset(buffer, 0, MAXLEN);
		sprintf(buffer, "%s", ERR);
		make_packet(*nseq, strlen(buffer), buffer);
		if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0)	return -1;
		return -2;
	    }
	    else
	    {
		record_upload(id, file);
		memset(buffer, 0, MAXLEN);
		sprintf(buffer, "%s", OK);
		make_packet(*nseq, strlen(buffer), buffer);
		if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0){
		    remove_upload(id, file);
		    return -1;
		}
		printf("(%s %d) overwriting file \"%s\"\n", prog_name, id, file);
	    }
	}
	else //Rename
	{
	    while(1)
	    {
		memset(buffer, 0, MAXLEN);
		if(ReliableRecv(sock, id, nseq_expected, buffer, MAXLEN, 0) < 0) return -1;
		strcpy(buffer, buffer+HEADER_LENGTH);		
		if((fdW = open(buffer, O_RDONLY)) > 0)
		{
		    close(fdW);
		    memset(buffer, 0, MAXLEN);
		    sprintf(buffer, "%s", ERREXISTS);
		    make_packet(*nseq, strlen(buffer), buffer);
		    if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0)
			return -1;
		}
		else
		{
		    strcpy(file, buffer+HEADER_LENGTH);
		    record_upload(id, file);
		    memset(buffer, '\0', MAXLEN);
		    sprintf(buffer, "%s", OK);
		    make_packet(*nseq, strlen(buffer), buffer);
		    if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0){
			remove_upload(id, file);
			return -1;
		    }
		    break;
		}
	    }
	}
    }
    else
    {
	record_upload(id, file);
	close(fdW);
	memset(buffer, 0, MAXLEN);
	sprintf(buffer, "%s", OK);
	make_packet(*nseq, strlen(buffer), buffer);
	if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0){
	    remove_upload(id, file);
	    return -1;
	}
    }

    //let's create the file
    if((fdW = open(file, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR)) == -1){
	remove_upload(id, file);
	memset(buffer, 0, MAXLEN);
	printf("(%s %d) error on creating \"%s\": %s\n", prog_name, id, file, strerror(errno));
	sprintf(buffer, "%s", ERR);
	make_packet(*nseq, strlen(buffer), buffer);
	if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0)
	    return -1;
	else
	    return -2;
    }
    memset(buffer, 0, MAXLEN);
    
    //Let's receive the file size
    if((nRead = ReliableRecv(sock, id, nseq_expected, buffer, MAXLEN, 0)) < 0){
	memset(buffer, 0, MAXLEN);
	printf("(%s %d) error on receiving file size\n", prog_name, id);
	close(fdW);
	remove_upload(id, file);
	unlink(file);
	return -1;
    }
    file_size = atoi(buffer+HEADER_LENGTH);
	
    //Let's start the actual upload
    printf("(%s %d) receiving file \"%s\" from %s:%u\n", prog_name, id, file, inet_ntoa(client.sin_addr), ntohs(client.sin_port));
    while((nRead = ReliableRecv(sock, id, nseq_expected, buffer, MAXLEN, 0)) > 0)
    {
	if(!strcmp(buffer+HEADER_LENGTH, CMD_STOP))
	{
	    printf("(%s %d) upload aborted by client\n", prog_name, id);
	    close(fdW);
	    unlink(file);
	    remove_upload(id, file);
	    return -2;
	}
	nWrite = write(fdW, buffer+HEADER_LENGTH, nRead);

	if(nWrite != nRead)
	{
	    printf("(%s) an error on write occurred. %d bytes written instead of %d. Aborting\n", prog_name, nWrite, nRead);
	    close(fdW);
	    unlink(file);
	    remove_upload(id, file);
	    memset(buffer, 0, MAXLEN);
	    sprintf(buffer, "%s", ERR);
	    make_packet(*nseq, strlen(buffer), buffer);
	    if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0){
		return -1;
	    }else{
		return -2;
	    }
	}
	else
	{
	    memset(buffer, 0, MAXLEN);
	    sprintf(buffer, "%s", OK);
	    make_packet(*nseq, strlen(buffer), buffer);
	    if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0){
		close(fdW);
		unlink(file);
		remove_upload(id, file);
		return -1;
	    }
	}
	nReceived += nWrite;
	printf("(%s %d) bytes received: %u/%u (%3.3f %%)\n", prog_name, id, nReceived, file_size, (nReceived/(file_size * 1.0)*100));
	memset(buffer, 0, MAXLEN);
    }
    if(nRead < 0)
    {
	close(fdW);
	unlink(file);
	remove_upload(id, file);
	return -1;
    }
    printf("(%s %d) upload file \"%s\" from %s:%u completed\n", prog_name, id, file, inet_ntoa(client.sin_addr), ntohs(client.sin_port));
    close(fdW);
    remove_upload(id, file);
    return 1;
}

int client_download(int sock, int id, int * nseq, int * nseq_expected, const char * file, int block_size, struct sockaddr_in client, int cliaddrlen)
{
    char buffer[MAXLEN], temp[MAXLEN];
    int fdR, nRead, file_size, left_to_send;
    struct stat info;
    memset(buffer, 0, MAXLEN);
    
    if(connect(sock, (struct sockaddr *) &client, cliaddrlen) != 0){
	printf("(%s %d) error on connect: %s\n", prog_name, id, strerror(errno));
	exit(EXIT_FAILURE);
    }
    
    //(1) Is a file with the same name currently in upload?
    if(find_in_log(id, UP, file)){
	memset(buffer, 0, MAXLEN);
	printf("(%s %d) access to \"%s\" denied: file currently in upload\n", prog_name, id, file);
	sprintf(buffer, "%s", ERRBUSY);
	make_packet(*nseq, strlen(buffer), buffer);
	if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0)
	    return -1;
	else
	    return -2;
    }
    
    //(2) Does the file the client wants to download exist?
    if((fdR = open(file, O_RDONLY)) == -1){
	memset(buffer, 0, MAXLEN);
	printf("(%s %d) error on opening \"%s\": %s\n", prog_name, id, file, strerror(errno));
	sprintf(buffer, "%s", ERREXISTS);
	make_packet(*nseq, strlen(buffer), buffer);
	if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0)
	    return -1;
	else
	    return -2;
    }
    
    fstat(fdR, &info);
    file_size = (unsigned int) info.st_size;
    
    //Everything is OK
    sprintf(buffer, "%s", OK);
    make_packet(*nseq, strlen(buffer), buffer);
    if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0) return -1;    
    left_to_send = file_size;
    
    //Let's send the client the file size
    memset(buffer, 0, MAXLEN);
    sprintf(buffer, "%010d", file_size);
    make_packet(*nseq, strlen(buffer), buffer);
    if(ReliableSend(sock, id, nseq, buffer, HEADER_LENGTH+10, 0) < 0){
	close(fdR);
	return -1;
    }
    
    record_download(id, file);
    
    //Let's start the actual download
    printf("(%s %d) sending file \"%s\" to %s:%u with %d bytes fragments\n", prog_name, id, file, inet_ntoa(client.sin_addr), ntohs(client.sin_port), block_size);
    while(left_to_send > 0)
    {
	//Let's receive the request for the next fragment or an error
	memset(buffer, 0, MAXLEN);
	if(ReliableRecv(sock, id, nseq_expected, buffer, MAXLEN, 0) < 0){
	    printf("(%s %d) error on receiving request for next fragment\n", prog_name, id);
	    close(fdR);
	    remove_download(id, file);
	    return -1;
	}
	memset(temp, 0, MAXLEN);
	sscanf(temp, "%*s %d %*s", &block_size);
	if(!strcmp(buffer+HEADER_LENGTH, CMD_STOP)){
	    printf("(%s %d) download aborted by client\n", prog_name, id);
	    close(fdR);
	    remove_download(id, file);
	    return -2;
	}else if(!strcmp(buffer+HEADER_LENGTH, ERR)){
	    printf("(%s %d) download aborted. An error occured on client\n", prog_name, id);
	    close(fdR);
	    remove_download(id, file);
	    return -2;
	}
	nRead = read(fdR, buffer, block_size);
	make_packet(*nseq, nRead, buffer);
	if(ReliableSend(sock, id, nseq, buffer, nRead+HEADER_LENGTH, 0) == -1){
	    remove_download(id, file);
	    return -1;
	}
	memset(buffer, 0, MAXLEN);
	left_to_send -= nRead;
	printf("(%s %d) bytes sent: %u/%u (%3.3f %%)\n", prog_name, id, file_size-left_to_send, file_size, ((file_size-left_to_send)/(file_size * 1.0)*100));
    }

    //EOF, let's send an empty message if file_size is an integer multiple of block_size
    if(file_size%block_size == 0)
    {
	//Let's receive the request for the next fragmet
	if(ReliableRecv(sock, id, nseq_expected, buffer, MAXLEN, 0) < 0){
	    printf("(%s %d) error on receiving request for next fragment\n", prog_name, id);
	    close(fdR);
	    remove_download(id, file);
	    return -1;
	}
	make_packet(*nseq, 0, buffer);
	if(ReliableSend(sock, id, nseq, buffer, strlen(buffer), 0) < 0){
	    close(fdR);
	    remove_download(id, file);
	    return -1;
	}
    }
    printf("(%s %d) download file \"%s\" from %s:%u completed\n", prog_name, id, file, inet_ntoa(client.sin_addr), ntohs(client.sin_port));
    close(fdR);
    remove_download(id, file);
    return 1;
}

int parse_command(char * buffer, int * block_size)
{
    char temp[MAXLEN], temp2[MAXLEN];
    int i, end_of_path_index, index = 0;
    strncpy(temp, buffer, MAXLEN);
    memset(temp2, 0, MAXLEN);
    
    //Let's remove all trailing spaces and '\n'
    for(i = strlen(temp)-1; temp[i] == ' ' || temp[i] == '\n'; i--)
	temp[i] = '\0';
    
    if(!strcmp(temp+HEADER_LENGTH, CMD_STOP))
	return STOP;
    else if(!strcmp(temp+HEADER_LENGTH, CMD_QUIT))
	return QUIT;
    else if(!strcmp(temp+HEADER_LENGTH, CMD_LS))
	return LS;
    else if(!strcmp(temp+HEADER_LENGTH, CMD_PWD))
	return PWD;
    else if(!strcmp(temp, CMD_OVERWRITE) || !strcmp(temp, "O"))
	return OVERWRITE;
    else if(!strcmp(temp, CMD_RENAME) || !strcmp(temp, "R"))
	return RENAME;
    else if(!strcmp(temp, CMD_DONOTHING) || !strcmp(temp, "N"))
	return DONOTHING;
    else if(strstr(temp+HEADER_LENGTH, CMD_CD) == temp+HEADER_LENGTH)
    {
	index = 0;
	for(i = HEADER_LENGTH+strlen(CMD_CD); temp[i] == ' '; i++);
	for(; temp[i] != '\0'; i++)
	    buffer[index++] = temp[i];
	buffer[index] = '\0';
	return CD;
    }
    else if(strstr(temp+HEADER_LENGTH, CMD_RM) == temp+HEADER_LENGTH)
    {
	index = 0;
	for(i = HEADER_LENGTH+strlen(CMD_RM); temp[i] == ' '; i++);
	for(; temp[i] != '\0'; i++)
	    buffer[index++] = temp[i];
	buffer[index] = '\0';
	return RM;
    }
    else if(strstr(temp+HEADER_LENGTH, CMD_UP) == temp+HEADER_LENGTH)
    {
	index = 0;
	for(i = HEADER_LENGTH+strlen(CMD_UP); temp[i] == ' '; i++);
	for(; temp[i] != '\0'; i++)
	    buffer[index++] = temp[i];
	buffer[index] = '\0';
	return UP;
    }
    else if(strstr(temp+HEADER_LENGTH, CMD_DOWN) == temp+HEADER_LENGTH)
    {
	index = 0;
	for(i = strlen(buffer)-1; temp[i] != ' '; i--);
	for(; temp[i] != '\0'; i++)
	    temp2[index++] = temp[i];
	*block_size = atoi(temp2);
	
	memset(temp2, 0, MAXLEN);
	index = 0;
	
	for(i = strlen(buffer)-1; temp[i] != ' '; i--);
	for(; temp[i] == ' '; i--);
	end_of_path_index = i;
	for(i = HEADER_LENGTH+strlen(CMD_DOWN); temp[i] == ' '; i++);
	for(; i <= end_of_path_index; i++)
	    temp2[index++] = temp[i];
	temp2[index] = '\0';
	
	strcpy(buffer, temp2);
	return DOWN;
    }
    else
	return UNKNOWN;
}

void make_packet(int seq, int len, char * to)
{
    int from_index = 0, to_index = HEADER_LENGTH;
    char temp[MAXLEN];
    memcpy(temp, to, MAXLEN);
    sprintf(to, "[%s%010d]", HEADER_SEQ, seq);
    while(len-- > 0)
	to[to_index++] = temp[from_index++];
}

int get_seq_number(const char * packet)
{
    int i = 1 + strlen(HEADER_SEQ), index = 0;
    char sequence_number[11];
    for(; index < 10; i++, index++)
	sequence_number[index] = packet[i];
    sequence_number[index] = '\0';
    return atoi(sequence_number);
}

int get_ack_number(const char * packet)
{
    int i, index = 0;
    char ack_number[11];
    for(i = 5; i < HEADER_LENGTH-1; i++, index++)
	ack_number[index] = packet[i];
    ack_number[index] = '\0';
    return atoi(ack_number);
}

int ReliableSend (int sock, int id, int * nseq, const char * buffer, int nbytes, int flags)
{
    int timeout_count = 0, ret;
    char ack[HEADER_LENGTH];
    
    while(1)
    {
	simulate(sleep(1));
	Send(sock, id, buffer, nbytes, flags);
	ret = Recvtimeout(sock, ack, HEADER_LENGTH, TIMEOUT);
	if(ret == -2){
	    if(++timeout_count == TIMEOUT_LIMIT){
		printf("(%s %d) timeout limit reached. Connection with client lost\n", prog_name, id);
		return -1;
	    }
	}else if(ret == -1){
	    printf("(%s %d) error on receive(): %s\n", prog_name, id, strerror(errno));
	    return -1;
	}else if(ret == 0){
	    printf("(%s %d) client crashed\n", prog_name, id);
	    return -1;
	}else{
	    if(!strcmp(ack, CMD_STOP)){
		(void)(*nseq)++; //in order to suppress warning
		return -2;
	    }
	    else if(*nseq == get_ack_number(ack)){
		(void)(*nseq)++; //in order to suppress warning
		return 1;
	    }
	    else
		continue;
	}
    }
    return 1; //Never reached
}

int ReliableSendto (int sock, int id, int * nseq, const char * buffer, int nbytes, int flags, const struct sockaddr * endpoint, socklen_t endpointlen)
{
    int timeout_count = 0, ret;
    char ack[HEADER_LENGTH];
    
    while(1)
    {
	Sendto(sock, id, buffer, nbytes, flags, endpoint, endpointlen);
	ret = Recvtimeout(sock, ack, HEADER_LENGTH, TIMEOUT);
	if(ret == -2){
	    if(++timeout_count == TIMEOUT_LIMIT){
		printf("(%s %d) timeout limit reached. Connection with client lost\n", prog_name, id);
		return -1;
	    }
	}else if(ret == -1){
	    printf("(%s %d) error on receive(): %s\n", prog_name, id, strerror(errno));
	    return -1;
	}else if(ret == 0){
	    printf("(%s %d) client crashed\n", prog_name, id);
	    return -1;
	}else{
	    if(!strcmp(ack, CMD_STOP)){
		(void)(*nseq)++; //in order to suppress warning
		return -2;
	    }
	    else if(*nseq == get_ack_number(ack)){
		(void)(*nseq)++; //in order to suppress warning
		return 1;
	    }
	    else
		continue;
	}
    }
    return 1; //Never reached
}

int ReliableRecv(int sock, int id, int * nseq_expected, char * buffer, int nbytes, int flags)
{
    int timeout_count = 0, ret, seq_number_received;
    char temp[100];
    
    while(1)
    {
	simulate(sleep(1));
	ret = Recvtimeout(sock, buffer, nbytes, TIMEOUT);
	if(ret == -2){
	    if(++timeout_count == TIMEOUT_LIMIT){
		printf("(%s %d) timeout limit reached. Connection with client lost\n", prog_name, id);
		return -1;
	    }
	}else if(ret == -1){
	    printf("(%s %d) error on receive(): %s\n", prog_name, id, strerror(errno));
	    return -1;
	}else if(ret == 0){
	    printf("(%s %d) server crashed\n", prog_name, id);
	    return -1;
	}else{
	    seq_number_received = get_seq_number(buffer);
	    if(seq_number_received == *nseq_expected){
		//Send ack for correct received sequence number
		sprintf(temp, "[ACK:%010d]", seq_number_received);
		Send(sock, id, temp, HEADER_LENGTH, flags);
		(void)(*nseq_expected)++; //in order to suppress warning
		return ret-HEADER_LENGTH;
	    }
	    else{
		//Send ack for previous sequence number received
		printf("(%s %d) expected sequence number (%d) but (%d) received. Packet discarded\n", prog_name, id, *nseq_expected, seq_number_received);
		sprintf(temp, "[ACK:%010d]", seq_number_received);
		Send(sock, id, temp, HEADER_LENGTH, flags);
	    }
	}
    }
    return 1; //Never reached
}

int ReliableRecvfrom(int sock, int id, int * nseq_expected, char * buffer, int nbytes, int flags, struct sockaddr * endpoint, socklen_t * endpointlen)
{
    int timeout_count = 0, ret, seq_number_received;
    char temp[100];
    
    while(1)
    {
	ret = Recvfromtimeout(sock, buffer, nbytes, TIMEOUT, endpoint, endpointlen);
	if(ret == -2){
	    if(++timeout_count == 3*TIMEOUT_LIMIT){
		printf("(%s %d) timeout limit reached. Connection with client lost\n", prog_name, id);
		return -1;
	    }
	}else if(ret == -1){
	    printf("(%s %d) error on receive(): %s\n", prog_name, id, strerror(errno));
	    return -1;
	}else if(ret == 0){
	    printf("(%s %d) client crashed\n", prog_name, id);
	    return -1;
	}else{
	    seq_number_received = get_seq_number(buffer);
	    if(seq_number_received == *nseq_expected){	    
		//Send ack for correct received sequence number
		sprintf(temp, "[ACK:%010d]", seq_number_received);
		Sendto(sock, id, temp, HEADER_LENGTH, flags, endpoint, *endpointlen);
		(void)(*nseq_expected)++; //in order to suppress warning
		return ret;
	    }
	    else{
		//Send ack for previous sequence number received
		printf("(%s %d) expected sequence number '%d' but '%d' was received. Packet discarded\n", prog_name, id, *nseq_expected, seq_number_received);
		sprintf(temp, "[ACK:%010d]", seq_number_received);
		Sendto(sock, id, temp, HEADER_LENGTH, flags, endpoint, *endpointlen);
	    }
	}
    }
    return 1; //Never reached
}

int Recv(int fd, int id, char * bufptr, int nbytes, int flags)
{
    int n;
    if ((n = recv(fd, bufptr, nbytes, flags)) < 0)
	printf("(%s %d) error on recv(): %s\n", prog_name, id, strerror(errno));
    return n;
}

int Recvfrom (int fd, int id, char * bufptr, int nbytes, int flags, struct sockaddr * sa, socklen_t * salenptr)
{
    int n;
    if ((n = recvfrom(fd, bufptr, nbytes, flags, sa, salenptr)) < 0)
	printf("(%s %d) error on recvfrom(): %s\n", prog_name, id, strerror(errno));
    return n;
}

int Recvtimeout(int s, char * buf, int len, int timeout)
{
    fd_set fds;
    int n;
    struct timeval tv;
    
    FD_ZERO(&fds);
    FD_SET(s, &fds);
    
    tv.tv_sec = timeout;
    tv.tv_usec = 0;
    
    n = select(s+1, &fds, NULL, NULL, &tv);
    if (n == 0) return -2;
	if (n == -1) return -1;
	    return recv(s, buf, len, 0);
}

int Recvfromtimeout(int s, char * buf, int len, int timeout, struct sockaddr * endpoint, socklen_t * endpointlen)
{
    fd_set fds;
    int n;
    struct timeval tv;
    
    FD_ZERO(&fds);
    FD_SET(s, &fds);
    
    tv.tv_sec = timeout;
    tv.tv_usec = 0;
    
    n = select(s+1, &fds, NULL, NULL, &tv);
    if (n == 0) return -2;
	if (n == -1) return -1;
	    return recvfrom(s, buf, len, 0, endpoint, endpointlen);
}

int Sendto (int fd, int id, const char * bufptr, int nbytes, int flags, const struct sockaddr * sa, socklen_t salen)
{
    int n;
    if ((n = sendto(fd, bufptr, nbytes, flags, sa, salen)) != nbytes)
	printf("(%s %d) error on sendto(): %s\n", prog_name, id, strerror(errno));
    return n;
}

int Send (int fd, int id, const char * bufptr, int nbytes, int flags)
{
    int n;
    if ((n = send(fd,bufptr,nbytes,flags)) != nbytes)
	printf("(%s %d) error on send(): %s\n", prog_name, id, strerror(errno));
    return n;
}