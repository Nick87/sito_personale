/* 
 * Per la corretta esecuzione del programma � necessario aver installato
 * wget per Windows, liberamente scaricabile dal sito:
 * 
 * http://xoomer.virgilio.it/hherold/
 *
 * @Nicola Alessandro Domingo
 */ 

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

#define DIM_IP       20

int main()
{
   FILE * input;
   char ip_address[DIM_IP];

   memset(ip_address, 0, DIM_IP);
   
   system("wget -q http://www.indirizzo-ip.com/ip.php?.txt --output-document=C:\\ip.txt");
    
   if ((input = fopen("C:\\ip.txt", "r")) == NULL)
   {
      printf("Impossibile aprire il file! Errore %d\n", errno);
      exit(EXIT_FAILURE);
   }
   
   fscanf(input, "%s", ip_address);
   printf("INDIRIZZO IP PUBBLICO: %s\n", ip_address);
   fclose(input);
   
   system("del C:\\ip.txt");   
   
   return EXIT_SUCCESS;
}
