#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>

#define TRUE  1
#define FALSE 0
#define SIZE 100

int ** init_board (int **);
void free_board (int **);
int * init_vettore (int *);
void free_vettore (int *);
void free_players (int *);
void put_final_board (char *, int **);
int partita_vinta (int **);
char to_char (int);
void error(char *) __attribute__ ((noreturn));

int main(int argc, char * argv[])
{
	struct sockaddr_in serv_addr, cli_addr;
	int ** board;
	int * vett;
	int i, res, listener, reuseaddr = TRUE, newfd, portno, nbytes, col, clilen, player = 0, n_moves = 0, fds[2] = {0};
	char buffer[SIZE];
	bzero(buffer, SIZE);
	
	if (argc < 2){
		fprintf(stderr,"Usage: %s port\n", argv[0]);
		exit(EXIT_FAILURE);
	}
	
	if((listener = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		error("ERROR opening socket");
	if(setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, &reuseaddr, sizeof(int)) == -1)
		error("ERROR setting socket");

	bzero((char *) &serv_addr, sizeof(serv_addr));
	portno = atoi(argv[1]);
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons(portno);

	if(bind(listener, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) 
		error("ERROR on binding");
	if(listen(listener, 5) < 0)
		error("ERROR on listening. ");
	printf("Server in ascolto\n");
	
	while(1)
	{
		start:
		board = init_board (board);
		vett = init_vettore (vett);
		for (i = 0; i < 2; i++)
		{
			clilen = sizeof(struct sockaddr_in);
			if((newfd = accept(listener, (struct sockaddr *)&cli_addr, (socklen_t *)&clilen)) == -1)
				error("ERROR on accept");
			fds[i] = newfd;	
			if(i == 0)
				strcpy(buffer, "12XO");
			else
				strcpy(buffer, "21OX");
			if(send(fds[i], buffer, 5, 0) < 0)
				error("ERROR writing to socket");
			bzero(buffer, SIZE);
			printf("Server: nuova connessione da %s sulla socket %d\n", inet_ntoa(cli_addr.sin_addr), newfd);
		}

		//Sblocchiamo il primo client
		if(send(fds[0], "Sblocco", 8, 0) < 0)
			error("ERROR writing to socket");
			
		while(1)
		{
			while(1)
			{
				printf("1\n");//Perche' senza questa printf si blocca qui il programma?
				if(send(fds[player], "Colonna", 11, 0) < 0)
					error("ERROR writing to socket");
				
				//Riceviamo la colonna
				if((nbytes = recv(fds[player], buffer, SIZE, 0)) <= 0)
				{
					if(nbytes == 0)
					{
						reset:
						free_board(board);
						free_vettore(vett);
						free_players(fds);
						player = n_moves = 0;
						bzero(buffer, SIZE);
						goto start;
					}
					else
						error("ERROR on recv");
				}

				col = buffer[0]-'0';
				vett[col-1]++;
				board[7-vett[col-1]][col-1] = (player+1);
				bzero(buffer, SIZE);
				res = partita_vinta(board);

				if(++n_moves == 49)
				{
					if(res == -1)//Partita finisce con pareggio
					{
						printf("La partita finisce in pareggio!\n");
						for(i = 0; i < 2; i++)
							if(send(fds[i], "1-", SIZE, 0) < 0)
								error("ERROR writing to socket");
					}
					else//player vince, (player+1)%2 perde
					{
						end_game:
						printf("Vince il giocatore %c\n", (player == 0) ? 'X' : 'O');
						strcpy(buffer, "11");
						put_final_board(buffer+2, board);
						if(send(fds[player], buffer, SIZE, 0) < 0)
							error("ERROR writing to socket");
						buffer[1] = '0';
						if(send(fds[(player+1)%2], buffer, SIZE, 0) < 0)
							error("ERROR writing to socket");
					}
					goto reset;
				}
				else
				{
					if(res != -1)//player vince, (player+1)%2 perde
						goto end_game;
					else//Dico che partita non e' finita e comunico la colonna
					{
						sprintf(buffer, "0%d", col);
						for(i = 0; i < 2; i++)
							if(send(fds[(player+i)%2], buffer, SIZE, 0) < 0)
								error("ERROR writing to socket");
					}
				}
				player = (player+1)%2;
				bzero(buffer, SIZE);
			}
		}
	}
	return EXIT_SUCCESS; 
}

void error(char *msg)
{
	perror(msg);
	exit(EXIT_FAILURE);
}

int ** init_board(int ** b)
{
	int i, j;
	b = (int **) malloc (7 * sizeof(int *));
	for (i = 0; i < 7; i++)
		b[i] = (int *) malloc (7 * sizeof(int));
	for (i = 0; i < 7; i++)
		for (j = 0; j < 7; j++)
			b[i][j] = 0;
	return b;
}

void free_board (int ** b)
{
	int i;
	for (i = 0; i < 7; i++)
		free(b[i]);
	free(b);
}

int * init_vettore(int * v)
{
	int i;
	v = (int *) malloc (7 * sizeof(int));
	for (i = 0; i <7; i++)
		v[i] = 0;
	return v;
}

void free_vettore(int * v)
{
	free(v);
}

void free_players (int * v)
{
	int i;
	for (i = 0; i < 2; i++)
		if(close(v[i]) < 0)
			fprintf(stderr, "ERROR on closing connection on socket %d\n", v[i]);
}



int partita_vinta(int ** b)
{
	int val, row, col, times;
	int winner = -1;
	int i, j, k;
	int ** matrix = init_board(matrix);
     
	//Controllo in verticale
	for (j = 0; j < 7; j++)
	{
		for (i = 6; i >= 3; i--)
		{
			times = 0;
			if( (val = b[i][j]) != 0)
			{
				for (k = i; k >= i-3; k--)
					if (b[k][j] == val)
						times++;
					else break;
				if (times == 4)
				{
					for (k = i; k >= i-3; k--)
						matrix[k][j] = 3;
					winner = val;
				}
			}
        }
    }

    //Controllo in orizzontale
    for (i = 6; i >= 0; i--)
    {
        for (j = 0; j <= 3; j++)
        {
            times = 0;
            if( (val = b[i][j]) != 0)
            {
                for (k = j; k <= j+3; k++)
                    if(b[i][k] == val)
						times++;
                    else break;
                if (times == 4)
                {
					for (k = j; k <= j+3; k++)
						matrix[i][k] = 3;
					winner = val;
                }
            }
        }
    }
     
    /* Controllo in diagonale \ */
    for (i = 0; i <= 3; i++)
    {
        for (j = 0; j <= 3; j++)
        {
            times = 0;
            if( (val = b[i][j]) != 0)
            {
                for (k = 0; k < 4; k++)
                    if(b[i+k][j+k] == val)
                        times++;
                    else break;
                if (times == 4)
                {
                    for (k = 0; k < 4; k++)
						matrix[i+k][j+k] = 3;
                    winner = val;
                }
            }
        }
    }

    //Controllo in diagonale /
    for (row = 6; row >= 3; row--)
    {
        for (col = 0; col <= 3; col++)
        {
            times = 0;
            if( (val = b[row][col]) != 0)
            {
                for (i = row, j = col; i >= row-3 && j <= col+3; i--, j++)
                    if(b[i][j] == val)
						times++;
                    else break;
                if (times == 4)
                {
					for (i = row, j = col; i >= row-3 && j <= col+3; i--, j++)
						matrix[i][j] = 3;
                    winner = val;
                }
            }
        }
    }
     
    if (winner != -1)
        for (i = 0; i < 7; i++)
			for (j = 0; j < 7; j++)
				if (matrix[i][j] == 3)
					b[i][j] = 3;
	free_board(matrix);
     
    return winner;
}

void put_final_board (char * s, int ** b)
{
	int i, j, index = 0;
	for(i = 0; i < 7; i++)
		for(j = 0; j < 7; j++)
			s[index++] = to_char(b[i][j]);
	s[index] = '\0';
}

char to_char (int val)
{
	char * str = "123";
	return (val == 0) ? '0' : str[val-1];
}
			