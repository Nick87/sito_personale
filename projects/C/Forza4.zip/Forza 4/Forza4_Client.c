#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>

#define SIZE       100
#define VINTO       1
#define PERSO       2
#define PAREGGIO    3
#define TRUE        1
#define FALSE       0

void print_board(int **);
void error(char *) __attribute__ ((noreturn));
void clear_screen();
char print_type (int);
int ** init_board (int **);
void free_board (int **);
int * init_vettore (int *);
void free_vettore (int *);
int fine_partita (char *, int *, int *, int **);
void string_to_matrix (char *, int **);

int main(int argc, char *argv[])
{
	int sockfd, nbytes, portno, colonna, io_player, lui_player, risultato, res;
	int ** board;
	int * vett;
	struct sockaddr_in serv_addr;
	struct hostent * server;
	char mio_simbolo, suo_simbolo, buffer[SIZE];
	bzero(buffer, SIZE);
	
	if (argc < 3){
		fprintf(stderr,"usage %s hostname port\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	portno = atoi(argv[2]);
	if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		error("ERROR opening socket");
	if((server = gethostbyname(argv[1])) == NULL){
		herror("ERROR on gethostbyname");
		exit(EXIT_FAILURE);
	}

	bzero((char *) &serv_addr, sizeof(serv_addr));
	bcopy((char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(portno);
	
	if (connect(sockfd,(struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) 
		error("ERROR on connecting");
	board = init_board(board);
	vett = init_vettore(vett);
	
	//Riceviamo il simbolo nostro seguito da quello dell'avversario
	if((nbytes = recv(sockfd, buffer, SIZE, 0)) <= 0)
	{
		if(nbytes == 0){
			printf("Il server ha chiuso la connessione!\n");
			exit(EXIT_FAILURE);
		}
		else
			error("ERROR on recv");
	}

	io_player = buffer[0]-'0';
	lui_player = buffer[1]-'0';
	mio_simbolo = buffer[2];
	suo_simbolo = buffer[3];
	bzero(buffer, SIZE);
	
	while(1)
	{		
		clear_screen();
		print_board(board);
		
		printf("Attesa avversario...\n");
		//Esito mossa avversaria
		if((nbytes = recv(sockfd, buffer, SIZE, 0)) <= 0)
		{
			if(nbytes == 0){
				printf("Il server ha chiuso la connessione!\n");
				exit(EXIT_FAILURE);
			}
			else
				error("ERROR on recv");
		}

		if(strcmp(buffer, "Sblocco"))
		{
			res = fine_partita(buffer, &risultato, &colonna, board);
			vett[colonna-1]++;
			if(!res)
				board[7-vett[colonna-1]][colonna-1] = lui_player;
			clear_screen();
			print_board(board);
			if(res)
				break;
		}
		bzero(buffer, SIZE);

		//Messaggio del server: "Colonna: "
		if((nbytes = recv(sockfd, buffer, SIZE, 0)) <= 0)
		{
			if(nbytes == 0){
				printf("Il server ha chiuso la connessione!\n");
				exit(EXIT_FAILURE);
			}
			else
				error("ERROR on recv");
		}

		//Input colonna
		do
		{
			printf("%s (tu sei %c): ", buffer, mio_simbolo);
			scanf("%d", &colonna);
		}
		while(colonna < 0 || colonna > 7 || vett[colonna-1] == 7);
		
		vett[colonna-1]++;
		board[7-vett[colonna-1]][colonna-1] = io_player;
		bzero(buffer, SIZE);

		//Invio colonna
		sprintf(buffer, "%d", colonna);
		if(send(sockfd, buffer, SIZE, 0) < 0)
			error("ERROR writing to socket");
		bzero(buffer, SIZE);
		
		//Vediamo se e' fine partita
		if((nbytes = recv(sockfd, buffer, SIZE, 0)) <= 0)
		{
			if(nbytes == 0){
				printf("Il server ha chiuso la connessione!\n");
				exit(EXIT_FAILURE);
			}
			else
				error("ERROR on recv");
		}
	
		if(fine_partita(buffer, &risultato, &colonna, board))
		{
			clear_screen();
			print_board(board);
			break;
		}
	}
	
	if(risultato == VINTO)
		printf("COMPLIMENTI! HAI VINTO!\n");
	else if(risultato == PERSO)
		printf("PECCATO! HAI PERSO\n");
	else
		printf("PAREGGIO!\n");
	
	free_board(board);
	free_vettore(vett);

	return EXIT_SUCCESS;
}

void error(char *msg)
{
	perror(msg);
	exit(EXIT_FAILURE);
}

void clear_screen()
{
	int i;
	for (i = 0; i < 60; i++)
		printf("\n");
}

//Alloca la memoria ed inizializza board
int ** init_board(int ** b)
{
	int i, j;
	b = (int **) malloc (7 * sizeof(int *));
	for (i = 0; i < 7; i++)
		b[i] = (int *) malloc (7 * sizeof(int));
	for (i = 0; i < 7; i++)
		for (j = 0; j < 7; j++)
			b[i][j] = 0;
	return b;
}

//Dealloca la memoria
void free_board (int ** b)
{
	int i;
	for (i = 0; i < 7; i++)
		free(b[i]);
	free(b);
}

//Alloca la memoria e inizializza vett
int * init_vettore(int * v)
{
	int i;
	v = (int *) malloc (7 * sizeof(int));
	for (i = 0; i <7; i++)
		v[i] = 0;
	return v;
}

//Dealloca la memoria
void free_vettore(int * v)
{
	free(v);
}

int fine_partita (char * b, int * ris, int * col, int ** matrix)
{
	if(b[0] == '0')//Non e' finita
	{
		*col = b[1]-'0';
		return FALSE;
	}
	else //E' finita
	{
		if(b[1] == '0')
		{
			*ris = PERSO;
			string_to_matrix(b+2, matrix);
		}
		else if (b[1] == '1')
		{
			*ris = VINTO;
			string_to_matrix(b+2, matrix);
		}
		else
			*ris = PAREGGIO;
		return TRUE;
	}
}

char print_type (int val)
{
     if (val == 0)  return ' ';
     if (val == 1)  return 'X';
     if (val == 2)  return 'O';
     else           return '+';
}

void print_board(int ** b)
{
	int i, j;
	printf("\n\n");
	printf("\t\t   1     2     3     4     5     6     7\n");
    printf("\t\t _____ _____ _____ _____ _____ _____ _____\n");
    for (i = 0; i < 7; i++)
    {
		printf("\t\t|     |     |     |     |     |     |     |\n");
		printf("\t\t");
        for (j = 0; j < 7; j++)
            printf("|  %c  ", print_type(b[i][j]));
        printf("|");
		printf("\n\t\t|_____|_____|_____|_____|_____|_____|_____|\n");
    }
    printf("\n\t\t   1     2     3     4     5     6     7\n\n");
}

void string_to_matrix (char * str, int ** b)
{
	int i, j, index = 0;
	for(i = 0; i < 7; i++)
		for(j = 0; j < 7; j++)
			b[i][j] = str[index++]-'0';
}
