#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <winsock.h>

//system() ritorna solo alla chiusura del file
//Senza ACK ci sono problemi
//A volte va in crash
//Gestione segnali

#define DEFAULT_PORT      "12345"
#define SIZE               1024
#define ACK                 1

void get_public_ip(char *);
void get_error(char *, int);
void make_final_string(char *, const char *);
int  receive_all(char *, long);
clock_t total_time;

int main(int argc, char ** argv)
{
    HANDLE file, hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SOCKET newsock, listener;
    WSADATA wsaData;
	DWORD file_size, bytesWritten;
	CONSOLE_SCREEN_BUFFER_INFO csbInfo;
    COORD CursorPos1, CursorPos2;
	struct sockaddr_in serv_addr, cli_addr;
    double tacche;
    int step, i, err, size = sizeof(struct sockaddr_in), n, received = 0, left_to_receive;    
    unsigned char * buffer;
    char base_path[SIZE], dest_path[SIZE], temp[SIZE], public_ip[20], msg[50];
    
    if ((err = WSAStartup(MAKEWORD(2,2), &wsaData)) != 0){
        sprintf(temp, "Error at WSAStartup(): %d", err);
        MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return EXIT_FAILURE;
    }
    
    printf("Test della connessione...");
    again:
    if(gethostbyname("www.google.it") == NULL)
    {
        if(MessageBox(NULL, TEXT("Connessione non disponibile.\nRiprovare?"),
                      TEXT("Message"), MB_ICONWARNING | MB_YESNO) == IDYES)
        goto again;
        else{
            WSACleanup();
            return EXIT_FAILURE;
        }
    }
    printf("OK\n\n");
    
    printf("IP pubblico da riferire al mittente: ");
    get_public_ip(public_ip);
    printf("%s\n", public_ip);
    
    if((listener = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET){
        sprintf(temp, "Error at socket(): %d", WSAGetLastError());
        WSACleanup();
        MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return EXIT_FAILURE;
    }
    
    ZeroMemory(&serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons(atoi(DEFAULT_PORT));
	
	if(bind(listener, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) == SOCKET_ERROR){
        get_error(msg, WSAGetLastError());
        sprintf(temp, "Error at bind: %s", msg);
        closesocket(listener);
        WSACleanup();
        MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return EXIT_FAILURE;
    }
	
	if (listen(listener, SOMAXCONN) == SOCKET_ERROR){
        get_error(msg, WSAGetLastError());
        sprintf(temp, "Error at listen: %s", msg);
        closesocket(listener);
        WSACleanup();
        MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return EXIT_FAILURE;
    }
    printf("\nAttesa file...\n");

    if((newsock = accept(listener, (struct sockaddr *)&cli_addr, &size)) == INVALID_SOCKET){
        sprintf(temp, "Error at accept: %d", WSAGetLastError());
        closesocket(listener);
        WSACleanup();
        MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return EXIT_FAILURE;
    }
    closesocket(listener);
    
    GetEnvironmentVariable("HOMEDRIVE", dest_path, SIZE);
    GetEnvironmentVariable("HOMEPATH", temp, SIZE);
    strcat(dest_path, temp);
    strcat(dest_path, "\\Desktop\\");
    strcpy(base_path, dest_path);
    ZeroMemory(temp, SIZE);
    
    //Riceviamo il nome del file
    if(recv(newsock, temp, SIZE, 0) == SOCKET_ERROR){
        get_error(msg, WSAGetLastError());
        sprintf(temp, "Error at receiving file name: %s", msg);
        closesocket(newsock);
        WSACleanup();
        MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return EXIT_FAILURE; 
    }
    
    //Per evitare il backslash iniziale del nome del file
	if(temp[0] == '\\')
        for(i = 1; i < SIZE; i++)
            temp[i-1] = temp[i];
        
    printf("Ricezione del file \"%s\" da %s\n", temp, inet_ntoa(cli_addr.sin_addr));
    strcat(dest_path, temp);	
    ZeroMemory(temp, SIZE);
    
    //Invio ack
    if (ACK && send(newsock, "1", 2, 0) == SOCKET_ERROR){
        get_error(msg, WSAGetLastError());
        sprintf(temp, "Error at sending ack: %s", msg);
        closesocket(newsock);
        WSACleanup();
        MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return EXIT_FAILURE;
    }
    
    if((file = CreateFile(dest_path, GENERIC_WRITE,
                          0, NULL, CREATE_NEW,
                          FILE_ATTRIBUTE_NORMAL, NULL)) == INVALID_HANDLE_VALUE)
    {
        FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), 0, msg, SIZE, NULL);
        closesocket(newsock);
        WSACleanup();
        MessageBox(NULL, TEXT(msg), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return EXIT_FAILURE;
    }
    
    //Riceviamo la dimensione del file
    if(recv(newsock, temp, SIZE, 0) == SOCKET_ERROR){
        get_error(msg, WSAGetLastError());
        sprintf(temp, "Error at receiving file size: %s", msg);
        closesocket(newsock);
        CloseHandle(file);
        DeleteFile(dest_path);
        WSACleanup();
        MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return EXIT_FAILURE; 
    }
    file_size = atoi(temp);
    ZeroMemory(temp, SIZE);
    left_to_receive = file_size;
    printf("\nDimensione del file: %.*f MB\n", 2, file_size/1024.0/1024.0);
    
    //Invio ack
    if (ACK && send(newsock, "1", 2, 0) == SOCKET_ERROR){
        get_error(msg, WSAGetLastError());
        sprintf(temp, "Error at sending ack: %s", msg);
        closesocket(newsock);
        WSACleanup();
        CloseHandle(file);
        DeleteFile(dest_path);
        MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return EXIT_FAILURE;
    }
    
    //Riceviamo il numero di step
    if(recv(newsock, temp, SIZE, 0) == SOCKET_ERROR){
        get_error(msg, WSAGetLastError());
        sprintf(temp, "Error at receiving steps: %s", msg);
        closesocket(newsock);
        CloseHandle(file);
        DeleteFile(dest_path);
        WSACleanup();
        MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return EXIT_FAILURE; 
    }
    step = atoi(temp);
    ZeroMemory(temp, SIZE);
    
    //Invio ack
    if (ACK && send(newsock, "1", 2, 0) == SOCKET_ERROR){
        get_error(msg, WSAGetLastError());
        sprintf(temp, "Error at sending ack: %s", msg);
        closesocket(newsock);
        CloseHandle(file);
        DeleteFile(dest_path);
        WSACleanup();
        MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return EXIT_FAILURE;
    }

    printf("\n0         .         *         .         100\n");
    printf("|");
    GetConsoleScreenBufferInfo(hConsole, &csbInfo);
    CursorPos1 = csbInfo.dwCursorPosition;
    printf("                                        |\n ");
    CursorPos2 = CursorPos1;
    CursorPos2.X = 0;
    CursorPos2.Y += 2;
    
    SetConsoleCursorPosition(hConsole, CursorPos2);
    printf("%.*f/%.*f MB (%.*f %%)", 2, received/1024.0/1024.0, 2, file_size/1024.0/1024.0, 2, (double) ((received*1.0)/file_size)*100);
    
    total_time = clock();
	while(received < file_size)
    {
        //Alloco memoria per il buffer di ricezione
        if((buffer = (unsigned char *) malloc(step)) == NULL){
            sprintf(temp, "Impossibile allocare memoria per il file.");
            fclose(file);
            closesocket(newsock);
            WSACleanup();
            CloseHandle(file);
            DeleteFile(dest_path);
            MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
            return EXIT_FAILURE;
        }

        if((n = recv(newsock, buffer, step, 0)) == SOCKET_ERROR){
            get_error(msg, WSAGetLastError());
            sprintf(temp, "Error at receiving file: %s", msg);
            closesocket(newsock);
            free(buffer);
            CloseHandle(file);
            DeleteFile(dest_path);
            WSACleanup();
            MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
            return EXIT_FAILURE;
        }
        
        if(WriteFile(file, buffer, n, &bytesWritten, NULL) == 0){
            FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), 0, msg, 50, NULL);
            sprintf(temp, "Impossibile scrivere il file: %s", msg);
            MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
            CloseHandle(file);
            DeleteFile(dest_path);
            free(buffer); 
            return EXIT_FAILURE;
        }
        FlushFileBuffers(file);
        free(buffer);
        
        received += n;
        left_to_receive -= n;
        if(left_to_receive < step)
           step = left_to_receive;
           
        SetConsoleCursorPosition(hConsole, CursorPos1);
        tacche = (double)40.0*((received*1.0)/file_size);
        for(i = 0; i < (int)tacche-1; i++)
           printf("=");
        printf(">");

        SetConsoleCursorPosition(hConsole, CursorPos2);
        printf("%.*f/%.*f MB (%.*f %%)", 2, received/1024.0/1024.0, 2, file_size/1024.0/1024.0, 2, (double) ((received*1.0)/file_size)*100.0);
        
        //Invio ack
        if (ACK && send(newsock, "1", 2, 0) == SOCKET_ERROR){
            get_error(msg, WSAGetLastError());
            sprintf(temp, "Error at sending ack: %s", msg);
            closesocket(newsock);
            CloseHandle(file);
            DeleteFile(dest_path);
            WSACleanup();
            MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
            return EXIT_FAILURE;
        }
    }
    total_time = clock()-total_time;
    
    CloseHandle(file);
    free(buffer);
    make_final_string(temp, base_path);
    
    if(MessageBox(NULL, TEXT(temp),  TEXT("Message"), MB_YESNO) == IDYES)
    {
       /* Per i path contenenti spazi necessitano i doppi apici altrimenti il comando
	      viene spezzato, ce li mettiamo comunque */
       ZeroMemory(temp, SIZE);
       temp[0] = '"';
       for(i = 1; dest_path[i-1] != '\0'; i++) 
          temp[i] = dest_path[i-1];      
       temp[i] = '"';
       system(temp);
    }
    return EXIT_SUCCESS;
}

void get_public_ip(char * ip)
{
    int n;
    WSADATA wsaData;
    SOCKET mysock;
    struct sockaddr_in serv;
	struct hostent * myip_server = NULL;
	char * ptr;
    char str[SIZE];
    char message[SIZE] = "GET /ip.php?.txt HTTP/1.1\r\n"
                         "User-Agent: filetransfer\r\n"
                         "Accept: */*\r\n"
                         "Host: www.indirizzo-ip.com\r\n"
                         "Connection: close\r\n"
                         "\r\n";
    
    if ((n = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0){ 
        sprintf(str, "Error at WSAStartup(): %d", n);
        MessageBox(NULL, TEXT(str), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return;
    }
    
    if((mysock = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET){
        sprintf(str, "Error at socket(): %d", WSAGetLastError());
        WSACleanup();
        MessageBox(NULL, TEXT(str), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return;
    }
    
    if((myip_server = gethostbyname("www.indirizzo-ip.com")) == NULL){
        get_error(str, WSAGetLastError());
        closesocket(mysock);
        WSACleanup();
        MessageBox(NULL, TEXT(str), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return;
    }
    
    ZeroMemory(&serv, sizeof(serv));
    CopyMemory((char *)&serv.sin_addr.s_addr, (char *)myip_server->h_addr, myip_server->h_length);
	serv.sin_family = AF_INET;
	serv.sin_port = htons(80);

	if (connect(mysock,(struct sockaddr *)&serv, sizeof(serv)) == SOCKET_ERROR){
        get_error(str, WSAGetLastError());
        closesocket(mysock);
        WSACleanup();
        MessageBox(NULL, TEXT(str), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return;
    }
    
    if (send(mysock, message, SIZE, 0) == SOCKET_ERROR){
        get_error(str, WSAGetLastError());
        closesocket(mysock);
        WSACleanup();
        MessageBox(NULL, TEXT(str), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return;
    }
    
    if(recv(mysock, str, SIZE, 0) == SOCKET_ERROR){
        get_error(str, WSAGetLastError());
        closesocket(mysock);
        WSACleanup();
        MessageBox(NULL, TEXT(str), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return;
    }
    closesocket(mysock);

    //ptr contiene la prima occorrenza di "Content-Type" in str
    ptr = strstr(str, "Content-Type");
    n = 0;
    for(; (*ptr)-'0' <= 0 || (*ptr)-'0' > 9; ptr++);
    for(; (*ptr) != '\0' && (*ptr) != '\n'; ip[n++]=(*ptr++));
}

void make_final_string(char * str, const char * path)
{
    int tot_secs = (int) total_time/CLOCKS_PER_SEC;
    if(tot_secs < 60)
        sprintf(str, "Durata trasferimento: %d secondi.\nFile salvato in: %s\nVuoi aprirlo?", tot_secs, path);
    else
        sprintf(str, "Durata trasferimento: %d minuti e %d secondi.\nFile salvato in: %s\nVuoi aprirlo?", tot_secs/60, tot_secs%60, path);
}

void get_error(char * str, int err)
{
     switch(err)
     {
         case WSAEACCES:
              strcpy(str, "Permission denied.");
              break;
         case WSAEFAULT:
              strcpy(str, "Bad address.");
              break;
         case WSAEADDRINUSE:
              strcpy(str, "Address already in use.");
              break;
         case WSAECONNABORTED:
              strcpy(str, "Software caused connection abort.");
              break;
         case WSAECONNRESET:
              strcpy(str, "Connection reset by peer.");
              break;
         case WSAETIMEDOUT:
              strcpy(str, "Connection timed out.");
              break;
         case WSAECONNREFUSED:
              strcpy(str, "Connection refused.");
              break;
         case WSAELOOP:
              strcpy(str, "Cannot translate name.");
              break;
         case WSAEHOSTDOWN:
              strcpy(str, "Host is down.");
              break;
         case WSAHOST_NOT_FOUND:
              strcpy(str, "Host not found.");
              break;
         default:
              sprintf(str, "%d", err);
              break;
     }
}
