#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <winsock.h>

#define DEFAULT_PORT      "12345"
#define SIZE              1024
//La percentuale del file mandato ad ogni invio, a parte l'ultimo
#define PERCENTUALE       1
#define ACK               1

int send_file(const char *, const char *, DWORD, HANDLE);
void parse_filepath(char *);
void input_file(char *);
void make_final_string(char *);
void get_error(char *, int);
clock_t total_time;

int main(int argc, char ** argv)
{
    HANDLE file;
    char file_name[SIZE], destinatario[SIZE];
    DWORD file_size;
    
    printf("Trascina sulla finestra il file da trasferire e premi invio\n");
    input_file(file_name);
    
    if((file = CreateFile(file_name, GENERIC_READ,
                          0, NULL, OPEN_EXISTING,
                          FILE_ATTRIBUTE_NORMAL, NULL)) == INVALID_HANDLE_VALUE)
    {
        FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), 0, destinatario, SIZE, NULL);
        MessageBox(NULL, TEXT(destinatario), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return EXIT_FAILURE;
    }
    file_size = GetFileSize(file, NULL);
    
    printf("\nInserisci il destinatario (nome host o indirizzo IP):\n");
    scanf("%s", destinatario);
    
    parse_filepath(file_name);
    if(send_file(file_name, destinatario, file_size, file) < 0){
        CloseHandle(file);
        return EXIT_FAILURE;
    }
    CloseHandle(file);
    
    //Riutilizzo la stringa destinatario, che ormai non serve piu'
    make_final_string(destinatario);
    MessageBox(NULL, TEXT(destinatario), TEXT("Message"), MB_OK); 
    return EXIT_SUCCESS;
}

void make_final_string(char * str)
{
    int tot_secs = (int) total_time/CLOCKS_PER_SEC;
    if(tot_secs < 60)
        sprintf(str, "File inviato correttamente in %d secondi.", tot_secs);
    else
        sprintf(str, "File inviato correttamente in %d minuti e %d secondi.", tot_secs/60, tot_secs%60);
}

void input_file(char * str)
{
   /* Trascinando il file sulla console, viene aggiunto il carattere " (doppi apici)
      all'inizio e alla fine quando il path contiene spazi, cos� facendo l'apertura
      del file fallisce, quindi li eliminiamo, se ci sono */
   int i;
   
   gets(str);
   if(str[0] != '"')
      return;
   //Eliminiamo il primo, shiftando di una posizione la stringa
   for(i = 1; i < SIZE; i++)
      str[i-1] = str[i];
   //Eliminiamo il secondo
   for(i = 0; i < SIZE; i++)
      if(str[i] == '"'){
         str[i] = '\0';
		 break;
	  }
}

//Estraggo il nome del file dal path assoluto
void parse_filepath(char * path)
{
     int i, index;
     for(i = 0; path[i] != '\0'; i++)
        if(path[i] == '\\')
           index = i;
           
     //Ora index contiene l'indice dell'ultima occorrenza del carattere '\'
     for(i = 0; path[index] != '\0'; i++, index++)
        path[i] = path[index];
     path[i] = '\0';
}

int send_file(const char * name, const char * dest, DWORD size, HANDLE file)
{
    SOCKET sock;
    char temp[SIZE], msg[50];;
    unsigned char * buffer = NULL;
    struct sockaddr_in serv_addr;
	struct hostent * server = NULL;
    WSADATA wsaData;
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO csbInfo;
    COORD CursorPos1, CursorPos2;
    double tacche;
    int i, n, step;
    DWORD sent = 0, left_to_send = size, BytesRead;
    
    if ((n = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0){ 
        sprintf(temp, "Error at WSAStartup(): %d", n);
        MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return -1;
    }
    
    if((sock = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET){
        sprintf(temp, "Error at socket(): %d", WSAGetLastError());
        WSACleanup();
        MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return -1;
    }
    
    printf("\nTest della connessione...");
    again:
    if(gethostbyname("www.google.it") == NULL)
    {
        if(MessageBox(NULL, TEXT("Connessione non disponibile.\nRiprovare?"),
                      TEXT("Message"), MB_ICONWARNING | MB_YESNO) == IDYES)
        goto again;
        else{
            WSACleanup();
			closesocket(sock);
            return -1;
        }
    }
    printf("OK\n");
    
    if((server = gethostbyname(dest)) == NULL){
        get_error(temp, WSAGetLastError());
        closesocket(sock);
        WSACleanup();
        MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return -1;
    }
    
    ZeroMemory(&serv_addr, sizeof(serv_addr));
    CopyMemory((char *)&serv_addr.sin_addr.s_addr, (char *)server->h_addr, server->h_length);
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(atoi(DEFAULT_PORT));
	
	//printf("\nDNS Lookup: %s\n", inet_ntoa(serv_addr.sin_addr));
	printf("\nDNS Lookup: %u.%u.%u.%u\n", (serv_addr.sin_addr.s_addr      ) & 0xFF,
                                          (serv_addr.sin_addr.s_addr >> 8 ) & 0xFF,
                                          (serv_addr.sin_addr.s_addr >> 16) & 0xFF,
                                          (serv_addr.sin_addr.s_addr >> 24) & 0xFF);

	if (connect(sock,(struct sockaddr *)&serv_addr, sizeof(serv_addr)) == SOCKET_ERROR){
        get_error(temp, WSAGetLastError());
        closesocket(sock);
        WSACleanup();
        MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return -1;
    }
    
    //Invio il nome del file
    if ((n = send(sock, name, SIZE, 0)) == SOCKET_ERROR){
        get_error(msg, WSAGetLastError());
        sprintf(temp, "Error at sending file name: %s", msg);
        closesocket(sock);
        WSACleanup();
        MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return -1;
    }
    
    //Aspetto l'ack
    if(ACK&& recv(sock, temp, SIZE, 0) == SOCKET_ERROR){
        get_error(msg, WSAGetLastError());
        sprintf(temp, "Error at receiving ack: %s", msg);
        closesocket(sock);
        WSACleanup();
        MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return -1;
    }
    
    //Invio la dimensione del file
    sprintf(temp, "%ld", size);
    if ((n = send(sock, temp, SIZE, 0)) == SOCKET_ERROR){
        get_error(msg, WSAGetLastError());
        sprintf(temp, "Error at sending file size: %s", msg);
        closesocket(sock);
        WSACleanup();
        MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return -1;
    }
    
    //Aspetto l'ack
    if(ACK&& recv(sock, temp, SIZE, 0) == SOCKET_ERROR){
        get_error(msg, WSAGetLastError());
        sprintf(temp, "Error at receiving ack: %s", msg);
        closesocket(sock);
        WSACleanup();
        MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return -1;
    }
    
    //Faccio in modo di inviare ogni volta la percentuale stabilita
    step = (int) (PERCENTUALE*size)/100;
    
    sprintf(temp, "%d", step);
    if ((n = send(sock, temp, SIZE, 0)) == SOCKET_ERROR){
        get_error(msg, WSAGetLastError());
        sprintf(temp, "Error at sending steps: %s", msg);
        closesocket(sock);
        WSACleanup();
        MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return -1;
    }
    
    //Aspetto l'ack
    if(ACK&& recv(sock, temp, SIZE, 0) == SOCKET_ERROR){
        get_error(msg, WSAGetLastError());
        sprintf(temp, "Error at receiving ack: %s", msg);
        closesocket(sock);
        WSACleanup();
        MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
        return -1;
    }

    printf("\nDimensione del file: %.*f MB\n", 2, size/1024.0/1024.0);
    printf("\n0         .         *         .         100\n");
    printf("|");
    GetConsoleScreenBufferInfo(hConsole, &csbInfo);
    CursorPos1 = csbInfo.dwCursorPosition;
    printf("                                        |\n");  
    CursorPos2 = CursorPos1;
    CursorPos2.X = 0;
    CursorPos2.Y += 2;
    
    SetConsoleCursorPosition(hConsole, CursorPos2);
    printf("%.*f/%.*f MB - %.*f %%", 2, sent/1024.0/1024.0, 2, size/1024.0/1024.0, 2, (double) ((sent*1.0)/size)*100.0);
 
    total_time = clock();
    while(sent < size)
    {
        //Alloco memoria per il buffer d'invio
        if((buffer = (unsigned char *) malloc(step)) == NULL){
            MessageBox(NULL, TEXT(temp), TEXT("Impossibile allocare memoria per il file"), MB_ICONWARNING | MB_OK);
            return -1;
        }
        
        if(ReadFile(file, buffer, step, &BytesRead, NULL) == 0){
            FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), 0, msg, 50, NULL);
            sprintf(temp, "Impossibile leggere il file: %s", msg);
            MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
            free(buffer); 
            return -1;
        }
        
        if ((n = send(sock, buffer, step, 0)) == SOCKET_ERROR){
            get_error(msg, WSAGetLastError());
            sprintf(temp, "Error at sending file: %s", msg);
            free(buffer);
            closesocket(sock);
            WSACleanup();
            MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
            return -1;
        }
        free(buffer);
        
        sent += n;
        left_to_send -= n;
        if(left_to_send < step)
           step = left_to_send;
        
        tacche = (double) 40.0*((sent*1.0)/size);
        SetConsoleCursorPosition(hConsole, CursorPos1);
        for(i = 0; i < (int)tacche-1; i++)
           printf("=");
        printf(">");
        
        SetConsoleCursorPosition(hConsole, CursorPos2);
        printf("%.*f/%.*f MB (%.*f %%)", 2, sent/1024.0/1024.0, 2, size/1024.0/1024.0, 2, (double) ((sent*1.0)/size)*100.0);
        
        //Aspetto l'ack
        if(ACK&& recv(sock, temp, SIZE, 0) == SOCKET_ERROR){
            get_error(msg, WSAGetLastError());
            sprintf(temp, "Error at receiving ack: %s", msg);
            closesocket(sock);
            WSACleanup();
            MessageBox(NULL, TEXT(temp), TEXT("Message"), MB_ICONWARNING | MB_OK);
            return -1;
        }
    }
    total_time = clock()-total_time;
    
    return 1;
}

void get_error(char * str, int err)
{
     switch(err)
     {
         case WSAEACCES:
              strcpy(str, "Permission denied.");
              break;
         case WSAEFAULT:
              strcpy(str, "Bad address.");
              break;
         case WSAEADDRINUSE:
              strcpy(str, "Address already in use.");
              break;
         case WSAECONNABORTED:
              strcpy(str, "Software caused connection abort.");
              break;
         case WSAECONNRESET:
              strcpy(str, "Connection reset by peer.");
              break;
         case WSAETIMEDOUT:
              strcpy(str, "Connection timed out.");
              break;
         case WSAECONNREFUSED:
              strcpy(str, "Connection refused.");
              break;
         case WSAELOOP:
              strcpy(str, "Cannot translate name.");
              break;
         case WSAEHOSTDOWN:
              strcpy(str, "Host is down.");
              break;
         case WSAHOST_NOT_FOUND:
              strcpy(str, "Host not found.");
              break;
         default:
              itoa(err, str, 10);
              break;
     }
}
