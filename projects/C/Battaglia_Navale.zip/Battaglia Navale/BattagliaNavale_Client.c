#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>

#define SIZE         120
#define DIM           8
#define TRUE          1
#define FALSE         0
#define VERTICALE     1
#define ORIZZONTALE   0
#define ACQUA        '2'
#define STR_ACQUA    "2"
#define COLPITO      '3'
#define STR_COLPITO  "3"
#define VITTORIA     '4'
#define SCONFITTA    '5'

int ** init_board (int **);
void error(char *) __attribute__ ((noreturn));
int metti_pezzo (int, int **);
int fine_partita (char *, int *, int *, int *, int *);
void print_board (int **, int);
char to_char (int);
void clear_screen();
char print_type (int);

int main(int argc, char *argv[])
{
	int vincitore, sockfd, nbytes, portno, i, j, index = 0;
	int ** my_board, ** board_colpi, ** my_board_colpita, acqua_colpito;
	int dimensione[] = {1, 2, 3, 4}, numero[] = {4, 3, 2, 1}, ncolpiti_io = 0, ncolpiti_lui = 0;
	struct sockaddr_in serv_addr;
	struct hostent *server;
	char buffer[SIZE], xy[SIZE];
	bzero(buffer, SIZE);
	bzero(xy, SIZE);
	
	if (argc < 3){
		fprintf(stderr,"usage %s hostname port\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	portno = atoi(argv[2]);
	if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		error("ERROR opening socket");
	if((server = gethostbyname(argv[1])) == NULL){
		herror("ERROR on gethostbyname");
		exit(EXIT_FAILURE);
	}

	bzero((char *) &serv_addr, sizeof(serv_addr));
	bcopy((char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(portno);
	
	if (connect(sockfd,(struct sockaddr*)&serv_addr,sizeof(serv_addr)) < 0) 
		error("ERROR on connecting");
	
	//Fase preliminare: inizializzazione e creazione board
	my_board = init_board(my_board);
	board_colpi = init_board(board_colpi);
	my_board_colpita = init_board(my_board_colpita);

	for (i = 0; i < 4; i++)
	{
		for (j = 0; j < numero[i]; j++)
		{
			clear_screen();
			print_board(my_board, -1);
			printf("Pezzi di dimensione %d messi: %d/%d\n", dimensione[i], j, numero[i]);
			while(!metti_pezzo(dimensione[i], my_board));
		}
	}
	clear_screen();
	print_board(my_board, -1);
	
	//Inviamo la board
	for (i = 0; i < DIM; i++)
		for (j = 0; j < DIM; j++)
			buffer[index++] = to_char(my_board[i][j]);
	buffer[index] = '\0';
	if(send(sockfd, buffer, strlen(buffer)+1, 0) < 0)
		error("ERROR writing to socket");
	bzero(buffer, SIZE);
		
	while(1)
	{		
		start:
		clear_screen();
		print_board(my_board_colpita, ncolpiti_lui);
		print_board(board_colpi, ncolpiti_io);
		
		printf("Attesa avversario...\n");
		//Messaggio del server con esito colpo avversario
		if((nbytes = recv(sockfd, buffer, SIZE, 0)) <= 0)
		{
			if(nbytes == 0){
				printf("Il server ha chiuso la connessione!\n");
				exit(EXIT_FAILURE);
			}
			else
				error("ERROR on recv");
		}

		/* Questo controllo e' per il primo client che si connette che
		   non e' in attesa di un reale esito del corpo dell'avversario,
		   in tale caso il server mi invia la stringa "Sblocco" ed io
		   vado avanti, per non avere problemi con le sequenza bloccanti
		   delle recv() */
		if(strcmp(buffer, "Sblocco"))
		{
			//Vediamo se e' fine partita
			if(!fine_partita(buffer, &vincitore, &i, &j, &acqua_colpito))
			{			
				my_board_colpita[i][j] = acqua_colpito;
				if(acqua_colpito == COLPITO-'0'){
					ncolpiti_lui++;
					goto start;
				}
			}
			else
				break;
			clear_screen();
			print_board(my_board_colpita, ncolpiti_lui);
			print_board(board_colpi, ncolpiti_io);
		}
		
		again:
		bzero(buffer, SIZE);
		//Messaggio del server: "Coordinate sparo:"
		if((nbytes = recv(sockfd, buffer, SIZE, 0)) <= 0)
		{
			if(nbytes == 0){
				printf("Il server ha chiuso la connessione!\n");
				exit(EXIT_FAILURE);
			}
			else
				error("ERROR on recv");
		}

		//Input coordinate dello sparo
		do{
			printf("%s", buffer);
			scanf("%s", xy);
			i = xy[0]-'0';
			j = xy[1]-'0';
		}
		while(i >= DIM || j >= DIM || board_colpi[i][j] != 0 || xy[0] == 0 || xy[1] == 0);
		
		//Invio coordinate sparo
		if(send(sockfd, xy, SIZE, 0) < 0)
			error("ERROR writing to socket");
		bzero(xy, SIZE);
		
		if((nbytes = recv(sockfd, buffer, SIZE, 0)) <= 0)
		{
			if(nbytes == 0){
				printf("Il server ha chiuso la connessione!\n");
				exit(EXIT_FAILURE);
			}
			else
				error("ERROR on recv");
		}

		//Vediamo se e' fine partita
		if(!fine_partita(buffer, &vincitore, &i, &j, &acqua_colpito))
		{
			board_colpi[i][j] = acqua_colpito;
			if(acqua_colpito == COLPITO-'0')
			{
				ncolpiti_io++;
				clear_screen();
				print_board(my_board_colpita, ncolpiti_lui);
				print_board(board_colpi, ncolpiti_io);
				goto again;
			}
		}
		else
			break;
	}
	
	clear_screen();
	print_board(my_board_colpita, ncolpiti_lui);
	print_board(board_colpi, ncolpiti_io);
	
	if (vincitore)
		printf("\nCOMPLIMENTI! HAI VINTO!\n");
	else
		printf("\nMI DISPIACE! HAI PERSO!\n");

	return EXIT_SUCCESS;
}

void error(char *msg)
{
	perror(msg);
	exit(EXIT_FAILURE);
}

void clear_screen()
{
	int i;
	for (i = 0; i < 60; i++)
		printf("\n");
}

int ** init_board (int ** b)
{
	int i, j;
	
	b = (int **) malloc (DIM * sizeof(int *));
	for (i = 0; i < DIM; i++)
	{
		b[i] = (int *) malloc (DIM * sizeof(int));
		for(j = 0; j < DIM; j++)
			b[i][j] = 0;
	}
	return b;
}

void print_board(int ** b, int val)
{
    int i, j;
	printf("\n");
    printf("\t\t    0     1     2     3     4     5     6     7\n");
    printf("\t\t  _____ _____ _____ _____ _____ _____ _____ _____\n");
    for (i = 0; i < DIM; i++)
    {
		printf("\t\t |     |     |     |     |     |     |     |     |\n");
		printf("\t    %d    ", i);
        for (j = 0; j < DIM; j++)
			printf("|  %c  ", print_type(b[i][j]));		
		printf("|");
		if (i == 0 && val != -1)
			printf("    %d/20", val);
		printf("\n\t\t |_____|_____|_____|_____|_____|_____|_____|_____|\n");
    }
	printf("\n");
}

char print_type (int val)
{
	switch(val)
	{
		case 0:
			return ' ';
			break;
		case 1:
		case COLPITO-'0':
			return 'X';
			break;
		case ACQUA-'0':
			return 'O';
			break;
		default:
			return ' ';
			break;
	}
}

int fine_partita (char * c, int * win, int * x, int * y, int * cosa)
{
	if(c[0] == '1')//la partita e' finita...
	{
		if(c[1] == VITTORIA) //...e abbiamo vinto
			*win = TRUE;
		else
			*win = FALSE; //... e abbiamo perso
		return TRUE;
	}
	else
	{
		*x = c[1]-'0';
		*y = c[2]-'0';
		*cosa = c[3]-'0';
		return FALSE;
	}
}

int metti_pezzo (int dim, int ** b)
{
	char buf[10];
	int x, y, i, j, dir = -1, count = 0;
	bzero(buf, 10);
	printf ("Inserisci coordinate XY in sequenza senza spazi: ");
	
	scanf("%s", buf);
	if(buf[0] == 0 || buf[1] == 0 || buf[0] == ' ' || buf[1] == ' ')
		return FALSE;

	x = buf[0]-'0';
	y = buf[1]-'0';
	
	if(b[x][y] != 0)
		return FALSE;
	if(dim == 1){
		b[x][y] = 1;
		return TRUE;
	}
	
	while(dir != ORIZZONTALE && dir != VERTICALE){
		printf ("ORIZZONTALE (%d) o VERTICALE (%d)?: ", ORIZZONTALE, VERTICALE);
		scanf("%d", &dir);
	}
	
	if (dir == ORIZZONTALE)
	{
		for (j = y; count < dim; j++, count++)
			if (j == DIM || b[x][j] != 0)
				return FALSE;
		//Se sono qui posso mettere il pezzo
		for (j = y, count = 0; count < dim; j++, count++)
			b[x][j] = 1;
		return TRUE;
	}
	else
	{
		for (i = x; count < dim; i++, count++)	
			if(i == DIM || b[i][y] != 0)
				return FALSE;
		//Se sono qui posso mettere il pezzo
		for (i = x, count = 0; count < dim; i++, count++)
			b[i][y] = 1;
		return TRUE;
	}
}

char to_char (int val)
{
	char str[] = "0123456789";
	return str[val];
}
