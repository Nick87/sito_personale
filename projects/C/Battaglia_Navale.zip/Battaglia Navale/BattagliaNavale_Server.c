#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define DIM            8
#define SIZE          120
#define TRUE           1
#define FALSE          0
#define STR_ACQUA     "2"
#define STR_COLPITO   "3"
#define STR_VITTORIA  "4"
#define STR_SCONFITTA "5"

typedef struct
{
	int fd;
	int ** board;
}client;

void error (char *) __attribute__ ((noreturn));
void init_players(client *);
void free_players(client *);
void fill_board (client *, char *);
void print_board (int **);

int main(int argc, char * argv[])
{
	struct sockaddr_in serv_addr, cli_addr;
	int listener, newfd, portno, i, j, nbytes, clilen, player, reuseaddr = TRUE, show_boards = FALSE;
	int colpiti[2] = {0, 0};
	client players[2];
	char buffer[SIZE];
	bzero(buffer, SIZE);
	
	if (argc < 2){
		fprintf(stderr,"Usage: %s port [flag]\n", argv[0]);
		exit(EXIT_FAILURE);
	}
	if(argc >= 3 && atoi(argv[2]))
		show_boards = TRUE;
	
	if((listener = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		error("ERROR opening socket");
	if(setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, &reuseaddr, sizeof(int)) == -1)
		error("ERROR setting socket");

	bzero((char *) &serv_addr, sizeof(serv_addr));
	portno = atoi(argv[1]);
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons(portno);

	if(bind(listener, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) 
		error("ERROR on binding");
	if(listen(listener, 5) < 0)
		error("ERROR on listening. ");
	printf("Server in ascolto\n");
	
	while(1)
	{
		start:
		init_players(players);
		for (i = 0; i < 2; i++)
		{
			clilen = sizeof(struct sockaddr_in);
			if((newfd = accept(listener, (struct sockaddr *)&cli_addr, (socklen_t *)&clilen)) == -1)
				error("ERROR on accept");
			players[i].fd = newfd;	
			printf("Server: nuova connessione da %s sulla socket %d\n", inet_ntoa(cli_addr.sin_addr), newfd);
							
			//Riceviamo la board
			if((nbytes = recv(players[i].fd, buffer, SIZE, 0)) <= 0)
			{
				if(nbytes == 0){
					free_players(players);
					bzero(buffer, SIZE);
					goto start;
				}
				else
					error("ERROR on recv");
			}
			fill_board(&players[i], buffer);
			printf("Ricevuta board numero %d\n",i+1);
			bzero(buffer, SIZE);
		}
		
		if(show_boards)
		{
			printf("\n");
			print_board(players[0].board);
			printf("\n");
			print_board(players[1].board);
			printf("\n");
		}

		/* Questa send e' per sbloccare il primo client dalla prima recv che 
		   e' in attesa dell'esito del colpo dell'avversario, ma essendo
		   il primo non  gli serve l'esito del colpo dell'avversario */
		if(send(players[0].fd, "Sblocco", SIZE, 0) < 0)
			error("ERROR writing to socket");
		
		player = 0;
		while(1)
		{
			//Invio messaggio
			strcpy(buffer, "Coordinate sparo: ");
			if(send(players[player].fd, buffer, SIZE, 0) < 0)
				error("ERROR writing to socket");
				
			//Riceviamo la posizione dello sparo
			if((nbytes = recv(players[player].fd, buffer, SIZE, 0)) <= 0)
			{
				if(nbytes == 0)
				{
					free_players(players);
					bzero(buffer, SIZE);
					goto start;
				}
				else
					error("ERROR on recv");
			}
			i = buffer[0]-'0';
			j = buffer[1]-'0';
			bzero(buffer, SIZE);
			
			//Vediamo se ha fatto centro o no
			if(players[(player+1)%2].board[i][j] != 0)
			{
				printf("Giocatore %d colpisce in %d-%d\n", player+1, i, j);
				colpiti[(player+1)%2]++;
			}
			else
				printf("Giocatore %d non colpisce in %d-%d\n", player+1, i, j);

			if(colpiti[(player+1)%2] != 20)//No fine partita
			{
				sprintf(buffer, "%d%d%d", 0, i, j);
				if(players[(player+1)%2].board[i][j] != 0)
					strcat(buffer, STR_COLPITO);
				else
					strcat(buffer, STR_ACQUA);
				if(send(players[player].fd, buffer, SIZE, 0) < 0)
					error("ERROR writing to socket");
				if(send(players[(player+1)%2].fd, buffer, SIZE, 0) < 0)
					error("ERROR writing to socket");
			}
			else //(player+1)%2 ha perso
			{
				printf("Vince il giocatore %d!\n", player+1);
				strcpy(buffer, "1");
				strcat(buffer, STR_VITTORIA);
				if(send(players[player].fd, buffer, SIZE, 0) < 0)
					error("ERROR writing to socket");
				bzero(buffer, SIZE);
				strcpy(buffer, "1");
				strcat(buffer, STR_SCONFITTA);
				if(send(players[(player+1)%2].fd, buffer, SIZE, 0) < 0)
					error("ERROR writing to socket");
				free_players(players);
				break; //while(1) interno
			}
			if(players[(player+1)%2].board[i][j] == 0)
				player = (player+1)%2;
			bzero(buffer, SIZE);
		}
	}
	return EXIT_SUCCESS; 
}

void error (char *msg)
{
	perror(msg);
	exit(EXIT_FAILURE);
}

void init_players (client * c)
{
	int i, j, k;
	for (i = 0; i < 2; i++)
	{
		c[i].fd = -1;
		c[i].board = (int **) malloc (DIM * sizeof(int *));
		for(j = 0; j < DIM; j++)
			c[i].board[j] = (int *) malloc (DIM * sizeof(int));
		for (j = 0; j < DIM; j++)
			for(k = 0; k < DIM; k++)
				c[i].board[j][k] = 0;
	}
}

void free_players (client * c)
{
	int i, j;
	for (i = 0; i < 2; i++)
	{
		if(close(c[i].fd) < 0)
			fprintf(stderr, "ERROR on closing connection\n");
		else
			printf("Socket %d chiusa correttamente!\n", c[i].fd);
		for (j = 0; j < DIM; j++)
			free(c[i].board[j]);
		free(c[i].board);
	}
}

void fill_board (client * c, char * buff)
{
	int i, j, index = 0;
	for (i = 0; i < DIM; i++)
		for(j = 0; j < DIM; j++)
			c->board[i][j] = buff[index++]-'0';
}

void print_board (int ** b)
{
	int i, j;
	printf(" --------\n");
	for(i = 0; i < DIM; i++)
	{
		printf("|");
		for(j = 0; j < DIM; j++)
			printf("%d", b[i][j]);
		printf("|");
		printf("\n");
	}
	printf(" --------\n");
}